import { useCallback, useEffect, useRef, useState } from "react";
import { GameEngine } from "./game/engine";
import {
  ActiveStation,
  EngineEvent,
  GameOverData,
  HudState,
  MeetingData,
  MeetingResult,
  PlayerInfo,
  ProposalData,
  Screen,
} from "./game/types";
import Crewmate from "./components/Crewmate";
import SettingsPanel from "./components/SettingsPanel";
import Guide from "./components/Guide";
import { ensureAudio, sfx, speak } from "./game/sound";
import { applyOrientation, getSettings, isForcedLandscape, mapDelta, markTutorialSeen, tutorialSeen } from "./game/settings";
import HUD from "./components/HUD";
import Meeting from "./components/Meeting";
import TaskGame from "./components/TaskGames";
import {
  EjectScreen,
  GameOverScreen,
  MenuScreen,
  RevealScreen,
} from "./components/Screens";

interface GameConfig {
  colorIdx: number;
  isImpostor: boolean;
  hat: string;
  mapIdx: number;
  lobby: { botCount: number; impostorCount: number };
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [config, setConfig] = useState<GameConfig | null>(null);
  const [gameId, setGameId] = useState(0);
  const [players, setPlayers] = useState<PlayerInfo[]>([]);
  const [hud, setHud] = useState<HudState | null>(null);
  const [meeting, setMeeting] = useState<{
    data: MeetingData;
    intel: { suspectId: number | null; witnessId: number | null; camera: boolean };
    coins: number;
  } | null>(null);
  const [eject, setEject] = useState<{
    ejected: PlayerInfo | null;
    jailed: PlayerInfo | null;
    wasImpostor: boolean;
    remaining: number;
  } | null>(null);
  const [gameOver, setGameOver] = useState<GameOverData | null>(null);
  const [flash, setFlash] = useState(0);
  const [deathBanner, setDeathBanner] = useState(false);
  const [disruptBanner, setDisruptBanner] = useState(false);
  const [activeGame, setActiveGame] = useState<ActiveStation | null>(null);
  const [proposal, setProposal] = useState<ProposalData | null>(null);
  const [tutorial, setTutorial] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [pauseTab, setPauseTab] = useState<"main" | "settings">("main");
  const [showGuide, setShowGuide] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const gameOverRef = useRef<GameOverData | null>(null);
  const screenRef = useRef<Screen>("menu");
  screenRef.current = screen;
  const lastBeat = useRef(0);
  const lastAlarm = useRef(-1);
  const camDrag = useRef<{ id: number; x: number; y: number } | null>(null);
  const orientedRef = useRef(false);
  const [forcedRot, setForcedRot] = useState(isForcedLandscape());

  // inside the Capacitor APK the WebView allows locking WITHOUT a user
  // gesture — command the phone to rotate the moment the app opens
  useEffect(() => {
    const w = window as unknown as { Capacitor?: unknown };
    if (w.Capacitor) {
      void applyOrientation(getSettings().orientation);
    }
  }, []);

  // keep CSS-rotation in sync with device rotation / settings changes
  useEffect(() => {
    const sync = () => {
      const f = isForcedLandscape();
      setForcedRot(f);
      document.documentElement.classList.toggle("force-landscape", f);
    };
    sync();
    window.addEventListener("resize", sync);
    const iv = setInterval(sync, 800); // settings may change without resize
    return () => {
      window.removeEventListener("resize", sync);
      clearInterval(iv);
    };
  }, []);

  const handleEvent = useCallback((e: EngineEvent) => {
    const engine = engineRef.current;
    if (!engine) return;
    if (e.type === "meeting") {
      setDeathBanner(false);
      setActiveGame(null);
      setProposal(null);
      sfx.meeting();
      speak(e.data.reason === "body" ? "bodyReported" : "emergency");
      setTimeout(() => speak("voting"), 2200);
      setPlayers(engine.getPlayers());
      setMeeting({ data: e.data, intel: engine.getIntel(), coins: engine.coins });
      setScreen("meeting");
    } else if (e.type === "playerKilled") {
      setFlash((f) => f + 1);
      sfx.kill();
      speak("youDied");
      setActiveGame(null);
      setProposal(null);
      setDeathBanner(true);
      try {
        navigator.vibrate?.([80, 40, 120]);
      } catch {
        /* no vibration */
      }
      setTimeout(() => setDeathBanner(false), 3200);
    } else if (e.type === "killFlash") {
      setFlash((f) => f + 1);
      sfx.kill();
      speak("kill");
    } else if (e.type === "sabotage") {
      sfx.sabotage();
      speak(e.kind === "reactor" ? "sabotageReactor" : "sabotageLights");
    } else if (e.type === "sabotageFixed") {
      sfx.fixed();
      speak("sabotageFixed");
    } else if (e.type === "camsDown") {
      sfx.sabotage();
      speak("camsDown");
    } else if (e.type === "stealthKill") {
      setTutorial("📷🔪 قتل مخفیانه! دوربین‌ها همزمان با قتل قطع شدند — هیچ فیلمی ثبت نشد.");
      setTimeout(() => setTutorial(null), 3500);
    } else if (e.type === "avenger") {
      sfx.sabotage();
      setTutorial(`😡🔪 «${e.botName}» قسم خورده انتقام هم‌دستش را از تو بگیرد... فرار کن!`);
      setTimeout(() => setTutorial(null), 5000);
      try {
        navigator.vibrate?.([60, 40, 60]);
      } catch {
        /* no vibration */
      }
    } else if (e.type === "proposal") {
      sfx.click();
      setProposal(e.data);
    } else if (e.type === "proposalOver") {
      setProposal(null);
    } else if (e.type === "gameover") {
      gameOverRef.current = e.data;
      speak(e.data.playerWon ? "victory" : "defeat");
      setGameOver(e.data);
      setPlayers(engine.getPlayers());
      setActiveGame(null);
      if (screenRef.current === "game") {
        setTimeout(() => setScreen("gameover"), 900);
      }
    }
  }, []);

  useEffect(() => {
    if (!config || !canvasRef.current) return;
    const engine = new GameEngine(
      canvasRef.current,
      config.colorIdx,
      config.isImpostor,
      config.hat,
      config.mapIdx,
      handleEvent,
      config.lobby,
    );
    engineRef.current = engine;
    setPlayers(engine.getPlayers());
    setHud(engine.getHud());
    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, [config, gameId, handleEvent]);

  // HUD polling + scare sounds
  useEffect(() => {
    if (screen !== "game") return;
    const iv = setInterval(() => {
      const engine = engineRef.current;
      if (!engine) return;
      const h = engine.getHud();
      setHud(h);
      // one-time tutorials (persisted)
      if (h.watchingCam >= 0 && !tutorialSeen("cctv")) {
        markTutorialSeen("cctv");
        setTutorial("📷 با دوربین‌های مداربسته می‌توانی حرکات بازیکنان را زیر نظر بگیری. با کشیدن صفحه، دوربین را بچرخان!");
        setTimeout(() => setTutorial(null), 6000);
      }
      if (h.jailTime > 0 && !tutorialSeen("jail")) {
        markTutorialSeen("jail");
        setTutorial("⛓ اگر بیشترین رأی را بیاوری ولی اکثریت مطلق نباشد، به بازداشتگاه منتقل می‌شوی. تا پایان تایمر صبر کن!");
        setTimeout(() => setTutorial(null), 6000);
      }
      const now = performance.now();
      // heartbeat when impostor is near
      if (h.danger > 0.45 && now - lastBeat.current > 900 - h.danger * 450) {
        lastBeat.current = now;
        sfx.heartbeat();
        if (h.danger > 0.7) {
          try {
            navigator.vibrate?.(30);
          } catch {
            /* ignore */
          }
        }
      }
      // reactor alarm ticks
      if (h.sabotage?.kind === "reactor") {
        const sec = Math.ceil(h.sabotage.timeLeft);
        if (sec !== lastAlarm.current) {
          lastAlarm.current = sec;
          sfx.alarm();
        }
      }
    }, 100);
    return () => clearInterval(iv);
  }, [screen]);

  const start = (
    colorIdx: number,
    role: "auto" | "crew" | "impostor",
    hat: string,
    mapIdx: number,
    lobby: { botCount: number; impostorCount: number },
  ) => {
    // auto role: fair odds = impostors / total players
    const fairOdds = lobby.impostorCount / (lobby.botCount + 1);
    const isImpostor = role === "impostor" || (role === "auto" && Math.random() < fairOdds);
    // apply the player's preferred screen orientation (fullscreen + lock)
    void applyOrientation(getSettings().orientation);
    gameOverRef.current = null;
    setGameOver(null);
    setMeeting(null);
    setEject(null);
    setHud(null);
    setActiveGame(null);
    setProposal(null);
    setConfig({ colorIdx, isImpostor, hat, mapIdx, lobby });
    setScreen("reveal");
    // voice: role reveal in Persian
    setTimeout(() => speak(isImpostor ? "youImpostor" : "youCrew"), 600);
    setTimeout(() => {
      if (!gameOverRef.current) {
        setScreen("game");
        speak("gameStart");
      }
    }, 3800);
  };

  const restart = () => {
    setConfig(null);
    setGameId((g) => g + 1);
    setScreen("menu");
    setHud(null);
    setPlayers([]);
    setMeeting(null);
    setEject(null);
    setGameOver(null);
    setActiveGame(null);
    setProposal(null);
    gameOverRef.current = null;
    setDeathBanner(false);
    setPaused(false);
  };

  const onMeetingDone = (result: MeetingResult) => {
    const engine = engineRef.current;
    if (!engine) return;
    if (result.disrupted) {
      // sabotaged meeting — nobody ejected, back to the ship
      setMeeting(null);
      engine.resolveMeeting(null);
      setPlayers(engine.getPlayers());
      if (gameOverRef.current) {
        setScreen("gameover");
      } else {
        setScreen("game");
        setDisruptBanner(true);
        setTimeout(() => setDisruptBanner(false), 2800);
      }
      return;
    }
    // settle bribe deals / threats / missions based on the actual outcome
    engine.settleMeetingOutcome(result.votes, result.ejectedId, result.jailedId ?? null);
    const ejectedInfo =
      result.ejectedId === null ? null : players.find((p) => p.id === result.ejectedId) ?? null;
    const jailedInfo =
      result.jailedId == null ? null : players.find((p) => p.id === result.jailedId) ?? null;
    const remaining = players.filter(
      (p) => p.isImpostor && p.alive && p.id !== (result.ejectedId ?? -99),
    ).length;
    setMeeting(null);
    setEject({
      ejected: ejectedInfo,
      jailed: jailedInfo,
      wasImpostor: ejectedInfo?.isImpostor ?? false,
      remaining,
    });
    setScreen("eject");
    speak(jailedInfo ? "jailed" : ejectedInfo ? "ejected" : "notEjected");
    setTimeout(() => {
      engine.resolveMeeting(result.ejectedId, result.jailedId ?? null);
      setPlayers(engine.getPlayers());
      setEject(null);
      if (gameOverRef.current) {
        setScreen("gameover");
      } else {
        setScreen("game");
      }
    }, 4200);
  };

  const onUse = () => {
    const engine = engineRef.current;
    if (!engine) return;
    const st = engine.getActiveStation();
    if (st) {
      engine.setMove(0, 0);
      setActiveGame(st);
    } else {
      engine.pressUse(); // emergency button
    }
  };

  const inRound = config !== null && screen !== "menu";

  return (
    <div
      className={forcedRot ? "fixed bg-[#050914] overflow-hidden" : "relative w-full h-[100dvh] bg-[#050914] overflow-hidden"}
      style={
        forcedRot
          ? {
              top: 0,
              left: 0,
              width: "100dvh",
              height: "100dvw",
              transform: "rotate(90deg) translateY(-100%)",
              transformOrigin: "top left",
            }
          : undefined
      }
      onPointerDown={() => {
        ensureAudio();
        // NATIVE-GAME BEHAVIOR: keep asking the phone to rotate on every tap
        // until the hardware lock actually succeeds (Android fullscreen+lock).
        // Until then the CSS rotation fallback keeps the game landscape anyway.
        if (
          getSettings().orientation === "landscape" &&
          window.innerHeight > window.innerWidth
        ) {
          void applyOrientation("landscape");
        } else if (!orientedRef.current) {
          orientedRef.current = true;
          void applyOrientation(getSettings().orientation);
        }
      }}
    >
      {config && (
        <canvas key={gameId} ref={canvasRef} className="absolute inset-0 w-full h-full" />
      )}

      {inRound && screen === "game" && hud && engineRef.current && (
        <HUD
          hud={hud}
          onMove={(x, y) => engineRef.current?.setMove(x, y)}
          onLook={(dx, dy) => engineRef.current?.addLook(dx, dy)}
          onUse={onUse}
          onReport={() => engineRef.current?.pressReport()}
          onKill={() => engineRef.current?.pressKill()}
          onSabotage={(kind) => engineRef.current?.triggerSabotage(kind)}
          onSabotageCams={() => engineRef.current?.sabotageCameras()}
          onWatchCams={() => engineRef.current?.startWatchingCams()}
          onTalk={(kind) => engineRef.current?.playerTalk(kind) ?? ""}
          onSit={() => engineRef.current?.sitDown()}
          onStand={() => engineRef.current?.standUp()}
          onTableSay={(idx) => engineRef.current?.tableSay(idx) ?? ""}
          onPause={() => {
            engineRef.current?.setPaused(true);
            setPauseTab("main");
            setPaused(true);
            sfx.click();
          }}
        />
      )}

      {/* CCTV viewer overlay */}
      {screen === "game" && hud && hud.watchingCam >= 0 && (
        <div className="absolute inset-0 z-20 pointer-events-none">
          {/* CRT frame + drag-to-rotate layer */}
          <div
            className="absolute inset-0 pointer-events-auto"
            style={{
              boxShadow: "inset 0 0 120px 30px rgba(0,20,50,.8)",
              background:
                "repeating-linear-gradient(0deg, rgba(0,0,0,0.12) 0px, rgba(0,0,0,0.12) 2px, transparent 2px, transparent 5px)",
              touchAction: "none",
            }}
            onPointerDown={(e) => {
              camDrag.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
              (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
            }}
            onPointerMove={(e) => {
              if (camDrag.current?.id === e.pointerId) {
                const [rdx, rdy] = mapDelta(
                  e.clientX - camDrag.current.x,
                  e.clientY - camDrag.current.y,
                );
                engineRef.current?.rotateCam(rdx, rdy);
                camDrag.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
              }
            }}
            onPointerUp={() => (camDrag.current = null)}
            onPointerCancel={() => (camDrag.current = null)}
          />
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-3">
            <span className="px-3 py-1 rounded-lg bg-black/80 border border-red-500/60 text-red-400 text-xs font-black animate-pulse">
              🔴 LIVE
            </span>
            <span className="px-3 py-1 rounded-lg bg-black/80 border border-cyan-500/40 text-cyan-200 text-sm font-black">
              📷 دوربین {hud.watchingCam + 1}/{hud.camCount} —{" "}
              {engineRef.current?.getCamRoomName() ?? ""}
            </span>
          </div>
          <div className="absolute top-14 left-1/2 -translate-x-1/2 pointer-events-none">
            <span className="text-white/40 text-[10px] font-bold">
              🔄 برای چرخاندن دوربین، صفحه را بکشید
            </span>
          </div>
          <div className="absolute bottom-8 landscape:bottom-3 left-1/2 -translate-x-1/2 flex gap-3 pointer-events-auto landscape:scale-90">
            <button
              onPointerDown={() => engineRef.current?.switchCam(-1)}
              className="w-14 h-14 rounded-2xl bg-slate-800/90 border-2 border-slate-500 text-white text-xl font-black active:scale-90"
            >
              ▶
            </button>
            <button
              onPointerDown={() => {
                engineRef.current?.stopWatchingCams();
                sfx.click();
              }}
              className="px-6 h-14 rounded-2xl bg-red-700/90 border-2 border-red-400 text-white text-sm font-black active:scale-95"
            >
              ✕ خروج از دوربین
            </button>
            <button
              onPointerDown={() => engineRef.current?.switchCam(1)}
              className="w-14 h-14 rounded-2xl bg-slate-800/90 border-2 border-slate-500 text-white text-xl font-black active:scale-90"
            >
              ◀
            </button>
          </div>
        </div>
      )}

      {/* bot proposal modal */}
      {screen === "game" && proposal && (
        <div className="absolute inset-x-0 top-1/4 z-30 flex justify-center px-4 pointer-events-none">
          <div className="pointer-events-auto w-full max-w-sm rounded-3xl bg-slate-900/95 border-2 border-emerald-400/60 p-4 anim-popIn shadow-2xl">
            <div className="flex items-center gap-3 mb-2">
              <div className="shrink-0" style={{ animation: "floatY 2.5s ease-in-out infinite" }}>
                <Crewmate color={proposal.botColor} hat={proposal.botHat} size={52} />
              </div>
              <div>
                <div className="text-white font-black text-sm">{proposal.botName}</div>
                <div className="text-slate-200/90 text-xs font-semibold leading-5 mt-0.5">
                  {proposal.text}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <button
                onClick={() => {
                  engineRef.current?.respondProposal(true, {
                    reward: proposal.reward,
                    targetId: proposal.targetId,
                  });
                  setProposal(null);
                  sfx.click();
                }}
                className="py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black border-2 border-emerald-300 active:scale-95"
              >
                {proposal.acceptLabel}
              </button>
              <button
                onClick={() => {
                  engineRef.current?.respondProposal(false);
                  setProposal(null);
                }}
                className="py-2.5 rounded-xl bg-slate-700 text-slate-200 text-xs font-black border-2 border-slate-500 active:scale-95"
              >
                {proposal.declineLabel}
              </button>
            </div>
            {proposal.kind === "lure" || proposal.kind === "task" ? (
              <div className="text-center text-white/35 text-[10px] mt-2">
                ⚠️ به هرکسی اعتماد نکن...
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* task minigame */}
      {screen === "game" && activeGame && (
        <TaskGame
          kind={activeGame.kind}
          label={activeGame.label}
          onDone={() => {
            engineRef.current?.completeStation(activeGame.stationId);
            sfx.task();
            speak("taskComplete");
            setActiveGame(null);
          }}
          onCancel={() => setActiveGame(null)}
        />
      )}

      {/* pause / stop menu */}
      {paused && screen === "game" && (
        <div className="absolute inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm max-h-[90%] overflow-y-auto scroll-y rounded-3xl bg-slate-900/95 border-2 border-slate-500/60 p-4 anim-popIn">
            <div className="text-center text-white font-black text-xl mb-4">⏸ بازی متوقف شد</div>
            {pauseTab === "main" ? (
              <div className="space-y-2.5">
                <button
                  onClick={() => {
                    engineRef.current?.setPaused(false);
                    setPaused(false);
                    sfx.click();
                  }}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-l from-emerald-600 to-teal-500 text-white font-black border-2 border-emerald-300 active:scale-95"
                >
                  ▶️ ادامه بازی
                </button>
                <button
                  onClick={() => setPauseTab("settings")}
                  className="w-full py-3.5 rounded-2xl bg-slate-700 text-white font-black border-2 border-slate-500 active:scale-95"
                >
                  ⚙️ تنظیمات
                </button>
                <button
                  onClick={() => setShowGuide(true)}
                  className="w-full py-3.5 rounded-2xl bg-indigo-700 text-white font-black border-2 border-indigo-400 active:scale-95"
                >
                  📖 راهنمای بازی
                </button>
                <button
                  onClick={() => {
                    setPaused(false);
                    restart();
                  }}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-l from-rose-700 to-red-600 text-white font-black border-2 border-rose-400 active:scale-95"
                >
                  🚪 خروج به منوی اصلی
                </button>
                <div className="text-center text-white/35 text-[10px] pt-1">
                  بازی تا وقتی برنگردی کاملاً متوقف می‌ماند
                </div>
              </div>
            ) : (
              <div className="space-y-2.5">
                <SettingsPanel onChanged={() => engineRef.current?.applySettings()} />
                <button
                  onClick={() => setPauseTab("main")}
                  className="w-full py-3 rounded-2xl bg-slate-700 text-white font-black border-2 border-slate-500 active:scale-95"
                >
                  ← بازگشت
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* full game guide overlay */}
      {showGuide && <Guide onClose={() => setShowGuide(false)} />}

      {/* one-time tutorial toast */}
      {tutorial && screen === "game" && (
        <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 z-40 w-[90%] max-w-md pointer-events-none">
          <div className="px-4 py-3 rounded-2xl bg-indigo-950/95 border-2 border-indigo-400/60 text-indigo-100 text-sm font-bold text-center anim-popIn leading-6">
            {tutorial}
          </div>
        </div>
      )}

      {/* kill flash */}
      {flash > 0 && (
        <div
          key={flash}
          className="absolute inset-0 pointer-events-none z-40 bg-red-600"
          style={{ animation: "killFlash .7s ease-out forwards" }}
        />
      )}

      {/* death banner */}
      {deathBanner && screen === "game" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none">
          <div className="text-center anim-fadeUp">
            <div
              className="text-5xl font-black text-red-500 mb-2"
              style={{ textShadow: "0 0 30px rgba(255,0,0,.8)" }}
            >
              💀 شما کشته شدید!
            </div>
            <div className="text-white/70 font-bold">اکنون روح هستید... 👻</div>
          </div>
        </div>
      )}

      {/* disrupted meeting banner */}
      {disruptBanner && screen === "game" && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
          <div className="px-6 py-3 rounded-2xl bg-black/80 border-2 border-orange-500 anim-fadeUp text-center">
            <div className="text-orange-400 font-black text-xl">⚡ جلسه بهم خورد!</div>
            <div className="text-white/60 text-xs font-bold mt-1">هیچ‌کس اخراج نشد...</div>
          </div>
        </div>
      )}

      {screen === "menu" && <MenuScreen onStart={start} />}
      {screen === "reveal" && config && (
        <RevealScreen isImpostor={config.isImpostor} players={players} />
      )}
      {screen === "meeting" && meeting && (
        <Meeting
          players={players}
          meeting={meeting.data}
          intel={meeting.intel}
          coins={meeting.coins}
          votesLeft={engineRef.current?.voteTokens ?? 0}
          defensesLeft={engineRef.current?.defensesLeft ?? 0}
          grudges={engineRef.current?.getGrudges() ?? []}
          deal={engineRef.current?.getDeal() ?? null}
          mission={engineRef.current?.getMission() ?? null}
          seed={
            engineRef.current?.getMeetingSeed() ?? {
              scores: {},
              witness: null,
              personalities: {},
            }
          }
          onClaim={(s, t, k) => engineRef.current?.noteMeetingClaim(s, t, k)}
          camLog={engineRef.current?.getCamLog() ?? []}
          camHint={engineRef.current?.getCamHint() ?? null}
          onConsumeVote={() => engineRef.current?.consumeVote() ?? false}
          onConsumeDefense={() => engineRef.current?.consumeDefense() ?? false}
          onSpend={(n) => engineRef.current?.spendCoins(n) ?? false}
          onDone={onMeetingDone}
        />
      )}
      {screen === "eject" && eject && (
        <EjectScreen
          ejected={eject.ejected}
          jailed={eject.jailed}
          wasImpostor={eject.wasImpostor}
          remainingImpostors={eject.remaining}
        />
      )}
      {screen === "gameover" && gameOver && (
        <GameOverScreen data={gameOver} players={players} onRestart={restart} />
      )}
    </div>
  );
}
