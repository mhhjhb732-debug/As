import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MeetingData, MeetingResult, PlayerInfo } from "../game/types";
import { sfx } from "../game/sound";
import Crewmate from "./Crewmate";

interface Props {
  players: PlayerInfo[];
  meeting: MeetingData;
  intel: { suspectId: number | null; witnessId: number | null; camera: boolean };
  coins: number;
  votesLeft: number;
  defensesLeft: number;
  grudges: number[]; // bots that hate the player
  deal: { botId: number; targetId: number; reward: number } | null;
  mission: { botId: number; targetId: number; reward: number } | null;
  seed: {
    scores: Record<number, Record<number, number>>;
    witness: { id: number; suspectId: number; kind: "sawKill" | "nearBody" } | null;
    personalities: Record<number, { aggression: number; bravery: number; label: string }>;
  };
  camLog: { id: number; name: string; color: string; room: string; secsAgo: number }[];
  camHint: { suspectId: number; room: string; secsAgo: number } | null;
  onConsumeVote: () => boolean;
  onConsumeDefense: () => boolean;
  onSpend: (n: number) => boolean;
  onClaim: (speakerId: number, targetId: number, kind: "accusation" | "defense" | "lie") => void;
  onDone: (result: MeetingResult) => void;
}

interface ChatMsg {
  id: number;
  from: PlayerInfo;
  text: string;
  system?: boolean;
}

const DISCUSS_TIME = 15;
const VOTE_TIME = 30;
const BRIBE_COST = 25;
const FRAME_COST = 15;
const DISRUPT_COST = 40;

let msgSeq = 1000;

export default function Meeting({
  players,
  meeting,
  intel,
  coins,
  votesLeft,
  defensesLeft,
  grudges,
  deal,
  mission,
  seed,
  camLog,
  camHint,
  onConsumeVote,
  onConsumeDefense,
  onSpend,
  onClaim,
  onDone,
}: Props) {
  const me = players.find((p) => p.id === 0)!;
  const alive = useMemo(() => players.filter((p) => p.alive), [players]);
  const canVote = me.alive;

  const [phase, setPhase] = useState<"discuss" | "vote" | "reveal" | "blackout">("discuss");
  const [timer, setTimer] = useState(DISCUSS_TIME);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [myVote, setMyVote] = useState<number | -1 | null>(null);
  const [botVotes, setBotVotes] = useState<Record<number, number | -1>>({});
  const [result, setResult] = useState<MeetingResult | null>(null);
  const [myCoins, setMyCoins] = useState(coins);
  const [msgsLeft, setMsgsLeft] = useState(3);
  const [pickMode, setPickMode] = useState<"accuse" | "frame" | "bribe" | null>(null);
  const [bribed, setBribed] = useState<Set<number>>(new Set());
  const [disruptUsed, setDisruptUsed] = useState(false);
  const [myVotesLeft, setMyVotesLeft] = useState(votesLeft);
  const [myDefenses, setMyDefenses] = useState(defensesLeft);
  const [showCams, setShowCams] = useState(false);
  const defendedRef = useRef(false); // once per meeting

  const chatRef = useRef<HTMLDivElement>(null);
  const doneRef = useRef(false);
  // suspicion[botId][targetId]
  const suspRef = useRef<Record<number, Record<number, number>>>({});
  const changedRef = useRef<Set<number>>(new Set());
  const botVotesRef = useRef(botVotes);
  botVotesRef.current = botVotes;
  const myVoteRef = useRef(myVote);
  myVoteRef.current = myVote;
  const bribedRef = useRef(bribed);
  bribedRef.current = bribed;
  const phaseRef = useRef(phase);
  phaseRef.current = phase;

  const name = useCallback(
    (id: number | null) =>
      id === null ? "؟" : id === 0 ? "شما" : players.find((p) => p.id === id)?.name ?? "؟",
    [players],
  );

  const pushChat = useCallback((from: PlayerInfo, text: string, system = false) => {
    setChat((c) => [...c, { id: msgSeq++, from, text, system }]);
  }, []);

  // ---- seed suspicion from each bot's OWN memory (no god-mode) ---------------
  // engine scores are 0..100 → convert to meeting scale (÷20).
  useEffect(() => {
    const s: Record<number, Record<number, number>> = {};
    for (const b of alive.filter((p) => p.isBot)) {
      s[b.id] = {};
      const mine = seed.scores[b.id] ?? {};
      for (const t of alive) {
        if (t.id === b.id) continue;
        s[b.id][t.id] = Math.max(0, (mine[t.id] ?? 0) / 20) + Math.random() * 0.3;
      }
      // public CCTV evidence is common knowledge
      if (intel.camera && intel.suspectId !== null && intel.suspectId !== b.id) {
        s[b.id][intel.suspectId] = (s[b.id][intel.suspectId] ?? 0) + 3;
      }
      // betrayed bots blame the player hard
      if (grudges.includes(b.id)) {
        s[b.id][0] = (s[b.id][0] ?? 0) + 3.5;
      }
    }
    suspRef.current = s;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- opening chat script ---------------------------------------------------
  useEffect(() => {
    const reporter = players.find((p) => p.id === meeting.reporterId)!;
    const victimName = meeting.victimId !== null ? name(meeting.victimId) : null;
    const msgs: { delay: number; from: PlayerInfo; text: string }[] = [];
    if (meeting.reason === "body") {
      msgs.push({
        delay: 0.5,
        from: reporter,
        text: `جسد ${victimName} را پیدا کردم! 😱`,
      });
    } else {
      msgs.push({ delay: 0.5, from: reporter, text: "جلسه اضطراری! باید صحبت کنیم." });
    }
    const talkers = alive.filter((p) => p.isBot && p.id !== meeting.reporterId);
    const lines = [
      "کجا بود جسد؟",
      "من تمام مدت در درمانگاه بودم.",
      "کسی چیز مشکوکی ندید؟",
      "من داشتم سیم‌ها را وصل می‌کردم...",
      "خیلی مشکوکه 🤔",
      "بدون مدرک رأی ندید!",
    ];
    let t = 1.6;
    for (let i = 0; i < Math.min(3, talkers.length); i++) {
      msgs.push({ delay: t, from: talkers[i], text: lines[i % lines.length] });
      t += 1.8;
    }
    if (intel.camera && intel.suspectId !== null) {
      const suspect = players.find((p) => p.id === intel.suspectId);
      if (suspect?.alive) {
        msgs.push({
          delay: t + 0.5,
          from: reporter,
          text: `📷 فیلم دوربین مداربسته را ببینید!! ${name(intel.suspectId)} دقیقاً لحظه قتل ثبت شده!! مدرک قطعی!`,
        });
      }
    } else if (seed.witness) {
      // source-accurate testimony: a bot may only claim what it actually saw
      const witness = players.find((p) => p.id === seed.witness!.id);
      const suspect = players.find((p) => p.id === seed.witness!.suspectId);
      if (witness?.alive && suspect?.alive) {
        const sawKill = seed.witness.kind === "sawKill";
        msgs.push({
          delay: t + 0.5,
          from: witness,
          text: sawKill
            ? `با چشم‌های خودم دیدم!! ${name(seed.witness.suspectId)} همان لحظه بالای جسد ایستاده بود! 🔪 تقریباً مطمئنم کار خودشه!`
            : `من ${name(seed.witness.suspectId)} را نزدیک جسد دیدم... مطمئن نیستم کار او باشد، ولی خیلی مشکوک است 🤔`,
        });
        // others HEAR this — second-hand info, weaker than seeing
        const echo = talkers.find((p) => p.id !== seed.witness!.id && p.id !== seed.witness!.suspectId);
        if (echo) {
          msgs.push({
            delay: t + 2.2,
            from: echo,
            text: sawKill
              ? `اگر ${name(seed.witness.id)} با چشم خودش دیده، برای من کافیه!`
              : `${name(seed.witness.id)} می‌گوید او را نزدیک جسد دیده... فقط شنیده‌ست، مدرک قطعی نیست.`,
          });
        }
      }
    }
    // grudge bot rants against the player
    const angryBot = players.find((p) => p.alive && p.isBot && grudges.includes(p.id));
    if (angryBot && me.alive) {
      msgs.push({
        delay: t + 1.4,
        from: angryBot,
        text: `به ${me.name} اعتماد نکنید! بهم خیانت کرد! پولمو گرفت و زیرش زد! 😡 بهش رأی بدید!`,
      });
    }
    const timers = msgs.map((m) =>
      setTimeout(() => pushChat(m.from, m.text), m.delay * 1000),
    );
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    chatRef.current?.scrollTo({ top: 99999, behavior: "smooth" });
  }, [chat]);

  // ---- a bot goes to check the CCTV during discussion and reports back ------
  useEffect(() => {
    const checkers = alive.filter((p) => p.isBot && p.id !== meeting.reporterId);
    const checker = checkers[Math.floor(Math.random() * checkers.length)];
    if (!checker) return;
    const t1 = setTimeout(() => {
      pushChat(checker, "صبر کنید... من میرم فیلم دوربین‌های مداربسته رو چک کنم 📷🏃");
    }, 6500);
    const t2 = setTimeout(() => {
      if (camHint) {
        const suspect = players.find((p) => p.id === camHint.suspectId);
        if (suspect?.alive) {
          pushChat(
            checker,
            `برگشتم!! 📷 دوربین‌ها «${name(camHint.suspectId)}» رو ${Math.round(
              camHint.secsAgo,
            )} ثانیه قبل توی «${camHint.room}» نشون میدن — دقیقاً مسیر جسد!! بهش رأی بدید!`,
          );
          shiftOpinions(camHint.suspectId, 2.4, true);
        } else {
          pushChat(checker, "برگشتم... فیلم‌ها چیز خاصی نشون نمیدن 📷😕");
        }
      } else if (camLog.length === 0) {
        pushChat(checker, "برگشتم... دوربین‌ها قطع بودن! خیلی مشکوکه 📷✖😠");
      } else {
        const entry = camLog[0];
        pushChat(
          checker,
          `برگشتم! 📷 آخرین تصویر: «${entry.name}» توی «${entry.room}». مدرک قطعی نیست ولی...`,
        );
        if (entry.id !== 0 || Math.random() < 0.4) shiftOpinions(entry.id, 0.8, false);
      }
    }, 13000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- timers ----------------------------------------------------------------
  useEffect(() => {
    if (phase === "reveal" || phase === "blackout") return;
    const iv = setInterval(() => setTimer((t) => Math.max(0, t - 1)), 1000);
    return () => clearInterval(iv);
  }, [phase]);

  useEffect(() => {
    if (timer > 0) return;
    if (phase === "discuss") {
      setPhase("vote");
      setTimer(VOTE_TIME);
      sfx.click();
    } else if (phase === "vote") {
      finishVoting();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timer]);

  // ---- bot voting (suspicion-driven) ------------------------------------------
  const decideBotVote = useCallback(
    (bot: PlayerInfo): number | -1 => {
      const s = suspRef.current[bot.id] ?? {};
      let bestId: number | null = null;
      let bestScore = 0;
      for (const t of alive) {
        if (t.id === bot.id) continue;
        const sc = s[t.id] ?? 0;
        if (sc > bestScore) {
          bestScore = sc;
          bestId = t.id;
        }
      }
      // betrayed bot always votes the player
      if (grudges.includes(bot.id) && me.alive && Math.random() < 0.85) return 0;
      // personality-adjusted decision threshold:
      // aggressive bots vote on weaker evidence, cowards demand certainty
      const pers = seed.personalities[bot.id] ?? { aggression: 0.5, bravery: 0.5, label: "" };
      const threshold = 1.5 * (1.15 - pers.aggression * 0.5) * (pers.bravery < 0.35 ? 1.35 : 1);
      if (bot.isImpostor) {
        // deflect: vote a crew member, preferably the current scapegoat
        if (bestId !== null && bestId !== bot.id && !players.find((p) => p.id === bestId)?.isImpostor && bestScore > 1)
          return bestId;
        const crew = alive.filter((p) => p.id !== bot.id && !p.isImpostor);
        if (crew.length && Math.random() < 0.4 + pers.aggression * 0.4)
          return crew[Math.floor(Math.random() * crew.length)].id;
        return -1;
      }
      if (bestId !== null && bestScore >= threshold) return bestId;
      // without real evidence: cautious bots skip, aggressive ones guess
      if (Math.random() < pers.aggression * 0.45) {
        const targets = alive.filter((p) => p.id !== bot.id);
        if (targets.length) return targets[Math.floor(Math.random() * targets.length)].id;
      }
      return -1;
    },
    [alive, players, grudges, me.alive, seed.personalities],
  );

  useEffect(() => {
    if (phase !== "vote") return;
    const bots = alive.filter((p) => p.isBot);
    const timers = bots.map((bot) => {
      const delay = 2500 + Math.random() * 16000;
      return setTimeout(() => {
        setBotVotes((v) => {
          if (v[bot.id] !== undefined) return v;
          sfx.click();
          return { ...v, [bot.id]: decideBotVote(bot) };
        });
      }, delay);
    });
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  // all voted -> finish early
  useEffect(() => {
    if (phase !== "vote") return;
    const botCount = alive.filter((p) => p.isBot).length;
    const meDone = !canVote || myVote !== null;
    if (Object.keys(botVotes).length >= botCount && meDone) {
      const t = setTimeout(finishVoting, 900);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botVotes, myVote, phase]);

  // ---- opinion shifting -------------------------------------------------------
  const shiftOpinions = useCallback(
    (targetId: number, amount: number, sourceCredible: boolean) => {
      for (const b of alive.filter((p) => p.isBot)) {
        const s = suspRef.current[b.id];
        if (!s || targetId === b.id) continue;
        const w = (sourceCredible ? 1 : 0.6) * (0.7 + Math.random() * 0.6);
        s[targetId] = (s[targetId] ?? 0) + amount * w;
      }
      // reactions + live vote changes
      const reactors = alive.filter((p) => p.isBot && p.id !== targetId);
      const reactor = reactors[Math.floor(Math.random() * reactors.length)];
      if (reactor && amount > 0) {
        const sc = suspRef.current[reactor.id]?.[targetId] ?? 0;
        setTimeout(() => {
          pushChat(
            reactor,
            sc > 1.6
              ? `آره! ${name(targetId)} واقعاً مشکوک می‌زنه! 😠`
              : `مطمئنی؟ ${name(targetId)}؟ 🤨`,
          );
        }, 700 + Math.random() * 800);
      }
      // EVERYONE can defend: the accused bot fights back!
      const accused = players.find((p) => p.id === targetId);
      if (accused?.alive && accused.isBot && amount > 0.5) {
        setTimeout(() => {
          const defLines = accused.isImpostor
            ? [
                `دروغ محضه!! من تمام مدت داشتم وظیفه انجام می‌دادم! 😡 اتفاقاً خودِ تو مشکوکی!`,
                `چه مدرکی داری؟؟ هیچی! داری جلسه رو منحرف می‌کنی! 🎭`,
              ]
            : [
                `من بی‌گناهم!! چند نفر منو موقع وظیفه دیدن! 🛡`,
                `این تهمته! من هیچ ربطی به این قضیه ندارم! 😤`,
              ];
          pushChat(accused, defLines[Math.floor(Math.random() * defLines.length)]);
          // a good defense lowers suspicion in some bots
          for (const b of alive.filter((p) => p.isBot && p.id !== targetId)) {
            const s = suspRef.current[b.id];
            if (s && Math.random() < (accused.isImpostor ? 0.55 : 0.45)) {
              s[targetId] = Math.max(0, (s[targetId] ?? 0) - 0.7);
            }
          }
          // impostors counter-accuse the accuser (the player)
          if (accused.isImpostor && me.alive && Math.random() < 0.5) {
            for (const b of alive.filter((p) => p.isBot && p.id !== targetId)) {
              const s = suspRef.current[b.id];
              if (s) s[0] = (s[0] ?? 0) + 0.6;
            }
          }
        }, 1600 + Math.random() * 700);
      }
      // bots already voted may change their vote — once each
      if (phaseRef.current === "vote") {
        setTimeout(() => {
          setBotVotes((v) => {
            const next = { ...v };
            let changed = false;
            for (const b of alive.filter((p) => p.isBot)) {
              if (next[b.id] === undefined) continue;
              if (changedRef.current.has(b.id) || bribedRef.current.has(b.id)) continue;
              const s = suspRef.current[b.id] ?? {};
              const cur = next[b.id];
              const curScore = cur === -1 ? 0.8 : s[cur] ?? 0;
              const newScore = s[targetId] ?? 0;
              if (
                targetId !== b.id &&
                cur !== targetId &&
                newScore > curScore + 0.5 &&
                Math.random() < 0.6
              ) {
                next[b.id] = targetId;
                changedRef.current.add(b.id);
                changed = true;
                pushChat(b, `نظرم عوض شد... به ${name(targetId)} رأی می‌دهم! 🔄`);
              }
            }
            return changed ? next : v;
          });
        }, 1200 + Math.random() * 900);
      }
    },
    [alive, name, pushChat],
  );

  // ---- player chat actions ------------------------------------------------------
  const doAccuse = (targetId: number) => {
    if (msgsLeft <= 0) return;
    setMsgsLeft((m) => m - 1);
    setPickMode(null);
    pushChat(me, `من به ${name(targetId)} مشکوکم! رفتارش عجیب بود! 🫵`);
    onClaim(0, targetId, "accusation");
    shiftOpinions(targetId, 0.9, true);
  };

  const doFrame = (targetId: number) => {
    if (!onSpend(FRAME_COST)) return;
    setMyCoins((c) => c - FRAME_COST);
    setMsgsLeft((m) => Math.max(0, m - 1));
    setPickMode(null);
    pushChat(me, `با چشم خودم دیدم ${name(targetId)} بالای جسد ایستاده بود!! 🎭`);
    onClaim(0, targetId, "accusation");
    shiftOpinions(targetId, 1.9, true);
  };

  const doDefend = () => {
    if (msgsLeft <= 0 || defendedRef.current || myDefenses <= 0) return;
    if (!onConsumeDefense()) return;
    defendedRef.current = true;
    setMyDefenses((d) => d - 1);
    setMsgsLeft((m) => m - 1);
    pushChat(me, "من بی‌گناهم! تمام مدت داشتم وظیفه انجام می‌دادم! 🛡");
    for (const b of alive.filter((p) => p.isBot)) {
      const s = suspRef.current[b.id];
      if (s) s[0] = Math.max(0, (s[0] ?? 0) - 1.1 * (0.6 + Math.random() * 0.6));
    }
    const reactor = alive.filter((p) => p.isBot)[0];
    if (reactor)
      setTimeout(() => pushChat(reactor, "باشه... فعلاً حرفت رو قبول می‌کنم. 🤝"), 900);
  };

  const doBribe = (botId: number) => {
    if (!onSpend(BRIBE_COST)) return;
    setMyCoins((c) => c - BRIBE_COST);
    setPickMode(null);
    setBribed((s) => new Set(s).add(botId));
    const bot = players.find((p) => p.id === botId)!;
    pushChat(bot, `راستش... من به حرف ${me.name} کاملاً اعتماد دارم. 🤝`, false);
    // if already voted, it will be overridden at tally; show change
    if (botVotesRef.current[botId] !== undefined) {
      pushChat(bot, "رأیم را عوض می‌کنم... 🤫");
    }
  };

  const doDisrupt = () => {
    if (!onSpend(DISRUPT_COST)) return;
    setMyCoins((c) => c - DISRUPT_COST);
    setDisruptUsed(true);
    setPhase("blackout");
    sfx.sabotage();
    setTimeout(() => {
      onDone({ ejectedId: null, jailedId: null, votes: {}, disrupted: true });
    }, 1900);
  };

  // ---- finish -------------------------------------------------------------------
  function finishVoting() {
    if (doneRef.current) return;
    doneRef.current = true;
    const votes: Record<number, number | -1> = { ...botVotesRef.current };
    for (const b of alive.filter((p) => p.isBot)) {
      if (votes[b.id] === undefined) votes[b.id] = -1;
    }
    const mv = myVoteRef.current;
    if (canVote) votes[0] = mv === null ? -1 : mv;
    // bribed bots copy the player's vote
    for (const id of bribedRef.current) {
      if (votes[id] !== undefined) votes[id] = canVote ? (mv === null ? -1 : mv) : -1;
    }
    const tally = new Map<number | -1, number>();
    for (const v of Object.values(votes)) tally.set(v, (tally.get(v) ?? 0) + 1);
    let ejected: number | null = null;
    let best = 0;
    let tie = false;
    for (const [target, count] of tally) {
      if (count > best) {
        best = count;
        ejected = target === -1 ? null : (target as number);
        tie = false;
      } else if (count === best) tie = true;
    }
    if (tie) ejected = null;
    // absolute majority => eject; plurality only => prison!
    let jailedId: number | null = null;
    if (!tie && ejected !== null) {
      const cast = Object.keys(votes).length;
      const majority = Math.floor(cast / 2) + 1;
      if (best < majority) {
        jailedId = ejected;
        ejected = null;
      }
    }
    const res: MeetingResult = { ejectedId: ejected, jailedId, votes };
    setResult(res);
    setPhase("reveal");
    setTimeout(() => onDone(res), 4000);
  }

  const hasVoted = (id: number) => (id === 0 ? myVote !== null : botVotes[id] !== undefined);

  const votesFor = (target: number | -1): PlayerInfo[] => {
    if (!result) return [];
    return Object.entries(result.votes)
      .filter(([, v]) => v === target)
      .map(([voter]) => players.find((p) => p.id === Number(voter))!)
      .filter(Boolean);
  };

  // ---- blackout screen ------------------------------------------------------------
  if (phase === "blackout") {
    return (
      <div className="absolute inset-0 z-30 bg-black flex items-center justify-center">
        <div className="text-center anim-fadeUp">
          <div className="text-5xl mb-3">⚡</div>
          <div className="text-red-500 font-black text-2xl" style={{ textShadow: "0 0 24px rgba(255,0,0,.8)" }}>
            ارتباطات قطع شد!
          </div>
          <div className="text-white/50 font-bold text-sm mt-2">جلسه بهم خورد... هیچ‌کس اخراج نشد</div>
        </div>
      </div>
    );
  }

  const pickTargets =
    pickMode === "bribe"
      ? alive.filter((p) => p.isBot && !bribed.has(p.id))
      : alive.filter((p) => p.id !== 0);

  return (
    <div className="absolute inset-0 z-30 bg-[#0a1020]/95 flex items-center justify-center p-2">
      <div className="w-full max-w-3xl h-full max-h-[100dvh] flex flex-col rounded-2xl border-4 border-slate-500/60 bg-gradient-to-b from-slate-800 to-slate-900 shadow-2xl overflow-hidden anim-fadeUp">
        {/* header */}
        <div className="flex items-center justify-between px-4 py-2 bg-slate-950/70 border-b border-slate-600/50">
          <div className="text-white font-black text-xs sm:text-base">
            🚨 {meeting.reason === "body" ? "جسد گزارش شد!" : "جلسه اضطراری!"}
          </div>
          <div className="flex items-center gap-3">
            <span
              className={`font-black text-sm ${myVotesLeft > 0 ? "text-cyan-300" : "text-red-400"}`}
              title="ژتون رأی باقی‌مانده"
            >
              🗳×{myVotesLeft}
            </span>
            <span className="text-amber-300 font-black text-sm">🪙 {myCoins}</span>
            <span
              className={`font-black text-lg tabular-nums ${timer <= 5 ? "text-red-400" : "text-amber-300"}`}
            >
              {phase === "discuss" ? "💬" : phase === "vote" ? "🗳️" : "📊"}{" "}
              {phase === "reveal" ? "" : `${timer}s`}
            </span>
          </div>
        </div>

        {/* active bribe-deal reminder */}
        {deal && canVote && phase !== "reveal" && (
          <div className="px-3 py-1.5 bg-amber-950/70 border-b border-amber-600/40 text-amber-200 text-[11px] font-black text-center">
            🤝 قرارداد فعال: به «{name(deal.targetId)}» رأی بده وگرنه «{name(deal.botId)}» دشمنت
            می‌شود! ({deal.reward}🪙 گرفتی)
          </div>
        )}

        {/* forced elimination mission reminder */}
        {mission && canVote && phase !== "reveal" && (
          <div className="px-3 py-1.5 bg-red-950/80 border-b border-red-600/50 text-red-200 text-[11px] font-black text-center animate-pulse">
            🔪 مأموریت اجباری: کاری کن «{name(mission.targetId)}» حذف شود وگرنه «
            {name(mission.botId)}» تو را می‌کشد! (پاداش: {mission.reward}🪙)
          </div>
        )}

        {/* CCTV review panel */}
        {showCams && (
          <div className="px-3 py-2 bg-blue-950/60 border-b border-blue-500/40">
            <div className="flex items-center justify-between mb-1">
              <span className="text-blue-200 text-[11px] font-black">📷 آخرین تصاویر دوربین‌های مداربسته:</span>
              <button className="text-blue-300 text-xs font-black" onClick={() => setShowCams(false)}>
                ✕
              </button>
            </div>
            {camLog.length === 0 ? (
              <div className="text-red-300 text-[11px] font-bold">
                ✖ دوربین‌ها خاموش بودند... هیچ تصویری ثبت نشده! (خودش یک سرنخ است 🤔)
              </div>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {camLog.slice(0, 6).map((s) => (
                  <span
                    key={s.id}
                    className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-black/40 border border-blue-400/30 text-[10px] font-bold text-blue-100"
                  >
                    <span className="w-3 h-3 rounded-full border border-black/40" style={{ background: s.color }} />
                    {s.name} — {s.room} ({Math.round(s.secsAgo)}s قبل)
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex-1 flex flex-col sm:flex-row min-h-0">
          {/* player cards */}
          <div className="flex-1 overflow-y-auto scroll-y p-2 grid grid-cols-2 landscape:grid-cols-3 gap-1.5 content-start">
            {players.map((p) => {
              const isSel = selected === p.id;
              const clickable =
                phase === "vote" && canVote && myVote === null && p.alive && p.id !== 0 && !pickMode;
              const pickable = pickMode !== null && pickTargets.some((t) => t.id === p.id);
              return (
                <button
                  key={p.id}
                  disabled={!clickable && !pickable}
                  onClick={() => {
                    if (pickable) {
                      if (pickMode === "accuse") doAccuse(p.id);
                      else if (pickMode === "frame") doFrame(p.id);
                      else if (pickMode === "bribe") doBribe(p.id);
                      return;
                    }
                    setSelected(isSel ? null : p.id);
                  }}
                  className={`relative flex items-center gap-2 rounded-xl border-2 px-2 py-1.5 text-right transition-all ${
                    !p.alive
                      ? "bg-slate-950/60 border-slate-800 opacity-45"
                      : pickable
                        ? "bg-purple-900/50 border-purple-400 animate-pulse"
                        : isSel
                          ? "bg-red-900/50 border-red-400"
                          : "bg-slate-700/50 border-slate-500/60"
                  } ${clickable || pickable ? "active:scale-95" : ""}`}
                >
                  <Crewmate color={p.color} hat={p.hat} size={40} dead={!p.alive} />
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-bold text-sm truncate">
                      {p.id === 0 ? `${p.name} (شما)` : p.name}
                      {!p.alive && " 💀"}
                      {bribed.has(p.id) && " 🤝"}
                    </div>
                    {phase === "vote" && p.alive && hasVoted(p.id) && (
                      <div className="text-[10px] text-emerald-300 font-bold">✓ رأی داد</div>
                    )}
                    {phase === "reveal" && p.alive && (
                      <div className="flex gap-0.5 flex-wrap mt-0.5">
                        {votesFor(p.id).map((v) => (
                          <span
                            key={v.id}
                            className="w-3.5 h-3.5 rounded-full border border-black/40"
                            style={{ background: v.color }}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                  {isSel && phase === "vote" && myVote === null && !pickMode && (
                    <span className="absolute -left-1 -top-1 flex gap-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        className="w-8 h-8 rounded-full bg-emerald-500 text-white font-black border-2 border-white"
                        onClick={() => {
                          if (myVotesLeft <= 0) return;
                          if (!onConsumeVote()) return;
                          setMyVotesLeft((v) => v - 1);
                          setMyVote(p.id);
                          setSelected(null);
                          sfx.click();
                        }}
                      >
                        ✓
                      </button>
                      <button
                        className="w-8 h-8 rounded-full bg-rose-500 text-white font-black border-2 border-white"
                        onClick={() => setSelected(null)}
                      >
                        ✗
                      </button>
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* chat + actions */}
          <div className="sm:w-72 h-48 sm:h-auto flex flex-col border-t sm:border-t-0 sm:border-r border-slate-600/50 bg-slate-950/50">
            <div className="px-3 py-1 text-[11px] font-bold text-slate-300 border-b border-slate-700/60 flex justify-between items-center">
              <span>💬 گفتگوی خدمه</span>
              <span className="flex items-center gap-2">
                <button
                  className="px-2 py-0.5 rounded-lg bg-blue-800/80 text-blue-100 text-[10px] font-black border border-blue-500/50"
                  onClick={() => setShowCams((s) => !s)}
                >
                  📷 دوربین‌ها
                </button>
                {canVote && <span className="text-cyan-300">پیام: {msgsLeft}</span>}
              </span>
            </div>
            <div ref={chatRef} className="flex-1 overflow-y-auto scroll-y p-2 space-y-1.5">
              {chat.map((m) => (
                <div key={m.id} className="flex items-start gap-1.5 anim-fadeUp">
                  <span
                    className="mt-0.5 w-4 h-4 rounded-full border border-black/40 shrink-0"
                    style={{ background: m.from.color }}
                  />
                  <div className="text-[11px] leading-4">
                    <span className="font-black text-white/90">
                      {m.from.id === 0 ? "شما" : m.from.name}:{" "}
                    </span>
                    <span className="text-slate-200/90">{m.text}</span>
                  </div>
                </div>
              ))}
            </div>
            {/* action bar */}
            {canVote && phase !== "reveal" && (
              <div className="p-1.5 border-t border-slate-700/60 grid grid-cols-2 gap-1">
                {pickMode ? (
                  <button
                    className="col-span-2 py-1.5 rounded-lg bg-purple-700 text-white text-[11px] font-black border border-purple-400"
                    onClick={() => setPickMode(null)}
                  >
                    {pickMode === "bribe"
                      ? "🤝 یک ربات را برای خرید رأی انتخاب کن..."
                      : "🎯 هدف را از کارت‌ها انتخاب کن..."}{" "}
                    (لغو)
                  </button>
                ) : (
                  <>
                    <button
                      disabled={msgsLeft <= 0}
                      onClick={() => setPickMode("accuse")}
                      className="py-1.5 rounded-lg bg-red-800/80 text-red-100 text-[10px] font-black border border-red-500/50 disabled:opacity-40"
                    >
                      🫵 متهم کردن
                    </button>
                    <button
                      disabled={msgsLeft <= 0 || defendedRef.current || myDefenses <= 0}
                      onClick={doDefend}
                      className="py-1.5 rounded-lg bg-sky-800/80 text-sky-100 text-[10px] font-black border border-sky-500/50 disabled:opacity-40"
                    >
                      🛡 دفاع ({myDefenses} باقی)
                    </button>
                    {me.isImpostor && (
                      <button
                        disabled={myCoins < FRAME_COST || msgsLeft <= 0}
                        onClick={() => setPickMode("frame")}
                        className="py-1.5 rounded-lg bg-fuchsia-900/80 text-fuchsia-100 text-[10px] font-black border border-fuchsia-500/50 disabled:opacity-40"
                      >
                        🎭 شهادت دروغ ({FRAME_COST}🪙)
                      </button>
                    )}
                    <button
                      disabled={myCoins < BRIBE_COST}
                      onClick={() => setPickMode("bribe")}
                      className="py-1.5 rounded-lg bg-amber-800/80 text-amber-100 text-[10px] font-black border border-amber-500/50 disabled:opacity-40"
                    >
                      🤝 خرید رأی ({BRIBE_COST}🪙)
                    </button>
                    {me.isImpostor && (
                      <button
                        disabled={myCoins < DISRUPT_COST || disruptUsed}
                        onClick={doDisrupt}
                        className="py-1.5 rounded-lg bg-orange-900/90 text-orange-100 text-[10px] font-black border border-orange-500/60 disabled:opacity-40 col-span-2"
                      >
                        ⚡ بهم زدن جلسه ({DISRUPT_COST}🪙)
                      </button>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* footer */}
        <div className="px-3 py-2 bg-slate-950/70 border-t border-slate-600/50 flex items-center justify-between gap-2">
          <div className="text-[11px] text-slate-300 font-semibold">
            {!canVote
              ? "👻 شما مرده‌اید و نمی‌توانید رأی دهید"
              : phase === "discuss"
                ? "صحبت کن، متهم کن، رأی بخر... رأی‌گیری به‌زودی!"
                : phase === "vote"
                  ? myVote === null
                    ? myVotesLeft > 0
                      ? `روی یک بازیکن ضربه بزن و تأیید کن (🗳×${myVotesLeft})`
                      : "ژتون رأی نداری! فقط می‌توانی رد کردن رأی بدهی"
                    : myVote === -1
                      ? "شما رأی را رد کردید"
                      : `شما به ${name(myVote)} رأی دادید`
                  : result?.jailedId != null
                    ? `⛓ ${name(result.jailedId)} بازداشت می‌شود! (اکثریت مطلق نشد)`
                    : result?.ejectedId === null
                      ? "هیچ‌کس اخراج نمی‌شود (رأی کافی نبود)"
                      : `${name(result?.ejectedId ?? null)} اخراج می‌شود...`}
          </div>
          {phase === "vote" && canVote && myVote === null && (
            <button
              className="shrink-0 px-4 py-2 rounded-xl bg-slate-600 text-white text-xs font-black border-2 border-slate-400 active:scale-95"
              onClick={() => setMyVote(-1)}
            >
              رد کردن رأی
            </button>
          )}
          {phase === "reveal" && (
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-slate-400 font-bold">رد:</span>
              {votesFor(-1).map((v) => (
                <span
                  key={v.id}
                  className="w-3.5 h-3.5 rounded-full border border-black/40"
                  style={{ background: v.color }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
