import { useState } from "react";
import {
  applyOrientation,
  getSettings,
  saveSettings,
  OrientationPref,
  Quality,
  VoiceLang,
} from "../game/settings";
import { setVolume, speak } from "../game/sound";

/** shared settings controls — used in the main menu and the in-game pause menu */
export default function SettingsPanel({ onChanged }: { onChanged?: () => void }) {
  const [settings, setSettingsState] = useState(getSettings());
  const update = (patch: Parameters<typeof saveSettings>[0]) => {
    const next = saveSettings(patch);
    setSettingsState({ ...next });
    if (patch.volume !== undefined) setVolume(next.volume);
    onChanged?.();
  };

  return (
    <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm space-y-3 anim-fadeUp">
      <div>
        <div className="text-white/80 text-xs font-bold mb-1.5">🎨 کیفیت گرافیک</div>
        <div className="grid grid-cols-4 gap-1.5">
          {(
            [
              ["low", "کم"],
              ["medium", "متوسط"],
              ["high", "زیاد"],
              ["ultra", "فوق‌العاده"],
            ] as [Quality, string][]
          ).map(([q, lbl]) => (
            <button
              key={q}
              onClick={() => update({ quality: q })}
              className={`py-1.5 rounded-xl text-[11px] font-black border-2 ${
                settings.quality === q
                  ? "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="text-white/80 text-xs font-bold mb-1.5">🎞 نرخ فریم</div>
        <div className="grid grid-cols-2 gap-1.5">
          {([30, 60] as const).map((f) => (
            <button
              key={f}
              onClick={() => update({ fps: f })}
              className={`py-1.5 rounded-xl text-[11px] font-black border-2 ${
                settings.fps === f
                  ? "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              {f === 30 ? "۳۰ (باتری کمتر)" : "۶۰ (روان‌تر)"}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="text-white/80 text-xs font-bold mb-1">
          🔊 حجم صدا: {Math.round(settings.volume * 100)}٪
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(settings.volume * 100)}
          onChange={(e) => update({ volume: Number(e.target.value) / 100 })}
          className="w-full accent-cyan-400"
        />
      </div>
      <div>
        <div className="text-white/80 text-xs font-bold mb-1.5">🗣 زبان گوینده</div>
        <div className="grid grid-cols-2 gap-1.5">
          {(
            [
              ["en", "English 🇬🇧"],
              ["off", "خاموش 🔇"],
            ] as [VoiceLang, string][]
          ).map(([l, lbl]) => (
            <button
              key={l}
              onClick={() => {
                update({ voiceLang: l });
                if (l !== "off") speak("gameStart"); // instant preview
              }}
              className={`py-1.5 rounded-xl text-[11px] font-black border-2 ${
                settings.voiceLang === l
                  ? "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="text-white/80 text-xs font-bold mb-1.5">📱 جهت صفحه</div>
        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              ["auto", "خودکار 🔄"],
              ["portrait", "عمودی 📱"],
              ["landscape", "افقی 📺"],
            ] as [OrientationPref, string][]
          ).map(([o, lbl]) => (
            <button
              key={o}
              onClick={() => {
                update({ orientation: o });
                void applyOrientation(o);
              }}
              className={`py-1.5 rounded-xl text-[11px] font-black border-2 ${
                settings.orientation === o
                  ? "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="text-white/80 text-xs font-bold mb-1">
          🕹 اندازه اهرم حرکت: {settings.joySize}px
        </div>
        <input
          type="range"
          min={96}
          max={180}
          value={settings.joySize}
          onChange={(e) => update({ joySize: Number(e.target.value) })}
          className="w-full accent-cyan-400"
        />
      </div>
      <div className="text-white/35 text-[10px] text-center">
        تنظیمات به‌صورت خودکار ذخیره می‌شوند 💾
      </div>
    </div>
  );
}
