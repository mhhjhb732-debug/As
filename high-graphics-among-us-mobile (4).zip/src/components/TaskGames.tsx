import { useEffect, useMemo, useRef, useState } from "react";
import { sfx } from "../game/sound";

interface Props {
  kind: string;
  label: string;
  onDone: () => void;
  onCancel: () => void;
}

const WIRE_COLORS = ["#ef4444", "#3b82f6", "#eab308", "#ec4899"];

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------------------------------------------------------------- wires

function WiresGame({ onDone }: { onDone: () => void }) {
  const right = useMemo(() => shuffle([0, 1, 2, 3]), []);
  const [sel, setSel] = useState<number | null>(null);
  const [connected, setConnected] = useState<Set<number>>(new Set());
  const [shakeIdx, setShakeIdx] = useState(-1);

  const connect = (rightColor: number) => {
    if (sel === null) return;
    if (rightColor === sel) {
      const next = new Set(connected);
      next.add(sel);
      setConnected(next);
      setSel(null);
      sfx.click();
      if (next.size === 4) setTimeout(onDone, 350);
    } else {
      setShakeIdx(rightColor);
      setTimeout(() => setShakeIdx(-1), 300);
    }
  };

  return (
    <div className="flex justify-between gap-6 w-full max-w-sm" dir="ltr">
      <div className="flex flex-col gap-4">
        {[0, 1, 2, 3].map((c) => (
          <button
            key={c}
            onClick={() => !connected.has(c) && setSel(c)}
            className={`w-20 h-11 rounded-r-xl border-2 transition-all ${
              connected.has(c) ? "opacity-40" : sel === c ? "scale-110 border-white" : "border-black/40"
            }`}
            style={{ background: WIRE_COLORS[c], boxShadow: sel === c ? `0 0 16px ${WIRE_COLORS[c]}` : undefined }}
          />
        ))}
      </div>
      <div className="flex-1 flex items-center justify-center text-white/30 text-xs font-bold">
        {sel !== null ? "→ سر دیگر را بزن" : connected.size === 4 ? "✓" : "سیم را انتخاب کن"}
      </div>
      <div className="flex flex-col gap-4">
        {right.map((c) => (
          <button
            key={c}
            onClick={() => connect(c)}
            className={`w-20 h-11 rounded-l-xl border-2 border-black/40 transition-all ${
              connected.has(c) ? "opacity-40" : ""
            }`}
            style={{
              background: WIRE_COLORS[c],
              transform: shakeIdx === c ? "translateX(6px)" : undefined,
            }}
          />
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- targets

function TargetsGame({ onDone }: { onDone: () => void }) {
  const TOTAL = 7;
  const [hit, setHit] = useState(0);
  const [pos, setPos] = useState({ x: 50, y: 50 });

  useEffect(() => {
    setPos({ x: 15 + Math.random() * 70, y: 15 + Math.random() * 70 });
  }, [hit]);

  // target drifts
  useEffect(() => {
    const iv = setInterval(() => {
      setPos((p) => ({
        x: Math.max(8, Math.min(92, p.x + (Math.random() - 0.5) * 16)),
        y: Math.max(8, Math.min(92, p.y + (Math.random() - 0.5) * 16)),
      }));
    }, 700);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="relative w-full max-w-sm h-64 rounded-2xl bg-[#020617] border-2 border-cyan-500/30 overflow-hidden">
      {Array.from({ length: 20 }, (_, i) => (
        <div
          key={i}
          className="absolute w-0.5 h-0.5 rounded-full bg-white/50"
          style={{ left: `${(i * 37) % 100}%`, top: `${(i * 61) % 100}%` }}
        />
      ))}
      <button
        className="absolute -translate-x-1/2 -translate-y-1/2 text-4xl transition-all duration-300 active:scale-75"
        style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
        onPointerDown={() => {
          sfx.click();
          const h = hit + 1;
          setHit(h);
          if (h >= TOTAL) setTimeout(onDone, 250);
        }}
      >
        ☄️
      </button>
      <div className="absolute top-2 left-1/2 -translate-x-1/2 text-cyan-300 font-black text-sm">
        {hit} / {TOTAL} 🎯
      </div>
      {/* crosshair deco */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
        <div className="w-24 h-24 border border-cyan-400/20 rounded-full" />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- simon

const SIMON_COLORS = ["#ef4444", "#22c55e", "#3b82f6", "#eab308"];

function SimonGame({ onDone }: { onDone: () => void }) {
  const seq = useMemo(() => Array.from({ length: 4 }, () => Math.floor(Math.random() * 4)), []);
  const [showing, setShowing] = useState(true);
  const [flash, setFlash] = useState(-1);
  const [idx, setIdx] = useState(0);
  const [fail, setFail] = useState(false);
  const [round, setRound] = useState(0);

  useEffect(() => {
    setShowing(true);
    setIdx(0);
    let i = 0;
    const iv = setInterval(() => {
      if (i < seq.length) {
        setFlash(seq[i]);
        sfx.click();
        setTimeout(() => setFlash(-1), 380);
        i++;
      } else {
        clearInterval(iv);
        setShowing(false);
      }
    }, 620);
    return () => clearInterval(iv);
  }, [seq, round]);

  const press = (c: number) => {
    if (showing) return;
    setFlash(c);
    setTimeout(() => setFlash(-1), 200);
    if (c === seq[idx]) {
      sfx.click();
      const n = idx + 1;
      setIdx(n);
      if (n >= seq.length) setTimeout(onDone, 350);
    } else {
      setFail(true);
      setTimeout(() => {
        setFail(false);
        setRound((r) => r + 1);
      }, 700);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="text-white/70 text-xs font-bold h-4">
        {fail ? "❌ اشتباه! دوباره نگاه کن..." : showing ? "👀 الگو را حفظ کن..." : `تکرار کن! ${idx}/${seq.length}`}
      </div>
      <div className="grid grid-cols-2 gap-3">
        {SIMON_COLORS.map((col, i) => (
          <button
            key={i}
            onPointerDown={() => press(i)}
            className="w-24 h-24 rounded-2xl border-2 border-black/50 transition-all"
            style={{
              background: col,
              opacity: flash === i ? 1 : 0.35,
              boxShadow: flash === i ? `0 0 26px ${col}` : undefined,
              transform: flash === i ? "scale(1.06)" : undefined,
            }}
          />
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- hold

function HoldGame({ onDone, label }: { onDone: () => void; label: string }) {
  const [fill, setFill] = useState(0);
  const holding = useRef(false);
  const doneRef = useRef(false);

  useEffect(() => {
    const iv = setInterval(() => {
      setFill((f) => {
        if (!holding.current) return Math.max(0, f - 0.008);
        const n = f + 0.016;
        if (n >= 1 && !doneRef.current) {
          doneRef.current = true;
          setTimeout(onDone, 300);
        }
        return Math.min(1, n);
      });
    }, 40);
    return () => clearInterval(iv);
  }, [onDone]);

  return (
    <div className="flex flex-col items-center gap-5 w-full max-w-xs">
      <div className="w-full h-40 rounded-2xl bg-black/60 border-2 border-amber-500/40 relative overflow-hidden">
        <div
          className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-amber-500 to-yellow-300 transition-all"
          style={{ height: `${fill * 100}%` }}
        />
        <div className="absolute inset-0 flex items-center justify-center text-white font-black text-2xl drop-shadow">
          {Math.round(fill * 100)}٪
        </div>
      </div>
      <button
        onPointerDown={() => (holding.current = true)}
        onPointerUp={() => (holding.current = false)}
        onPointerLeave={() => (holding.current = false)}
        className="px-10 py-5 rounded-2xl bg-amber-500 text-black font-black text-lg border-4 border-amber-200 active:scale-95 select-none"
        style={{ touchAction: "none" }}
      >
        ⛽ نگه دار — {label}
      </button>
    </div>
  );
}

// ---------------------------------------------------------------- download

function DownloadGame({ onDone }: { onDone: () => void }) {
  const [started, setStarted] = useState(false);
  const [prog, setProg] = useState(0);

  useEffect(() => {
    if (!started) return;
    const iv = setInterval(() => {
      setProg((p) => {
        const n = p + 0.012 + Math.random() * 0.02;
        if (n >= 1) {
          clearInterval(iv);
          setTimeout(onDone, 400);
          return 1;
        }
        return n;
      });
    }, 60);
    return () => clearInterval(iv);
  }, [started, onDone]);

  return (
    <div className="w-full max-w-xs rounded-2xl bg-[#03170d] border-2 border-emerald-500/40 p-4 font-mono" dir="ltr">
      <div className="text-emerald-400 text-xs mb-2">&gt; SKELD_OS v4.2 — data transfer</div>
      {!started ? (
        <button
          onClick={() => {
            setStarted(true);
            sfx.click();
          }}
          className="w-full py-4 rounded-xl bg-emerald-500 text-black font-black text-base active:scale-95"
        >
          ▶ شروع انتقال
        </button>
      ) : (
        <>
          <div className="h-4 rounded bg-black/70 border border-emerald-400/40 overflow-hidden mb-2">
            <div className="h-full bg-emerald-400" style={{ width: `${prog * 100}%` }} />
          </div>
          <div className="text-emerald-300 text-xs">
            {Math.round(prog * 100)}% — {(prog * 87.4).toFixed(1)} MB / 87.4 MB
          </div>
          <div className="text-emerald-600 text-[10px] mt-1 h-3 overflow-hidden">
            {prog < 1 ? `packet_${Math.floor(prog * 900)}.bin ✓` : "TRANSFER COMPLETE ✓"}
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- path (chart course)

function PathGame({ onDone }: { onDone: () => void }) {
  const points = useMemo(
    () => [
      { x: 12, y: 70 },
      { x: 38, y: 30 },
      { x: 62, y: 62 },
      { x: 88, y: 25 },
    ],
    [],
  );
  const [next, setNext] = useState(0);

  return (
    <div className="relative w-full max-w-sm h-64 rounded-2xl bg-[#020b1c] border-2 border-blue-500/40 overflow-hidden">
      <svg className="absolute inset-0 w-full h-full">
        {points.map((_, i) =>
          i < next - 1 ? (
            <line
              key={i}
              x1={`${points[i].x}%`}
              y1={`${points[i].y}%`}
              x2={`${points[i + 1].x}%`}
              y2={`${points[i + 1].y}%`}
              stroke="#38bdf8"
              strokeWidth="2"
              strokeDasharray="5 4"
            />
          ) : null,
        )}
      </svg>
      {points.map((p, i) => (
        <button
          key={i}
          onClick={() => {
            if (i === next) {
              sfx.click();
              const n = next + 1;
              setNext(n);
              if (n >= points.length) setTimeout(onDone, 350);
            }
          }}
          className={`absolute -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full border-2 font-black text-sm transition-all ${
            i < next
              ? "bg-emerald-500 border-emerald-200 text-black"
              : i === next
                ? "bg-blue-500 border-white text-white animate-pulse scale-110"
                : "bg-slate-800 border-slate-600 text-slate-400"
          }`}
          style={{ left: `${p.x}%`, top: `${p.y}%` }}
        >
          {i + 1}
        </button>
      ))}
      <div className="absolute top-2 right-3 text-blue-300 text-xs font-bold">🚀 نقاط مسیر را به ترتیب بزن</div>
    </div>
  );
}

// ---------------------------------------------------------------- align (needle timing)

function AlignGame({ onDone }: { onDone: () => void }) {
  const [val, setVal] = useState(0);
  const [hits, setHits] = useState(0);
  const [flash, setFlash] = useState<"ok" | "bad" | null>(null);
  const tRef = useRef(0);

  useEffect(() => {
    let raf: number;
    const tick = () => {
      tRef.current += 0.035;
      setVal(Math.sin(tRef.current * 2.1));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const tryLock = () => {
    if (Math.abs(val) < 0.18) {
      sfx.click();
      setFlash("ok");
      const h = hits + 1;
      setHits(h);
      if (h >= 2) setTimeout(onDone, 350);
    } else {
      setFlash("bad");
    }
    setTimeout(() => setFlash(null), 300);
  };

  return (
    <div className="flex flex-col items-center gap-5 w-full max-w-xs">
      <div className="text-white/70 text-xs font-bold">عقربه را در ناحیه سبز ثبت کن ({hits}/۲)</div>
      <div
        className={`relative w-full h-16 rounded-xl border-2 overflow-hidden transition-colors ${
          flash === "ok" ? "border-emerald-400 bg-emerald-950" : flash === "bad" ? "border-red-500 bg-red-950" : "border-slate-500 bg-black/60"
        }`}
      >
        <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[14%] bg-emerald-500/30 border-x border-emerald-400/60" />
        <div
          className="absolute top-1 bottom-1 w-1.5 rounded bg-cyan-300"
          style={{ left: `calc(50% + ${val * 44}% - 3px)`, boxShadow: "0 0 10px #22d3ee" }}
        />
      </div>
      <button
        onPointerDown={tryLock}
        className="px-12 py-4 rounded-2xl bg-cyan-500 text-black font-black text-lg border-4 border-cyan-200 active:scale-95"
      >
        🎯 ثبت
      </button>
    </div>
  );
}

// ---------------------------------------------------------------- fix lights

function FixLightsGame({ onDone }: { onDone: () => void }) {
  const [sw, setSw] = useState([false, false, false, false, false]);
  const flip = (i: number) => {
    sfx.click();
    const n = [...sw];
    n[i] = !n[i];
    setSw(n);
    if (n.every(Boolean)) setTimeout(onDone, 400);
  };
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="text-yellow-200/80 text-xs font-bold animate-pulse">⚡ همه فیوزها را بالا بزن!</div>
      <div className="flex gap-3 p-4 rounded-2xl bg-[#1a1608] border-2 border-yellow-600/50">
        {sw.map((on, i) => (
          <button
            key={i}
            onClick={() => flip(i)}
            className="flex flex-col items-center gap-1"
          >
            <div
              className={`w-10 h-20 rounded-lg border-2 flex items-start justify-center p-1 transition-colors ${
                on ? "bg-yellow-500/30 border-yellow-400" : "bg-black/60 border-slate-600"
              }`}
            >
              <div
                className={`w-6 h-8 rounded transition-all ${on ? "bg-yellow-400 translate-y-0" : "bg-slate-500 translate-y-9"}`}
              />
            </div>
            <div className={`w-2.5 h-2.5 rounded-full ${on ? "bg-yellow-300" : "bg-slate-700"}`} style={on ? { boxShadow: "0 0 8px #fde047" } : undefined} />
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- fix reactor (two-hand hold!)

function FixReactorGame({ onDone }: { onDone: () => void }) {
  const [l, setL] = useState(false);
  const [r, setR] = useState(false);
  const [fill, setFill] = useState(0);
  const lRef = useRef(false);
  const rRef = useRef(false);
  const doneRef = useRef(false);

  useEffect(() => {
    const iv = setInterval(() => {
      setFill((f) => {
        if (lRef.current && rRef.current) {
          const n = f + 0.02;
          if (n >= 1 && !doneRef.current) {
            doneRef.current = true;
            setTimeout(onDone, 300);
          }
          return Math.min(1, n);
        }
        return Math.max(0, f - 0.015);
      });
    }, 40);
    return () => clearInterval(iv);
  }, [onDone]);

  const setSide = (side: "l" | "r", val: boolean) => {
    if (side === "l") {
      setL(val);
      lRef.current = val;
    } else {
      setR(val);
      rRef.current = val;
    }
  };

  const handCls = (active: boolean) =>
    `w-28 h-36 rounded-2xl border-4 text-5xl transition-all select-none ${
      active ? "bg-emerald-600 border-emerald-300 scale-95" : "bg-red-900/60 border-red-500/60"
    }`;

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-sm">
      <div className="text-red-300 font-black text-sm animate-pulse">☢️ هر دو دست را همزمان نگه دار!</div>
      <div className="w-full h-4 rounded-full bg-black/70 border border-red-400/50 overflow-hidden">
        <div className="h-full bg-gradient-to-l from-emerald-400 to-lime-300" style={{ width: `${fill * 100}%` }} />
      </div>
      <div className="flex gap-6">
        {(["l", "r"] as const).map((side) => (
          <button
            key={side}
            className={handCls(side === "l" ? l : r)}
            style={{ touchAction: "none" }}
            onPointerDown={() => setSide(side, true)}
            onPointerUp={() => setSide(side, false)}
            onPointerCancel={() => setSide(side, false)}
            onPointerLeave={() => setSide(side, false)}
          >
            🖐️
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- shell

export default function TaskGame({ kind, label, onDone, onCancel }: Props) {
  const body = (() => {
    switch (kind) {
      case "wires":
        return <WiresGame onDone={onDone} />;
      case "targets":
        return <TargetsGame onDone={onDone} />;
      case "simon":
        return <SimonGame onDone={onDone} />;
      case "hold":
        return <HoldGame onDone={onDone} label="پر کن" />;
      case "download":
        return <DownloadGame onDone={onDone} />;
      case "path":
        return <PathGame onDone={onDone} />;
      case "align":
        return <AlignGame onDone={onDone} />;
      case "fix-lights":
        return <FixLightsGame onDone={onDone} />;
      case "fix-reactor":
        return <FixReactorGame onDone={onDone} />;
      default:
        return <HoldGame onDone={onDone} label="انجام بده" />;
    }
  })();

  const isFix = kind.startsWith("fix-");

  return (
    <div className="absolute inset-0 z-30 bg-black/70 flex items-center justify-center p-3">
      <div
        className={`w-full max-w-md rounded-3xl border-4 p-4 anim-fadeUp ${
          isFix ? "bg-[#1c0a0a] border-red-500/70" : "bg-slate-900 border-slate-500/70"
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div className={`font-black text-sm ${isFix ? "text-red-300" : "text-cyan-200"}`}>
            {isFix ? "🚨 " : "🛠 "}
            {label}
          </div>
          <button
            onClick={onCancel}
            className="px-3 py-1 rounded-lg bg-white/10 text-white/70 text-xs font-bold border border-white/20 active:scale-95"
          >
            ✕ انصراف
          </button>
        </div>
        <div className="flex justify-center pb-2">{body}</div>
        {!isFix && (
          <div className="text-center text-white/30 text-[10px] mt-2">
            ⚠️ حواست باشد — هنگام انجام وظیفه آسیب‌پذیری!
          </div>
        )}
      </div>
    </div>
  );
}
