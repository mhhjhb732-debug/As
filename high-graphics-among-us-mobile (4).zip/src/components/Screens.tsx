import { useMemo, useState } from "react";
import { COLORS, MAPS } from "../game/mapData";
import { HATS } from "../game/world";
import { GameOverData, PlayerInfo } from "../game/types";
import Crewmate from "./Crewmate";
import SettingsPanel from "./SettingsPanel";
import Guide from "./Guide";

export function StarField({ density = 70 }: { density?: number }) {
  const stars = useMemo(
    () =>
      Array.from({ length: density }, (_, i) => ({
        id: i,
        top: Math.random() * 100,
        size: 1 + Math.random() * 2.2,
        dur: 14 + Math.random() * 30,
        delay: -Math.random() * 40,
        op: 0.3 + Math.random() * 0.7,
      })),
    [density],
  );
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {stars.map((s) => (
        <div
          key={s.id}
          className="absolute rounded-full bg-white"
          style={{
            top: `${s.top}%`,
            left: 0,
            width: s.size,
            height: s.size,
            opacity: s.op,
            animation: `driftStar ${s.dur}s linear infinite`,
            animationDelay: `${s.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

// ------------------------------------------------------------------- menu

export interface LobbyConfig {
  botCount: number;
  impostorCount: number;
}

const STANDARD_LOBBY: LobbyConfig = { botCount: 9, impostorCount: 2 };

export function MenuScreen({
  onStart,
}: {
  onStart: (
    colorIdx: number,
    forceRole: "auto" | "crew" | "impostor",
    hat: string,
    mapIdx: number,
    lobby: LobbyConfig,
  ) => void;
}) {
  const [colorIdx, setColorIdx] = useState(0);
  const [role, setRole] = useState<"auto" | "crew" | "impostor">("auto");
  const [hat, setHat] = useState("none");
  const [mapIdx, setMapIdx] = useState(0);
  const [mode, setMode] = useState<"standard" | "custom">("standard");
  const [botCount, setBotCount] = useState(7);
  const [impostorCount, setImpostorCount] = useState(1);
  // crew must outnumber impostors: max 3 or ⌊total/3⌋
  const maxImp = Math.min(3, Math.floor((botCount + 1) / 3));
  const effImp = Math.min(impostorCount, maxImp);
  const lobby: LobbyConfig =
    mode === "standard" ? STANDARD_LOBBY : { botCount, impostorCount: effImp };
  const [showSettings, setShowSettings] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  return (
    <div className="absolute inset-0 bg-gradient-to-b from-[#050914] via-[#0a1230] to-[#050914] flex flex-col items-center overflow-y-auto scroll-y">
      <StarField />
      <div className="relative z-10 flex flex-col items-center gap-3 p-4 pb-8 w-full max-w-md my-auto">
        <div style={{ animation: "floatY 3.5s ease-in-out infinite" }}>
          <Crewmate color={COLORS[colorIdx].hex} hat={hat} size={110} />
        </div>
        <h1
          className="text-4xl sm:text-5xl font-black text-white tracking-tight"
          style={{ textShadow: "0 0 24px rgba(90,180,255,.7), 3px 3px 0 #b91c1c" }}
        >
          در میان ما
        </h1>
        <p className="text-cyan-200/80 text-sm font-semibold -mt-2">
          نسخه سه‌بعدی اول‌شخص — یک خائن در میان ماست...
        </p>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm">
          <div className="text-white/80 text-xs font-bold mb-2">🎨 رنگ خود را انتخاب کنید</div>
          <div className="grid grid-cols-5 gap-2">
            {COLORS.map((c, i) => (
              <button
                key={c.hex}
                onClick={() => setColorIdx(i)}
                className={`h-12 rounded-xl border-2 transition-all active:scale-90 ${
                  i === colorIdx ? "border-white scale-105 shadow-lg" : "border-white/20"
                }`}
                style={{ background: c.hex }}
                aria-label={c.name}
              />
            ))}
          </div>
          <div className="text-center text-white font-bold text-sm mt-2">{COLORS[colorIdx].name}</div>
        </div>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm">
          <div className="text-white/80 text-xs font-bold mb-2">👑 کلاه خود را انتخاب کنید</div>
          <div className="grid grid-cols-7 gap-1.5">
            {HATS.map((h) => (
              <button
                key={h.id}
                onClick={() => setHat(h.id)}
                className={`flex flex-col items-center justify-center rounded-xl border-2 py-1.5 transition-all active:scale-90 ${
                  hat === h.id ? "border-amber-300 bg-amber-400/20 scale-105" : "border-white/15 bg-white/5"
                }`}
              >
                {h.id === "none" ? (
                  <span className="h-8 flex items-center text-lg opacity-60">🚫</span>
                ) : (
                  <Crewmate color={COLORS[colorIdx].hex} hat={h.id} size={32} />
                )}
                <span className="text-[9px] text-white/70 font-bold mt-0.5">{h.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm">
          <div className="text-white/80 text-xs font-bold mb-2">🗺 نقشه</div>
          <div className="grid grid-cols-3 gap-2">
            {MAPS.map((m, i) => (
              <button
                key={m.id}
                onClick={() => setMapIdx(i)}
                className={`py-2 px-1 rounded-xl border-2 transition-all ${
                  mapIdx === i
                    ? "bg-indigo-500/40 border-indigo-300"
                    : "bg-white/5 border-white/15"
                }`}
              >
                <div className={`text-sm font-black ${mapIdx === i ? "text-white" : "text-white/70"}`}>
                  {i === 0 ? "🚀" : i === 1 ? "🏢" : "❄️"} {m.name}
                </div>
                <div className="text-[9px] text-white/45 font-semibold mt-0.5 leading-3">{m.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm">
          <div className="text-white/80 text-xs font-bold mb-2">👥 ترکیب بازیکنان</div>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <button
              onClick={() => setMode("standard")}
              className={`py-2 rounded-xl text-xs font-black border-2 transition-all ${
                mode === "standard"
                  ? "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              استاندارد ⭐
            </button>
            <button
              onClick={() => setMode("custom")}
              className={`py-2 rounded-xl text-xs font-black border-2 transition-all ${
                mode === "custom"
                  ? "bg-purple-500 text-white border-purple-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              سفارشی 🛠
            </button>
          </div>
          {mode === "standard" ? (
            <div className="flex items-center justify-center gap-3 py-1 text-xs font-black">
              <span className="px-3 py-1 rounded-full bg-cyan-950/60 text-cyan-200 border border-cyan-400/30">
                🧑‍🚀 ۱۰ بازیکن
              </span>
              <span className="px-3 py-1 rounded-full bg-emerald-950/60 text-emerald-200 border border-emerald-400/30">
                🛡 ۸ خدمه
              </span>
              <span className="px-3 py-1 rounded-full bg-red-950/60 text-red-300 border border-red-400/30">
                🔪 ۲ خائن
              </span>
            </div>
          ) : (
            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-[11px] font-bold mb-0.5">
                  <span className="text-white/80">🤖 تعداد ربات‌ها</span>
                  <span className="text-cyan-300">{botCount} ربات + شما = {botCount + 1} بازیکن</span>
                </div>
                <input
                  type="range"
                  min={4}
                  max={9}
                  value={botCount}
                  onChange={(e) => setBotCount(Number(e.target.value))}
                  className="w-full accent-cyan-400"
                />
              </div>
              <div>
                <div className="flex justify-between text-[11px] font-bold mb-0.5">
                  <span className="text-white/80">🔪 تعداد خائن‌ها</span>
                  <span className="text-red-300">
                    {effImp} خائن / {botCount + 1 - effImp} خدمه
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={maxImp}
                  value={effImp}
                  onChange={(e) => setImpostorCount(Number(e.target.value))}
                  className="w-full accent-red-400"
                />
                {maxImp < 3 && (
                  <div className="text-white/35 text-[9px] mt-0.5">
                    برای خائن بیشتر، بازیکن بیشتری اضافه کن (خدمه باید حداقل ۲ برابر باشند)
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 backdrop-blur-sm">
          <div className="text-white/80 text-xs font-bold mb-2">🎭 نقش</div>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["auto", "شانسی 🎲"],
                ["crew", "خدمه 🧑‍🚀"],
                ["impostor", "خائن 🔪"],
              ] as const
            ).map(([k, label]) => (
              <button
                key={k}
                onClick={() => setRole(k)}
                className={`py-2 rounded-xl text-xs font-black border-2 transition-all ${
                  role === k
                    ? "bg-cyan-500 text-black border-cyan-200"
                    : "bg-white/5 text-white/70 border-white/15"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="w-full grid grid-cols-2 gap-2">
          <button
            onClick={() => setShowSettings((s) => !s)}
            className="py-2.5 rounded-2xl bg-white/5 border border-white/15 text-white/80 text-sm font-black active:scale-95"
          >
            ⚙️ تنظیمات {showSettings ? "▲" : "▼"}
          </button>
          <button
            onClick={() => setShowGuide(true)}
            className="py-2.5 rounded-2xl bg-indigo-600/40 border border-indigo-400/40 text-indigo-100 text-sm font-black active:scale-95"
          >
            📖 راهنمای بازی
          </button>
        </div>
        {showSettings && <SettingsPanel />}

        <button
          onClick={() => onStart(colorIdx, role, hat, mapIdx, lobby)}
          className="w-full py-4 rounded-2xl bg-gradient-to-l from-red-600 to-rose-500 text-white text-xl font-black border-2 border-rose-300 shadow-xl shadow-rose-900/50 active:scale-95 transition-all"
        >
          🚀 شروع بازی
        </button>

        <div className="w-full rounded-2xl bg-white/5 border border-white/15 p-3 text-[11px] leading-5 text-white/60 font-semibold">
          <span className="text-white/85 font-black">✨ امکانات:</span> مینی‌گیم‌های واقعی برای وظایف
          🛠 | مأموریت‌های چندمرحله‌ای 🔗 | خرابکاری: قطع برق و انفجار رآکتور ☢️ | صحبت و متهم‌کردن در
          جلسات 💬 | خرید رأی با سکه 🤝 | بهم زدن جلسه ⚡ | ضربان قلب وقتی قاتل نزدیک است 💓
        </div>
        <div className="text-white/40 text-[11px] leading-5 text-center">
          🕹️ اهرم چپ: حرکت | کشیدن صفحه: نگاه کردن | دکمه‌ها: استفاده / گزارش / کشتن
          <br />
          💻 روی رایانه: WASD + کشیدن ماوس
        </div>
      </div>
      {showGuide && <Guide onClose={() => setShowGuide(false)} />}
    </div>
  );
}

// ------------------------------------------------------------------ reveal

export function RevealScreen({
  isImpostor,
  players,
}: {
  isImpostor: boolean;
  players: PlayerInfo[];
}) {
  const impCount = Math.max(1, players.filter((pl) => pl.isImpostor).length);
  const fa = ["", "۱", "۲", "۳"][impCount] ?? String(impCount);
  return (
    <div
      className={`absolute inset-0 flex flex-col items-center justify-center ${
        isImpostor ? "bg-[#1a0505]" : "bg-[#03101f]"
      }`}
    >
      <StarField density={40} />
      <div className="relative z-10 text-center anim-fadeUp px-4">
        <div
          className={`text-4xl sm:text-6xl font-black mb-2 ${
            isImpostor ? "text-red-500" : "text-cyan-300"
          }`}
          style={{
            textShadow: isImpostor
              ? "0 0 30px rgba(255,40,40,.8)"
              : "0 0 30px rgba(80,200,255,.8)",
          }}
        >
          {isImpostor ? "خائن" : "خدمه"}
        </div>
        <div className="text-white/70 font-bold text-sm mb-6">
          {isImpostor
            ? impCount > 1
              ? `شما و ${["", "", "۱", "۲"][impCount]} هم‌دست‌تان — همه را بکشید بدون اینکه لو بروید!`
              : "همه را بکش، جسدها را پنهان کن و در رأی‌گیری زنده بمان!"
            : `در میان ما ${fa} خائن وجود دارد — وظایف را کامل کن!`}
        </div>
        <div className="flex justify-center items-end gap-1 flex-wrap max-w-md mx-auto">
          {players.map((p, i) => (
            <div key={p.id} style={{ animation: `floatY ${2.5 + (i % 3)}s ease-in-out infinite` }}>
              <Crewmate color={p.color} hat={p.hat} size={i === 0 ? 72 : 52} />
              <div className="text-center text-[10px] text-white/60 font-bold">
                {p.id === 0 ? "شما" : p.name}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------- eject

export function EjectScreen({
  ejected,
  jailed,
  wasImpostor,
  remainingImpostors,
}: {
  ejected: PlayerInfo | null;
  jailed: PlayerInfo | null;
  wasImpostor: boolean;
  remainingImpostors: number;
}) {
  if (jailed) {
    return (
      <div className="absolute inset-0 bg-[#0a0508] flex items-center justify-center overflow-hidden">
        <StarField density={40} />
        <div className="relative z-10 text-center px-6 anim-fadeUp">
          <div className="relative inline-block mb-4">
            <div style={{ animation: "floatY 3s ease-in-out infinite" }}>
              <Crewmate color={jailed.color} hat={jailed.hat} size={100} />
            </div>
            {/* bars overlay */}
            <div className="absolute inset-0 flex justify-between px-1 pointer-events-none">
              {Array.from({ length: 5 }, (_, i) => (
                <div key={i} className="w-1.5 bg-gradient-to-b from-slate-400 to-slate-600 rounded-full opacity-90" />
              ))}
            </div>
          </div>
          <div className="text-white text-xl sm:text-3xl font-black leading-relaxed" style={{ textShadow: "0 2px 12px #000" }}>
            ⛓ {jailed.id === 0 ? "شما" : jailed.name} به بازداشتگاه افتاد!
          </div>
          <div className="text-amber-200/70 font-bold text-sm mt-2">
            رأی اکثریت مطلق نشد — ۳۵ ثانیه حبس در سلول
          </div>
          <div className="text-white/40 font-bold text-xs mt-3">
            {remainingImpostors} خائن هنوز آزاد است...
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="absolute inset-0 bg-[#02040c] flex items-center justify-center overflow-hidden">
      <StarField density={90} />
      {ejected && (
        <div
          className="absolute"
          style={{ animation: "ejectDrift 4s linear forwards", top: "40%", left: "40%" }}
        >
          <Crewmate color={ejected.color} hat={ejected.hat} size={90} />
        </div>
      )}
      <div className="relative z-10 text-center px-6">
        <div className="text-white text-xl sm:text-3xl font-black leading-relaxed" style={{ textShadow: "0 2px 12px #000" }}>
          {ejected === null ? (
            <>هیچ‌کس اخراج نشد. (رد کردن رأی)</>
          ) : wasImpostor ? (
            <>
              {ejected.name} خائن بود. <span className="text-red-400">🔪</span>
            </>
          ) : (
            <>
              {ejected.name} خائن <span className="text-cyan-300">نبود</span>. 😢
            </>
          )}
        </div>
        <div className="text-white/50 font-bold text-sm mt-3">
          {remainingImpostors} خائن باقی مانده است
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- game over

export function GameOverScreen({
  data,
  players,
  onRestart,
}: {
  data: GameOverData;
  players: PlayerInfo[];
  onRestart: () => void;
}) {
  const impostors = players.filter((p) => data.impostorIds.includes(p.id));
  const msg =
    data.kind === "crew-tasks"
      ? "خدمه با تکمیل تمام وظایف پیروز شدند!"
      : data.kind === "crew-eject"
        ? "خائن به فضا پرتاب شد!"
        : data.kind === "impostor-sabotage"
          ? "☢️ رآکتور منفجر شد! خرابکاری موفق بود!"
          : "خائن همه خدمه را از بین برد!";
  return (
    <div
      className={`absolute inset-0 flex flex-col items-center justify-center ${
        data.playerWon ? "bg-[#03151f]" : "bg-[#1c0505]"
      }`}
    >
      <StarField density={50} />
      <div className="relative z-10 text-center anim-fadeUp px-4">
        <div
          className={`text-5xl sm:text-7xl font-black mb-3 ${
            data.playerWon ? "text-emerald-400" : "text-red-500"
          }`}
          style={{
            textShadow: data.playerWon
              ? "0 0 34px rgba(50,255,150,.7)"
              : "0 0 34px rgba(255,40,40,.7)",
          }}
        >
          {data.playerWon ? "پیروزی!" : "شکست"}
        </div>
        <div className="text-white/80 font-bold mb-6">{msg}</div>
        <div className="mb-2 text-white/50 text-xs font-bold">خائن:</div>
        <div className="flex justify-center gap-3 mb-8">
          {impostors.map((p) => (
            <div key={p.id} style={{ animation: "floatY 3s ease-in-out infinite" }}>
              <Crewmate color={p.color} hat={p.hat} size={84} />
              <div className="text-red-400 font-black text-sm mt-1">
                {p.id === 0 ? "شما" : p.name}
              </div>
            </div>
          ))}
        </div>
        <button
          onClick={onRestart}
          className="px-10 py-4 rounded-2xl bg-gradient-to-l from-cyan-500 to-blue-500 text-black text-lg font-black border-2 border-cyan-200 shadow-xl active:scale-95 transition-all"
        >
          🔁 بازی دوباره
        </button>
      </div>
    </div>
  );
}
