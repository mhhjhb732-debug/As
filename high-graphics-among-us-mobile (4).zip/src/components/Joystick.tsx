import { useRef, useState, useCallback } from "react";
import { isForcedLandscape } from "../game/settings";

interface Props {
  onMove: (x: number, y: number) => void; // normalized -1..1
  size?: number;
}

export default function Joystick({ onMove, size = 132 }: Props) {
  const baseRef = useRef<HTMLDivElement>(null);
  const idRef = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const R = size / 2;

  const update = useCallback(
    (clientX: number, clientY: number) => {
      const el = baseRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      // physical offset from the pad center…
      const px = clientX - (r.left + r.width / 2);
      const py = clientY - (r.top + r.height / 2);
      // …mapped into the (possibly CSS-rotated) app's local axes
      let dx = px;
      let dy = py;
      if (isForcedLandscape()) {
        dx = py;
        dy = -px;
      }
      const d = Math.hypot(dx, dy);
      const max = R * 0.72;
      if (d > max) {
        dx = (dx / d) * max;
        dy = (dy / d) * max;
      }
      setKnob({ x: dx, y: dy });
      onMove(dx / max, dy / max);
    },
    [onMove, R],
  );

  const end = useCallback(() => {
    idRef.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  }, [onMove]);

  return (
    <div
      ref={baseRef}
      className="relative rounded-full border-2 border-white/25 bg-white/10 backdrop-blur-sm"
      style={{ width: size, height: size, touchAction: "none" }}
      onPointerDown={(e) => {
        idRef.current = e.pointerId;
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        update(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (idRef.current === e.pointerId) update(e.clientX, e.clientY);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div className="absolute inset-0 flex items-center justify-center text-white/30 text-[10px] font-bold">
        حرکت
      </div>
      <div
        className="absolute rounded-full bg-white/70 shadow-lg shadow-black/40 border border-white/70"
        style={{
          width: size * 0.42,
          height: size * 0.42,
          left: R - size * 0.21 + knob.x,
          top: R - size * 0.21 + knob.y,
        }}
      />
    </div>
  );
}
