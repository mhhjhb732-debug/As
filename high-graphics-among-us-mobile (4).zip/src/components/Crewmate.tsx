interface Props {
  color: string;
  size?: number;
  dead?: boolean;
  hat?: string;
  className?: string;
}

function Hat({ hat }: { hat: string }) {
  switch (hat) {
    case "crown":
      return (
        <g>
          <path d="M36 12 L42 2 L50 10 L58 0 L66 10 L74 2 L80 12 L78 20 L38 20 Z" fill="#ffc93d" stroke="#a8760a" strokeWidth="2" />
          <circle cx="50" cy="15" r="2.6" fill="#ff2255" />
          <circle cx="66" cy="15" r="2.6" fill="#2563eb" />
        </g>
      );
    case "tophat":
      return (
        <g>
          <rect x="40" y="-8" width="34" height="20" rx="3" fill="#14151c" />
          <rect x="40" y="6" width="34" height="6" rx="3" fill="#b01030" />
          <rect x="32" y="10" width="50" height="6" rx="3" fill="#14151c" />
        </g>
      );
    case "cap":
      return (
        <g>
          <path d="M38 14 Q38 -2 57 -2 Q76 -2 76 14 Z" fill="#2563eb" stroke="#173c8f" strokeWidth="2" />
          <rect x="70" y="9" width="20" height="6" rx="3" fill="#2563eb" stroke="#173c8f" strokeWidth="1.5" />
        </g>
      );
    case "halo":
      return <ellipse cx="57" cy="-2" rx="17" ry="5.5" fill="none" stroke="#ffd83d" strokeWidth="4" opacity="0.95" />;
    case "horns":
      return (
        <g fill="#d91e1e" stroke="#7d0f0f" strokeWidth="1.5">
          <path d="M38 14 Q30 2 36 -4 Q42 4 44 12 Z" />
          <path d="M76 14 Q84 2 78 -4 Q72 4 70 12 Z" />
        </g>
      );
    case "antenna":
      return (
        <g>
          <line x1="57" y1="10" x2="57" y2="-6" stroke="#8a93a5" strokeWidth="2.5" />
          <circle cx="57" cy="-8" r="4.5" fill="#ff3b3b" stroke="#7d0f0f" strokeWidth="1.5" />
        </g>
      );
    default:
      return null;
  }
}

function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, Math.round(((n >> 16) & 255) * f)));
  const g = Math.min(255, Math.max(0, Math.round(((n >> 8) & 255) * f)));
  const b = Math.min(255, Math.max(0, Math.round((n & 255) * f)));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

export default function Crewmate({ color, size = 56, dead, hat = "none", className }: Props) {
  const dark = shade(color, 0.55);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      style={{ filter: dead ? "grayscale(.7) brightness(.6)" : undefined, overflow: "visible" }}
    >
      {/* backpack */}
      <rect x="8" y="34" width="18" height="34" rx="8" fill={dark} />
      {/* legs */}
      <rect x="30" y="72" width="16" height="22" rx="7" fill={color} stroke={dark} strokeWidth="3" />
      <rect x="56" y="72" width="16" height="22" rx="7" fill={color} stroke={dark} strokeWidth="3" />
      {/* body */}
      <path
        d="M28 88 L28 38 Q28 10 52 10 Q76 10 76 36 L76 88 Q76 94 68 94 L36 94 Q28 94 28 88 Z"
        fill={color}
        stroke={dark}
        strokeWidth="3.5"
      />
      {/* visor */}
      <rect x="46" y="24" width="36" height="22" rx="11" fill="#9fd7e8" stroke={shade("#9fd7e8", 0.6)} strokeWidth="3" />
      <rect x="52" y="28" width="18" height="7" rx="3.5" fill="#d8f3fb" opacity="0.9" />
      {dead && (
        <g stroke="#111" strokeWidth="4" strokeLinecap="round">
          <line x1="52" y1="28" x2="64" y2="40" />
          <line x1="64" y1="28" x2="52" y2="40" />
        </g>
      )}
      {!dead && <Hat hat={hat} />}
    </svg>
  );
}
