import { useEffect, useRef, useState } from "react";
import { HudState, SabKind, TalkKind } from "../game/types";
import { FIX_POINTS, RECTS, STATIONS } from "../game/mapData";
import { getSettings, mapDelta } from "../game/settings";
import Joystick from "./Joystick";

interface Props {
  hud: HudState;
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onUse: () => void;
  onReport: () => void;
  onKill: () => void;
  onSabotage: (kind: SabKind) => void;
  onSabotageCams: () => void;
  onWatchCams: () => void;
  onTalk: (kind: TalkKind) => string;
  onSit: () => void;
  onStand: () => void;
  onTableSay: (idx: number) => string;
  onPause: () => void;
}

function MiniMap({ hud, big }: { hud: HudState; big: boolean }) {
  // dynamic bounds — supports all three maps
  let MMX0 = Infinity,
    MMX1 = -Infinity,
    MMZ0 = Infinity,
    MMZ1 = -Infinity;
  for (const r of RECTS) {
    MMX0 = Math.min(MMX0, r.cx - r.w / 2);
    MMX1 = Math.max(MMX1, r.cx + r.w / 2);
    MMZ0 = Math.min(MMZ0, r.cz - r.d / 2);
    MMZ1 = Math.max(MMZ1, r.cz + r.d / 2);
  }
  MMX0 -= 1;
  MMX1 += 1;
  MMZ0 -= 1;
  MMZ1 += 1;
  const W = big ? 320 : 148;
  const H = (W * (MMZ1 - MMZ0)) / (MMX1 - MMX0);
  const sx = (x: number) => ((x - MMX0) / (MMX1 - MMX0)) * W;
  const sz = (z: number) => ((z - MMZ0) / (MMZ1 - MMZ0)) * H;
  const fix = hud.sabotage ? FIX_POINTS[hud.sabotage.kind] : null;
  return (
    <svg width={W} height={H} className="block">
      {RECTS.map((r) => (
        <rect
          key={r.id}
          x={sx(r.cx - r.w / 2)}
          y={sz(r.cz - r.d / 2)}
          width={(r.w / (MMX1 - MMX0)) * W}
          height={(r.d / (MMZ1 - MMZ0)) * H}
          rx={2}
          fill={r.room ? "rgba(110,140,190,0.35)" : "rgba(90,110,150,0.25)"}
          stroke="rgba(160,200,255,0.5)"
          strokeWidth="1"
        />
      ))}
      {!hud.isImpostor &&
        hud.tasks
          .filter((t) => !t.done && t.currentStationId)
          .map((t) => {
            const s = STATIONS.find((st) => st.id === t.currentStationId)!;
            return (
              <circle key={t.id} cx={sx(s.x)} cy={sz(s.z)} r={big ? 5 : 3} fill="#ffd34d">
                <animate attributeName="opacity" values="1;0.3;1" dur="1.2s" repeatCount="indefinite" />
              </circle>
            );
          })}
      {fix && (
        <circle cx={sx(fix.x)} cy={sz(fix.z)} r={big ? 7 : 5} fill="#ff2222">
          <animate attributeName="r" values={big ? "5;9;5" : "3;6;3"} dur="0.7s" repeatCount="indefinite" />
        </circle>
      )}
      {/* tiny room-name labels — always know where everything is */}
      {RECTS.filter((r) => r.room && r.name).map((r) => (
        <text
          key={`lbl-${r.id}`}
          x={sx(r.cx)}
          y={sz(r.cz) + (big ? 3 : 2)}
          textAnchor="middle"
          fontSize={big ? 10 : 5.5}
          fontWeight="700"
          fill={big ? "rgba(220,235,255,0.95)" : "rgba(210,228,255,0.85)"}
          style={{ paintOrder: "stroke", stroke: "rgba(0,0,0,0.75)", strokeWidth: big ? 2.5 : 1.6 }}
        >
          {r.name}
        </text>
      ))}
      <circle cx={sx(hud.playerPos.x)} cy={sz(hud.playerPos.z)} r={big ? 6 : 4} fill="#4dc8ff" stroke="#fff" strokeWidth="1.5" />
    </svg>
  );
}

export default function HUD({
  hud,
  onMove,
  onLook,
  onUse,
  onReport,
  onKill,
  onSabotage,
  onSabotageCams,
  onWatchCams,
  onTalk,
  onSit,
  onStand,
  onTableSay,
  onPause,
}: Props) {
  const lookId = useRef<number | null>(null);
  const last = useRef({ x: 0, y: 0 });
  const [showTasks, setShowTasks] = useState(true);
  const [bigMap, setBigMap] = useState(false);
  const [talkOpen, setTalkOpen] = useState(false);
  const [myLine, setMyLine] = useState<string | null>(null);

  const sendTalk = (kind: TalkKind) => {
    const line = onTalk(kind);
    setTalkOpen(false);
    if (line) {
      setMyLine(line);
      setTimeout(() => setMyLine(null), 2200);
    }
  };

  // bugfix: auto-close chat panel when the bot walks away / dies / meeting starts
  useEffect(() => {
    if (!hud.canTalk) setTalkOpen(false);
  }, [hud.canTalk]);

  const doneCount = hud.tasks.filter((t) => t.done).length;
  const sabReactor = hud.sabotage?.kind === "reactor";
  const sabLights = hud.sabotage?.kind === "lights";

  return (
    <div className="absolute inset-0 select-none" style={{ touchAction: "none" }}>
      {/* look layer */}
      <div
        className="absolute inset-0"
        onPointerDown={(e) => {
          if (lookId.current === null) {
            lookId.current = e.pointerId;
            last.current = { x: e.clientX, y: e.clientY };
          }
        }}
        onPointerMove={(e) => {
          if (lookId.current === e.pointerId) {
            const [dx, dy] = mapDelta(e.clientX - last.current.x, e.clientY - last.current.y);
            onLook(dx, dy);
            last.current = { x: e.clientX, y: e.clientY };
          }
        }}
        onPointerUp={(e) => {
          if (lookId.current === e.pointerId) lookId.current = null;
        }}
        onPointerCancel={(e) => {
          if (lookId.current === e.pointerId) lookId.current = null;
        }}
      />

      {/* fear vignette */}
      {hud.danger > 0.05 && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: `inset 0 0 ${60 + hud.danger * 120}px ${hud.danger * 60}px rgba(160,0,0,${
              0.25 + hud.danger * 0.45
            })`,
            animation: hud.danger > 0.5 ? "pulseGlow 0.8s infinite" : undefined,
          }}
        />
      )}

      {/* ======== TOP-CENTER column: progress → status pills → banners ======== */}
      <div className="absolute top-2 landscape:top-1 inset-x-0 flex flex-col items-center gap-1.5 landscape:gap-0.5 pointer-events-none z-10">
        {/* task progress */}
        <div className="w-[44%] landscape:w-[26%] max-w-sm">
          <div className="text-center text-[11px] font-bold text-emerald-200/90 drop-shadow mb-0.5 landscape:hidden">
            پیشرفت کل وظایف
          </div>
          <div className="h-3 landscape:h-2 rounded-full bg-black/50 border border-emerald-300/40 overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-emerald-400 to-lime-300 transition-all duration-500"
              style={{ width: `${Math.round(hud.taskProgress * 100)}%` }}
            />
          </div>
        </div>
        {/* room + coins pills */}
        <div className="flex items-center gap-2">
          <span className="px-3 py-0.5 rounded-full bg-black/45 text-cyan-100/90 text-xs font-bold border border-cyan-200/20">
            {hud.roomName}
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-950/60 text-amber-300 text-xs font-black border border-amber-400/30">
            🪙 {hud.coins}
          </span>
        </div>
        {/* REC badge — impostor on CCTV */}
        {hud.isImpostor && hud.onCamera && (
          <span className="px-3 py-1 rounded-lg bg-black/80 border-2 border-red-500 text-red-400 text-xs font-black animate-pulse">
            🔴 REC — در دید دوربین مداربسته!
          </span>
        )}
        {/* reactor meltdown banner */}
        {sabReactor && hud.sabotage && (
          <div className="px-5 py-2 rounded-2xl bg-red-950/85 border-2 border-red-500 text-center anim-shake">
            <div className="text-red-300 font-black text-sm">☢️ انفجار رآکتور!</div>
            <div className="text-red-100 font-black text-2xl tabular-nums">
              {Math.ceil(hud.sabotage.timeLeft)}
            </div>
            <div className="text-red-200/80 text-[10px] font-bold">سریع به رآکتور برو و خنکش کن!</div>
          </div>
        )}
        {/* lights out banner */}
        {sabLights && (
          <div className="px-5 py-1.5 rounded-2xl bg-black/80 border-2 border-yellow-500/70 text-center">
            <div className="text-yellow-300 font-black text-sm animate-pulse">💡 برق قطع شد!</div>
            <div className="text-yellow-100/70 text-[10px] font-bold">فیوزها در اتاق برق هستند...</div>
          </div>
        )}
        {/* ghost banner */}
        {hud.isGhost && (
          <span className="px-4 py-1 rounded-full bg-indigo-900/70 text-indigo-100 text-sm font-bold border border-indigo-300/40">
            👻 شما روح هستید — وظایف را ادامه بده...
          </span>
        )}
      </div>

      {/* jail banner */}
      {hud.jailTime > 0 && (
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 pointer-events-none z-10">
          <div className="px-6 py-3 rounded-2xl bg-black/80 border-2 border-amber-500/70 text-center anim-fadeUp">
            <div className="text-amber-300 font-black text-lg">⛓ شما در بازداشتگاه هستید</div>
            <div className="text-white font-black text-3xl tabular-nums mt-1">
              {Math.ceil(hud.jailTime)}
            </div>
            <div className="text-white/50 text-[10px] font-bold mt-1">
              تا آزادی... در سلول قدم بزن 🚶
            </div>
          </div>
        </div>
      )}

      {/* ======== TOP-RIGHT column: tasks → mission/murder badges ======== */}
      <div className="absolute top-2 landscape:top-1 right-2 z-10 flex flex-col items-end gap-1.5 landscape:gap-1 max-w-[48vw] landscape:max-w-[30vw] landscape:max-h-[80vh] landscape:overflow-y-auto scroll-y">
        <button
          className="px-3 py-1 rounded-lg bg-black/55 text-white text-xs font-bold border border-white/20"
          onClick={() => setShowTasks((s) => !s)}
        >
          {hud.isImpostor ? "🔪 مأموریت" : `📋 وظایف ${doneCount}/${hud.tasks.length}`}
        </button>
        {showTasks && (
          <div className="rounded-xl bg-black/55 border border-white/15 p-2 space-y-1 backdrop-blur-sm">
            {hud.isImpostor ? (
              <div className="text-red-300 text-[11px] font-bold leading-5 w-44">
                همه را بکش بدون اینکه دیده شوی!
                <br />
                <span className="text-orange-300">💡 قطع برق: شکار در تاریکی</span>
                <br />
                <span className="text-red-200/80">☢️ رآکتور: حواس‌ها را پرت کن</span>
              </div>
            ) : (
              hud.tasks.map((t) => (
                <div
                  key={t.id}
                  className={`text-[11px] font-semibold leading-4 ${
                    t.done ? "text-emerald-400 line-through opacity-60" : "text-amber-100"
                  }`}
                >
                  {t.done ? "✓" : "•"} {t.label}
                  {t.total > 1 && !t.done && (
                    <span className="text-cyan-300"> ({t.step}/{t.total})</span>
                  )}
                  {!t.done && (
                    <div className="text-[10px] text-white/50 pr-3">↤ {t.stepLabel}</div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
        {/* active elimination mission badge */}
        {hud.mission && !hud.isGhost && (
          <div className="px-2.5 py-1.5 rounded-xl bg-red-950/85 border border-red-500/60 text-[10px] font-black leading-4 pointer-events-none">
            <span className="text-red-300">🔪 مأموریت اجباری:</span>
            <span className="text-red-100"> حذف «{hud.mission.targetName}» در جلسه بعد</span>
            <div className="text-red-200/60">وگرنه «{hud.mission.botName}» تو را می‌کشد!</div>
          </div>
        )}
        {/* active murder-accomplice badge */}
        {hud.murderPlan && !hud.isGhost && (
          <div className="px-2.5 py-1.5 rounded-xl bg-purple-950/85 border border-purple-500/60 text-[10px] font-black leading-4 pointer-events-none">
            <span className="text-purple-300">😈 شریک جرم:</span>
            <span className="text-purple-100">
              {" "}
              «{hud.murderPlan.botName}» می‌خواهد «{hud.murderPlan.targetName}» را بکشد
            </span>
            <div className="text-purple-200/60">
              مراقب باش کسی نیاید... سهم تو: {hud.murderPlan.reward}🪙
            </div>
          </div>
        )}
      </div>

      {/* ======== TOP-LEFT column: pause → minimap → camera status ======== */}
      <div className="absolute top-2 left-2 landscape:top-1 z-10 flex flex-col items-start gap-1.5 landscape:scale-[0.8] landscape:origin-top-left">
        <div className="flex items-start gap-1.5">
          <button
            className="rounded-xl bg-black/50 border border-white/20 p-1.5 backdrop-blur-sm"
            onClick={() => setBigMap((b) => !b)}
          >
            <MiniMap hud={hud} big={false} />
          </button>
          {/* pause / stop button */}
          <button
            onPointerDown={(e) => {
              e.stopPropagation();
              onPause();
            }}
            className="w-10 h-10 rounded-xl bg-black/60 border-2 border-white/25 text-white text-base font-black active:scale-90 backdrop-blur-sm"
            aria-label="توقف بازی"
          >
            ⏸
          </button>
        </div>
        {hud.camerasDown > 0 && (
          <span className="px-2 py-0.5 rounded-lg bg-black/60 border border-slate-500/50 text-slate-300 text-[10px] font-bold pointer-events-none">
            📷✖ دوربین‌ها قطع ({Math.ceil(hud.camerasDown)}s)
          </span>
        )}
      </div>
      {bigMap && (
        <div
          className="absolute inset-0 bg-black/70 flex items-center justify-center z-20"
          onClick={() => setBigMap(false)}
        >
          <div className="rounded-2xl bg-slate-900/95 border border-cyan-300/30 p-4 anim-fadeUp">
            <div className="text-center text-cyan-100 font-bold mb-2 text-sm">🗺 نقشه سفینه</div>
            <MiniMap hud={hud} big={true} />
            <div className="text-center text-white/50 text-[11px] mt-2">برای بستن ضربه بزنید</div>
          </div>
        </div>
      )}

      {/* joystick (size from user settings; slightly smaller in landscape) */}
      {!hud.sitting && (
        <div
          className="absolute bottom-6 left-5 landscape:bottom-2 landscape:left-3 landscape:scale-90 landscape:origin-bottom-left"
          style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <Joystick onMove={onMove} size={getSettings().joySize} />
        </div>
      )}

      {/* my speech line */}
      {myLine && (
        <div className="absolute bottom-56 landscape:bottom-36 left-1/2 -translate-x-1/2 pointer-events-none z-10">
          <div className="px-4 py-1.5 rounded-2xl bg-white/95 text-slate-900 text-sm font-black border-2 border-slate-400 anim-fadeUp">
            {myLine}
          </div>
        </div>
      )}

      {/* sit-at-table button */}
      {hud.canSit && !hud.sitting && (
        <div className="absolute bottom-52 landscape:bottom-28 left-1/2 -translate-x-1/2 z-10">
          <button
            onPointerDown={(e) => {
              e.stopPropagation();
              onSit();
            }}
            className="px-5 py-2.5 rounded-2xl bg-teal-600 border-2 border-teal-300 text-white font-black text-sm active:scale-95"
            style={{ boxShadow: "0 0 18px rgba(30,200,180,.5)" }}
          >
            🪑 نشستن سر میز و گپ زدن
          </button>
        </div>
      )}

      {/* seated table-chat panel */}
      {hud.sitting && (
        <div className="absolute bottom-6 landscape:bottom-2 left-1/2 -translate-x-1/2 z-10 w-[92%] max-w-sm">
          <div className="rounded-2xl bg-slate-900/95 border-2 border-teal-400/50 p-2 anim-fadeUp">
            <div className="flex items-center justify-between mb-1.5 px-1">
              <span className="text-teal-200 text-[11px] font-black">☕ گپ سر میز (فقط حرف!)</span>
              <button
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onStand();
                }}
                className="px-3 py-1 rounded-lg bg-rose-700 text-white text-[11px] font-black border border-rose-400 active:scale-95"
              >
                🚶 بلند شدن
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {["چه خبرا؟ ☕", "خائن کیه؟ 🤔", "وظایف چطوره؟ 📋", "جوک بگم؟ 😄"].map(
                (lbl, i) => (
                  <button
                    key={i}
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const line = onTableSay(i);
                      if (line) {
                        setMyLine(line);
                        setTimeout(() => setMyLine(null), 2200);
                      }
                    }}
                    className="py-2 rounded-xl bg-slate-700 text-white text-[11px] font-black border border-slate-500 active:scale-95"
                  >
                    {lbl}
                  </button>
                ),
              )}
            </div>
          </div>
        </div>
      )}

      {/* talk button + quick chat */}
      {hud.canTalk && !hud.isGhost && !hud.sitting && (
        <div className={`absolute ${hud.isImpostor ? "bottom-24 landscape:bottom-20" : "bottom-7 landscape:bottom-2"} left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 landscape:scale-90`}>
          {talkOpen && (
            <div className="rounded-2xl bg-slate-900/95 border-2 border-emerald-400/50 p-2 grid grid-cols-2 gap-1.5 anim-fadeUp w-64">
              <div className="col-span-2 text-center text-emerald-200 text-[10px] font-black">
                💬 گفتگو با {hud.talkName}
              </div>
              <button onClick={() => sendTalk("hi")} className="py-2 rounded-xl bg-slate-700 text-white text-[11px] font-black border border-slate-500 active:scale-95">
                سلام! 👋
              </button>
              <button onClick={() => sendTalk("who")} className="py-2 rounded-xl bg-slate-700 text-white text-[11px] font-black border border-slate-500 active:scale-95">
                کی مشکوکه؟ 🤔
              </button>
              <button onClick={() => sendTalk("follow")} className="py-2 rounded-xl bg-emerald-800 text-emerald-100 text-[11px] font-black border border-emerald-500/60 active:scale-95">
                دنبالم بیا 🚶
              </button>
              <button onClick={() => sendTalk("leave")} className="py-2 rounded-xl bg-red-900 text-red-100 text-[11px] font-black border border-red-500/60 active:scale-95">
                برو پی کارت 😠
              </button>
            </div>
          )}
          <button
            onPointerDown={(e) => {
              e.stopPropagation();
              setTalkOpen((o) => !o);
            }}
            className="px-5 h-12 rounded-full bg-emerald-600 border-2 border-emerald-300 text-white font-black text-sm active:scale-95"
            style={{ boxShadow: "0 0 18px rgba(30,220,140,.5)" }}
          >
            💬 صحبت با {hud.talkName}
          </button>
        </div>
      )}

      {/* impostor sabotage buttons */}
      {hud.isImpostor && !hud.isGhost && (
        <div className="absolute bottom-7 left-1/2 -translate-x-1/2 flex gap-3 landscape:bottom-2 landscape:gap-2 landscape:scale-90">
          {(
            [
              ["lights", "💡", "قطع برق"],
              ["reactor", "☢️", "رآکتور"],
            ] as [SabKind, string, string][]
          ).map(([kind, icon, lbl]) => {
            const ready = hud.sabotageCd <= 0 && !hud.sabotage;
            return (
              <button
                key={kind}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onSabotage(kind);
                }}
                disabled={!ready}
                className={`w-14 h-14 rounded-2xl border-2 text-xl flex flex-col items-center justify-center ${
                  ready
                    ? "bg-orange-700/90 border-orange-300 text-white"
                    : "bg-slate-900/70 border-slate-700 text-slate-500"
                }`}
              >
                <span>{icon}</span>
                <span className="text-[8px] font-black">
                  {ready ? lbl : hud.sabotage ? "فعال" : Math.ceil(hud.sabotageCd)}
                </span>
              </button>
            );
          })}
          {(() => {
            const camReady = hud.cameraCd <= 0 && hud.camerasDown <= 0;
            return (
              <button
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onSabotageCams();
                }}
                disabled={!camReady}
                className={`w-14 h-14 rounded-2xl border-2 text-xl flex flex-col items-center justify-center ${
                  camReady
                    ? "bg-purple-800/90 border-purple-300 text-white"
                    : "bg-slate-900/70 border-slate-700 text-slate-500"
                }`}
              >
                <span>📷</span>
                <span className="text-[8px] font-black">
                  {camReady
                    ? "قطع دوربین"
                    : hud.camerasDown > 0
                      ? `${Math.ceil(hud.camerasDown)}s قطع`
                      : Math.ceil(hud.cameraCd)}
                </span>
              </button>
            );
          })()}
        </div>
      )}

      {/* watch CCTV button (near security monitors) */}
      {hud.canWatchCams && hud.watchingCam < 0 && (
        <div className="absolute bottom-44 landscape:bottom-24 left-1/2 -translate-x-1/2 z-10 landscape:scale-90">
          <button
            onPointerDown={(e) => {
              e.stopPropagation();
              onWatchCams();
            }}
            className="px-5 py-3 rounded-2xl bg-blue-600 border-2 border-blue-300 text-white font-black text-sm active:scale-95"
            style={{ boxShadow: "0 0 20px rgba(60,130,255,.6)" }}
          >
            📺 تماشای دوربین‌های مداربسته
          </button>
        </div>
      )}



      {/* action buttons (compact scale in landscape) */}
      <div
        className={`absolute bottom-6 right-5 flex-col items-center gap-3 landscape:bottom-2 landscape:right-3 landscape:gap-1.5 landscape:scale-[0.82] landscape:origin-bottom-right ${hud.sitting ? "hidden" : "flex"}`}
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        {hud.isImpostor && !hud.isGhost && (
          <button
            onPointerDown={(e) => {
              e.stopPropagation();
              onKill();
            }}
            disabled={!hud.canKill}
            className={`w-[76px] h-[76px] rounded-full font-black text-sm border-4 transition-all ${
              hud.canKill
                ? "bg-red-600 border-red-300 text-white"
                : "bg-red-950/60 border-red-800/60 text-red-300/50"
            }`}
            style={hud.canKill ? { animation: "pulseGlow 1.2s infinite" } : undefined}
          >
            {hud.killCooldown > 0 ? `⏱ ${Math.ceil(hud.killCooldown)}` : "کشتن 🔪"}
          </button>
        )}
        <button
          onPointerDown={(e) => {
            e.stopPropagation();
            onReport();
          }}
          disabled={!hud.canReport}
          className={`w-[68px] h-[68px] rounded-full font-black text-[11px] border-4 transition-all ${
            hud.canReport
              ? "bg-amber-500 border-amber-200 text-black animate-pulse"
              : "bg-slate-800/60 border-slate-600/50 text-slate-400/50"
          }`}
        >
          گزارش 📢
        </button>
        <button
          onPointerDown={(e) => {
            e.stopPropagation();
            onUse();
          }}
          disabled={!hud.canUse}
          className={`w-[86px] h-[86px] rounded-full font-black text-sm border-4 transition-all ${
            hud.canUse
              ? hud.useKind === "fix"
                ? "bg-red-600 border-red-200 text-white animate-pulse"
                : hud.useKind === "emergency"
                  ? "bg-rose-600 border-rose-200 text-white"
                  : "bg-cyan-500 border-cyan-100 text-black"
              : "bg-slate-800/60 border-slate-600/50 text-slate-400/50"
          }`}
          style={hud.canUse ? { boxShadow: "0 0 22px rgba(80,220,255,.6)" } : undefined}
        >
          {hud.useKind === "fix" ? "تعمیر 🚨" : hud.canUse ? "استفاده ⚙️" : "استفاده"}
        </button>
      </div>

      {/* body clue */}
      {hud.canReport && hud.clue && (
        <div className="absolute bottom-52 landscape:bottom-32 left-1/2 -translate-x-1/2 pointer-events-none z-10">
          <span className="px-4 py-1.5 rounded-xl bg-amber-950/85 text-amber-200 text-xs font-bold border border-amber-500/50 anim-fadeUp">
            {hud.clue}
          </span>
        </div>
      )}

      {/* use hint */}
      {hud.canUse && (
        <div className="absolute bottom-40 landscape:bottom-24 left-1/2 -translate-x-1/2 pointer-events-none">
          <span
            className={`px-4 py-1.5 rounded-xl text-sm font-bold border ${
              hud.useKind === "fix"
                ? "bg-red-950/80 text-red-100 border-red-400/60"
                : "bg-black/65 text-cyan-100 border-cyan-300/40"
            }`}
          >
            {hud.useLabel}
          </span>
        </div>
      )}

      {/* crosshair */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        <div className="w-1.5 h-1.5 rounded-full bg-white/50 border border-black/30" />
      </div>
    </div>
  );
}
