import { useState } from "react";

type Tab = "basics" | "impostor" | "crew";

function Row({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-2.5 py-1.5 border-b border-white/5 last:border-0">
      <span className="text-xl shrink-0 mt-0.5">{icon}</span>
      <div>
        <div className="text-white font-black text-[12px]">{title}</div>
        <div className="text-white/55 text-[11px] leading-5">{desc}</div>
      </div>
    </div>
  );
}

export default function Guide({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("basics");

  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
      <div className="w-full max-w-lg max-h-[92%] flex flex-col rounded-3xl bg-slate-900/97 border-2 border-slate-500/60 anim-popIn overflow-hidden">
        {/* header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950/70 border-b border-slate-600/50">
          <div className="text-white font-black text-base">📖 راهنمای کامل بازی</div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-rose-700 text-white text-xs font-black border border-rose-400 active:scale-95"
          >
            ✕ بستن
          </button>
        </div>
        {/* tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-2 bg-slate-950/40">
          {(
            [
              ["basics", "🎮 کنترل‌ها"],
              ["impostor", "🔪 اگر خائنی"],
              ["crew", "🛡 اگر خدمه‌ای"],
            ] as [Tab, string][]
          ).map(([t, lbl]) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`py-2 rounded-xl text-xs font-black border-2 transition-all ${
                tab === t
                  ? t === "impostor"
                    ? "bg-red-600 text-white border-red-300"
                    : t === "crew"
                      ? "bg-emerald-600 text-white border-emerald-300"
                      : "bg-cyan-500 text-black border-cyan-200"
                  : "bg-white/5 text-white/60 border-white/15"
              }`}
            >
              {lbl}
            </button>
          ))}
        </div>
        {/* content */}
        <div className="flex-1 overflow-y-auto px-4 py-2 scroll-y">
          {tab === "basics" && (
            <>
              <Row icon="🕹" title="حرکت" desc="اهرم پایین-چپ (روی رایانه: WASD). کشیدن بقیه صفحه = چرخاندن دید." />
              <Row icon="⚙️" title="دکمه استفاده" desc="نزدیک هر ایستگاه وظیفه یا دکمه اضطراری روشن می‌شود. وظایف مینی‌گیم دارند!" />
              <Row icon="📢" title="گزارش جسد" desc="نزدیک جسد فعال می‌شود و جلسه اضطراری شروع می‌کند. کنار جسد سرنخ ردپا هم می‌بینی." />
              <Row icon="🚨" title="دکمه اضطراری" desc="وسط کافه‌تریا؛ فقط یک‌بار در کل بازی می‌توانی جلسه بیندازی — حساب‌شده خرجش کن." />
              <Row icon="🗳" title="رأی‌گیری" desc="فقط ۴ ژتون رأی در کل بازی داری! اکثریت مطلق = پرتاب به فضا؛ فقط بیشترین رأی = بازداشتگاه (۳۵ ثانیه)." />
              <Row icon="💬" title="صحبت و جلسه" desc="در جلسه: متهم کن (۳ پیام)، دفاع کن (۲ بار در کل بازی)، رأی بخر (۲۵🪙). بیرون جلسه: با دکمه سبز با ربات‌ها حرف بزن." />
              <Row icon="🪙" title="سکه" desc="وظیفه ۸+ | تعمیر ۱۲+ | زنده‌ماندن از جلسه ۶+ | همکاری ۵+. خرج رشوه، شهادت دروغ و بهم‌زدن جلسه می‌شود." />
              <Row icon="📷" title="دوربین مداربسته" desc="از اتاق امنیت تماشا کن (با کشیدن بچرخان). قتل جلوی دوربین روشن = مدرک قطعی در جلسه!" />
              <Row icon="🪑" title="میز گپ" desc="کنار میز اضطراری بنشین و فقط گپ بزن — ربات‌ها هم می‌آیند. مراقب پشتت باش!" />
              <Row icon="👻" title="بعد از مرگ" desc="روح می‌شوی: پرواز آزاد و ادامه وظایف — ولی رأی و حرف نداری." />
              <Row icon="⏸" title="توقف" desc="دکمه ⏸ کنار نقشه: توقف کامل بازی، تنظیمات و خروج." />
            </>
          )}
          {tab === "impostor" && (
            <>
              <div className="text-red-300 text-[11px] font-black py-2 leading-5">
                هدف: خدمه را حذف کن تا تعدادتان برابر شود، یا رآکتور را منفجر کن — بدون اینکه لو بروی!
              </div>
              <Row icon="🔪" title="کشتن" desc="نزدیک قربانی شو (پشت دیوار نمی‌شود!). کول‌داون ۳۲ ثانیه. هر قتل ۱۵ سکه." />
              <Row icon="📷" title="اول دوربین، بعد قتل" desc="نشان «🔴 REC» یعنی در دید دوربینی! دکمه «قطع دوربین» را بزن یا اگر آماده باشد، هنگام قتل خودکار قطع می‌شود (قتل مخفیانه)." />
              <Row icon="👣" title="ردپای خونی" desc="بعد از قتل ۱۶ ثانیه رد قرمز می‌گذاری — از صحنه دور شو و مستقیم سمت جمعیت نرو." />
              <Row icon="💡" title="قطع برق" desc="بهترین پوشش: دید همه ۳ متر می‌شود، شاهدها تقریباً کور، تو کامل می‌بینی. در تاریکی شکار کن." />
              <Row icon="☢️" title="رآکتور" desc="۴۰ ثانیه شمارش معکوس؛ خدمه هجوم می‌برند تعمیر کنند — کمین کن یا اگر تعمیر نشود، برنده‌ای!" />
              <Row icon="🎭" title="در جلسه" desc="شهادت دروغ بده (۱۵🪙)، رأی بخر (۲۵🪙)، جلسه را بهم بزن (۴۰🪙). متهم شدی؟ محکم دفاع و ضدحمله کن." />
              <Row icon="😈" title="تله و تهدید" desc="با «بیا نشانت بدهم» قربانی را جای خلوت بکش. تهدید کن ساکت بماند؛ مأموریت حذف بده؛ شریک جرم بگیر." />
              <Row icon="🤝" title="هم‌دستت" desc="در حالت ۲ خائن، هم‌دیگر را نمی‌کشید و لو نمی‌دهید. اگر حذف شود، انتقامش با توست!" />
              <Row icon="⚠️" title="اشتباهات مرگبار" desc="کشتن جلوی شاهد، کشتن روی دوربین روشن، تعقیب آشکار یک نفر، و رأی‌دادن ناهماهنگ با جمع." />
            </>
          )}
          {tab === "crew" && (
            <>
              <div className="text-emerald-300 text-[11px] font-black py-2 leading-5">
                هدف: همه وظایف را کامل کنید یا همه خائن‌ها را با رأی‌گیری بیرون بیندازید!
              </div>
              <Row icon="📋" title="وظایف" desc="لیست بالا-راست؛ نقاط زرد چشمک‌زن روی نقشه. مأموریت‌های ۲ مرحله‌ای را کامل کن — نوار سبز بالای صفحه پیروزی جمعی است." />
              <Row icon="👥" title="تنها نمان" desc="با «دنبالم بیا» یا پیشنهاد همراهی ربات‌ها گروهی بگرد — ولی بدان خائن هم با اشتیاق همراهی را قبول می‌کند!" />
              <Row icon="💓" title="ضربان قلب" desc="صدای ضربان و قرمزی دور صفحه = خائن نزدیک است. فرار کن سمت جمعیت." />
              <Row icon="📷" title="کارآگاه‌بازی" desc="از اتاق امنیت دوربین‌ها را بپا. در جلسه دکمه «📷 دوربین‌ها» را بزن و طبق مدرک رأی بده. قطعی ناگهانی دوربین‌ها = قتل در راه است!" />
              <Row icon="👣" title="سرنخ‌ها" desc="کنار جسد سرنخ ردپا می‌بینی: «ردپا به سمت درمانگاه می‌رود» = مسیر قاتل! تعقیبش کن." />
              <Row icon="🗳" title="رأی هوشمندانه" desc="ژتون‌هایت محدودند — بی‌مدرک رأی نده. «با چشمم دیدم» خیلی قوی‌تر از «نزدیک جسد بود» است. شنیده‌ها ممکن است غلط باشند." />
              <Row icon="🚨" title="خرابکاری" desc="قطع برق: برو اتاق برق فیوزها را بزن. رآکتور: دو دست همزمان — نرسی همه می‌بازید!" />
              <Row icon="🎭" title="فریب‌ها" desc="پول خائن را بگیری و خیانت کنی، کینه می‌گیرد و شکارت می‌کند. تهدید شدی؟ رد کنی سراغت می‌آید — هوشمند انتخاب کن." />
              <Row icon="🛡" title="متهم شدی؟" desc="فقط ۲ دفاع در کل بازی داری. الکی خرجش نکن؛ با مدرک (دوربین/موقعیتت) دفاع کن." />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
