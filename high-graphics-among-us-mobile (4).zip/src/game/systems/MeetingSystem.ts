// =============================================================================
// MeetingSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function getMeetingSeed(g: GameEngine): {
    scores: Record<number, Record<number, number>>;
    witness: { id: number; suspectId: number; kind: "sawKill" | "nearBody" } | null;
    personalities: Record<number, { aggression: number; bravery: number; label: string }>;
  } {
    const scores: Record<number, Record<number, number>> = {};
    const personalities: Record<number, { aggression: number; bravery: number; label: string }> = {};
    let witness: { id: number; suspectId: number; kind: "sawKill" | "nearBody" } | null = null;
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || !e.mind) continue;
      const row: Record<number, number> = {};
      for (const t of g.entities) {
        if (!t.info.alive || t.info.id === e.info.id) continue;
        row[t.info.id] = e.mind.evidenceScore(t.info.id, g.worldT);
      }
      scores[e.info.id] = row;
      personalities[e.info.id] = {
        aggression: e.mind.traits.aggression,
        bravery: e.mind.traits.bravery,
        label: e.mind.archetype.label,
      };
      // strongest direct sighting becomes the meeting's witness testimony
      const sight = e.mind.directSighting();
      if (sight && !e.info.isImpostor) {
        const suspect = g.entities.find((s) => s.info.id === sight.aboutId);
        if (suspect?.info.alive && (!witness || sight.kind === "sawKill")) {
          witness = { id: e.info.id, suspectId: sight.aboutId, kind: sight.kind };
        }
      }
    }
    return { scores, witness, personalities };
}

export function noteMeetingClaim(g: GameEngine, 
    speakerId: number,
    targetId: number,
    kind: "accusation" | "defense" | "lie",
  ) {
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || !e.mind || e.info.id === targetId) continue;
      if (kind === "accusation") {
        // heard info — reliability depends on trust in the speaker
        const rel = e.mind.relFor(speakerId);
        // NATURAL: second-hand info can be garbled in transmission
        const garbled = Math.random() < 0.15;
        e.mind.remember({
          kind: "heardSuspicion",
          aboutId: targetId,
          source: speakerId === 0 ? "player" : "bot",
          reliability: Math.min(1, 0.4 + rel.trust / 150) * (garbled ? 0.35 : 1),
          t: g.worldT,
        });
      } else if (kind === "lie") {
        e.mind.remember({
          kind: "provenLie",
          aboutId: targetId,
          source: "meeting",
          reliability: 0.9,
          t: g.worldT,
        });
      }
    }
    if (kind === "defense") {
      // the accused (if a bot) remembers who defended them
      const accused = g.entities.find((e) => e.info.id === targetId);
      accused?.mind?.remember({
        kind: "defendedMe",
        aboutId: speakerId,
        source: "meeting",
        reliability: 1,
        t: g.worldT,
      });
    }
}

export function settleMeetingOutcome(g: GameEngine, 
    votes: Record<number, number | -1>,
    ejectedId: number | null = null,
    jailedId: number | null = null,
  ) {
    const myVote = votes[0];

    // ================= ACCOMPLICE REVENGE =================
    // If an impostor is eliminated (ejected/jailed) or dies holding a grudge
    // against the player, a surviving impostor teammate avenges them.
    const player = g.entities[0];
    const removedId = ejectedId ?? jailedId;
    const removed =
      removedId !== null ? g.entities.find((e) => e.info.id === removedId) : null;
    const avengers = g.entities.filter(
      (e) =>
        e.info.isBot &&
        e.info.alive &&
        e.info.isImpostor &&
        e.info.id !== removedId &&
        e.jailedT <= 0,
    );
    if (removed?.info.isImpostor && avengers.length && player.info.alive && !player.info.isImpostor) {
      // did the player cross the fallen impostor?
      const playerVotedHim = myVote === removedId;
      const hadBeefWithPlayer =
        g.grudges.has(removedId!) || // player refused his threat/mission/deal
        g.threatBotId === removedId ||
        removed.mind?.relFor(0).grudge !== undefined &&
          (removed.mind?.relFor(0).grudge ?? 0) > 30;
      if (playerVotedHim || hadBeefWithPlayer) {
        const av = avengers[Math.floor(Math.random() * avengers.length)];
        g.grudges.add(av.info.id);
        av.killCd = Math.min(av.killCd, 7); // he's coming for you, fast
        av.mind?.remember({
          kind: "betrayedMe",
          aboutId: 0,
          source: "meeting",
          reliability: 1,
          t: g.worldT,
        });
        setTimeout(() => {
          if (av.info.alive) {
            g.say(
              av,
              ejectedId === removedId
                ? "هم‌دستم رو به کشتن دادی... حالا نوبت خودته 🔪😡"
                : "رفیقم رو انداختی بازداشتگاه؟ تاوانشو می‌دی... 🔪",
              4,
            );
          }
        }, 2000);
        g.onEvent({ type: "avenger", botName: av.info.name });
      }
    }
    // a dead grudge-holder's revenge is inherited by a surviving accomplice
    for (const e of g.entities) {
      if (!e.info.isImpostor || e.info.alive || !g.grudges.has(e.info.id)) continue;
      g.grudges.delete(e.info.id);
      if (avengers.length && player.info.alive && !player.info.isImpostor) {
        const heir = avengers[Math.floor(Math.random() * avengers.length)];
        g.grudges.add(heir.info.id);
        heir.killCd = Math.min(heir.killCd, 10);
      }
    }
    // =======================================================

    // bots remember who voted against THEM (their own votes are public info)
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || !e.mind) continue;
      for (const [voterStr, target] of Object.entries(votes)) {
        const voterId = Number(voterStr);
        if (target === e.info.id && voterId !== e.info.id) {
          e.mind.remember({
            kind: "votedAgainstMe",
            aboutId: voterId,
            source: "meeting",
            reliability: 1,
            t: g.worldT,
          });
        }
      }
    }
    // ---- elimination mission enforcement ----
    if (g.pendingMission) {
      const { botId, targetId, reward } = g.pendingMission;
      const bot = g.entities.find((e) => e.info.id === botId);
      const target = g.entities.find((e) => e.info.id === targetId);
      const botAlive = bot && bot.info.alive && bot.info.id !== ejectedId;
      const targetGone =
        ejectedId === targetId || jailedId === targetId || !target || !target.info.alive;
      if (targetGone) {
        // mission accomplished
        if (g.entities[0].info.alive) g.coins += reward;
        if (botAlive) setTimeout(() => g.say(bot!, "کارت عالی بود... 🔪🤝", 3.5), 1500);
      } else if (botAlive && g.entities[0].info.alive) {
        // mission failed — the impostor comes for you
        g.grudges.add(botId);
        bot!.killCd = Math.min(bot!.killCd, 5);
        setTimeout(
          () => g.say(bot!, "بهت گفته بودم چی میشه... حالا نوبت خودته 🔪😡", 4),
          1500,
        );
      }
      g.pendingMission = null;
    }
    // deal enforcement
    if (g.pendingDeal) {
      const { botId, targetId, reward } = g.pendingDeal;
      const bot = g.entities.find((e) => e.info.id === botId);
      if (bot && bot.info.alive && g.entities[0].info.alive) {
        if (myVote === targetId) {
          g.coins += 5; // bonus for loyalty
          bot.mind?.remember({
            kind: "dealtWithMe",
            aboutId: 0,
            source: "self",
            reliability: 1,
            t: g.worldT,
          });
          setTimeout(() => g.say(bot, "کارت خوب بود... 🤝", 3), 1500);
        } else {
          // betrayal!
          g.grudges.add(botId);
          g.quarrelBotId = botId;
          g.quarrelReward = reward;
          bot.mind?.remember({
            kind: "betrayedMe",
            aboutId: 0,
            source: "self",
            reliability: 1,
            t: g.worldT,
          });
        }
      }
      g.pendingDeal = null;
    }
    // threat enforcement — voted against the impostor who threatened you
    if (g.threatBotId !== null) {
      const bot = g.entities.find((e) => e.info.id === g.threatBotId);
      if (bot && bot.info.alive && myVote === g.threatBotId) {
        bot.killCd = Math.min(bot.killCd, 6); // he's coming for you
        g.grudges.add(bot.info.id);
        setTimeout(() => g.say(bot, "بهت هشدار داده بودم... 🔪😡", 3.5), 1500);
      }
      g.threatBotId = null;
    }
}

export function resolveMeeting(g: GameEngine, ejectedId: number | null, jailedId: number | null = null) {
    if (ejectedId !== null) {
      const e = g.entities.find((en) => en.info.id === ejectedId);
      if (e) {
        e.info.alive = false;
        e.rig.group.visible = false;
        if (e.info.id === 0) g.isGhost = true;
      }
    }
    // bodies are carried to the morgue and kept in isolation (not deleted!)
    for (const b of g.bodies) {
      const slot = g.morgueCount++;
      const col = slot % 3;
      const row = Math.floor(slot / 3);
      b.mesh.position.set(
        MORGUE.x - 1.8 + col * 1.8,
        0.56 + row * 0.01,
        MORGUE.z + 0.6 + row * 0.9,
      );
      b.mesh.rotation.y = Math.PI / 2;
      // remove the blood pool in the morgue (bodies are cleaned)
      b.mesh.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (mesh.isMesh && (mesh.material as THREE.MeshBasicMaterial).transparent) {
          const mat = mesh.material as THREE.MeshBasicMaterial;
          if (mat.color && mat.color.getHex() === 0x7a0f14) mesh.visible = false;
        }
      });
    }
    g.bodies = [];
    g.witnesses.clear();
    g.cameraEvidence = null;
    // clear old footprints + stop bleeding trails
    for (let i = g.anims.length - 1; i >= 0; i--) {
      if (g.anims[i].kind === "print") {
        g.scene.remove(g.anims[i].obj);
        g.anims.splice(i, 1);
      }
    }
    for (const e of g.entities) e.bloodyT = 0;
    g.sightMap.clear();
    g.pendingMurder = null; // murder plans don't survive meetings
    // reset social state
    g.activeProposal = null;
    g.socialTimer = 18 + Math.random() * 10;
    for (const e of g.entities) {
      e.social = "none";
      e.leadKind = null;
      e.bubbleT = 0;
      e.rig.bubble.visible = false;
    }
    const alive = g.entities.filter((e) => e.info.alive);
    alive.forEach((e, i) => {
      const ang = -Math.PI / 2 + (i / alive.length) * Math.PI * 2;
      e.x = EMERGENCY_POS.x + Math.cos(ang) * SPAWN_RING;
      e.z = EMERGENCY_POS.z + Math.sin(ang) * SPAWN_RING;
      e.path = [];
      e.dwell = 1.5 + Math.random() * 3;
      e.yaw = ang + Math.PI;
      e.targetYaw = e.yaw;
      e.rig.group.position.set(e.x, 0, e.z);
    });
    g.playerKillCd = Math.max(g.playerKillCd, 14);
    g.sabCd = Math.max(g.sabCd, 12);
    g.botSabTimer = 25 + Math.random() * 25;
    for (const e of g.entities) e.killCd = Math.max(e.killCd, 16 + Math.random() * 8);
    if (g.entities[0].info.alive) g.coins += COIN_SURVIVE;
    if (jailedId !== null) g.jail(jailedId);
    g.spawnT = 1.1;

    if (!g.checkWin()) {
      g.state = "playing";
      g.clock.getDelta();
    }
}

export function startMeeting(g: GameEngine, data: MeetingData) {
    if (g.state !== "playing") return;
    g.clearSabotage();
    const intel = g.getIntel();
    data.accusedId = intel.suspectId;
    g.state = "meeting";
    g.setMove(0, 0);
    g.camView = -1;
    g.sitting = false;
    g.onEvent({ type: "meeting", data });
}
