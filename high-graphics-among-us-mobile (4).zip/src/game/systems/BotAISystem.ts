// =============================================================================
// BotAISystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function updateBots(g: GameEngine, dt: number) {
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive) continue;

      // jailed bots pace in the cell
      if (e.jailedT > 0) {
        e.walking = false;
        e.rig.group.position.set(e.x, 0, e.z);
        const tj = performance.now() / 1000;
        e.rig.body.position.y = 1.02 + Math.sin(tj * 2 + e.info.id) * 0.02;
        e.rig.legL.position.z = 0;
        e.rig.legR.position.z = 0;
        continue;
      }

      const isFixer = g.sab !== null && g.fixerIds.has(e.info.id);
      const isSocial = e.social !== "none";

      if (e.dwell > 0 && !isFixer && !isSocial) {
        e.dwell -= dt;
        e.walking = false;
      } else {
        if (e.path.length === 0) {
          if (isFixer || isSocial) {
            // social/fixer bots manage their own paths
            e.walking = false;
          } else {
            const from = nearestNode(e.x, e.z);
            let to: NavNode | null = null;
            // accomplice murder plan: hunt the agreed victim specifically
            if (
              e.info.isImpostor &&
              g.pendingMurder &&
              g.pendingMurder.botId === e.info.id
            ) {
              const t = g.entities.find(
                (v) => v.info.id === g.pendingMurder!.targetId && v.info.alive,
              );
              if (t) to = nearestNode(t.x, t.z);
            }
            // smart hunting: impostor stalks its prey
            // AVENGER: grudge-holding impostor hunts the player relentlessly
            if (
              e.info.isImpostor &&
              g.grudges.has(e.info.id) &&
              g.entities[0].info.alive &&
              !g.isGhost &&
              g.entities[0].jailedT <= 0
            ) {
              to = nearestNode(g.entities[0].x, g.entities[0].z);
            }
            if (!to && e.info.isImpostor && e.killCd < 12 && Math.random() < 0.5) {
              // NO GOD-MODE: only stalk prey plausibly within earshot/sight (14u)
              const prey = g.entities.filter(
                (v) =>
                  v !== e &&
                  v.info.alive &&
                  !v.info.isImpostor &&
                  v.jailedT <= 0 &&
                  Math.hypot(v.x - e.x, v.z - e.z) < 14 &&
                  !(v.info.id === 0 && g.isGhost),
              );
              const t = prey[Math.floor(Math.random() * prey.length)];
              if (t) to = nearestNode(t.x, t.z);
            }
            if (!to) {
              const targets = NODES.filter((n) => n.id !== from.id && n.id !== "prison");
              to = targets[Math.floor(Math.random() * targets.length)];
            }
            e.path = findPath(from.id, to.id);
            if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
          }
        }
        if (e.path.length > 0) {
          const target = e.path[0];
          const dx = target.x - e.x;
          const dz = target.z - e.z;
          const d = Math.hypot(dx, dz);
          if (d < 0.5) {
            e.path.shift();
            if (e.path.length === 0 && !isFixer) e.dwell = 2 + Math.random() * 5;
          } else {
            // BUGFIX: buddies/approachers were slower than the player (2.35 vs 4) and
            // could never catch up — social bots now hustle at 3.7
            const spd = isFixer
              ? BOT_SPEED * FIXER_SPEED_MULT
              : e.social === "buddy" || e.social === "approach"
                ? SOCIAL_BOT_SPEED
                : BOT_SPEED;
            const sp = spd * dt;
            g.tryMove(e, (dx / d) * sp, (dz / d) * sp);
            e.targetYaw = Math.atan2(dx, dz);
            e.walking = true;
          }
          if (Math.hypot(e.x - e.lastX, e.z - e.lastZ) < 0.02) {
            e.stuck += dt;
            if (e.stuck > 1.6) {
              const n = nearestNode(e.x, e.z);
              e.x = n.x;
              e.z = n.z;
              e.path = [];
              e.stuck = 0;
            }
          } else {
            e.stuck = 0;
          }
          e.lastX = e.x;
          e.lastZ = e.z;
        }
      }

      let dy = e.targetYaw - e.yaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      e.yaw += dy * Math.min(1, dt * 10);
      e.rig.group.position.set(e.x, 0, e.z);
      e.rig.group.rotation.y = e.yaw;

      const t = performance.now() / 1000;
      if (e.walking) {
        const s = Math.sin(t * 11 + e.info.id);
        e.rig.legL.position.z = s * 0.22;
        e.rig.legR.position.z = -s * 0.22;
        e.rig.body.position.y = 1.02 + Math.abs(Math.sin(t * 11 + e.info.id)) * 0.06;
      } else {
        e.rig.legL.position.z = 0;
        e.rig.legR.position.z = 0;
        e.rig.body.position.y = 1.02 + Math.sin(t * 2 + e.info.id) * 0.02;
      }

      // crew bot: report bodies (harder to notice in blackout)
      if (!e.info.isImpostor) {
        const noticeRange = g.sab?.kind === "lights" ? 1.8 : 4.2;
        for (const b of g.bodies) {
          const d = Math.hypot(e.x - b.x, e.z - b.z);
          if (d < noticeRange) {
            e.reportDelay += dt;
            if (e.reportDelay > 0.9) {
              e.reportDelay = 0;
              g.startMeeting({
                reason: "body",
                reporterId: e.info.id,
                victimId: b.victimId,
                accusedId: null,
              });
              return;
            }
          }
        }
      }

      // impostor bot: hunt (bolder in the dark)
      if (e.info.isImpostor) {
        e.killCd -= dt;
        if (e.killCd <= 0) {
          const blackout = g.sab?.kind === "lights";
          let victim: Entity | null = null;
          for (const v of g.entities) {
            if (v === e || !v.info.alive || v.info.isImpostor || v.jailedT > 0) continue;
            if (v.info.id === 0 && g.isGhost) continue;
            const d = Math.hypot(e.x - v.x, e.z - v.z);
            if (d < 2.1 && directWalkable(e.x, e.z, v.x, v.z)) {
              let seen = 0;
              for (const w of g.entities) {
                if (w === e || w === v || !w.info.alive) continue;
                if (w.info.id === 0 && g.isGhost) continue;
                if (Math.hypot(w.x - e.x, w.z - e.z) < (blackout ? 4 : 9)) seen++;
              }
              const boldness = e.mind?.traits.aggression ?? 0.5;
              if (seen === 0 || (seen === 1 && Math.random() < (blackout ? 0.5 : 0.03 + boldness * 0.2))) {
                victim = v;
                break;
              }
            }
          }
          if (victim) {
            // SMART IMPOSTOR: cut the cameras first so the murder isn't recorded
            if (
              g.camerasDownT <= 0 &&
              g.botCamCd <= 0 &&
              (g.inCameraView(e.x, e.z) || g.inCameraView(victim.x, victim.z))
            ) {
              g.botCamCd = 65 + Math.random() * 20;
              g.killCams(CAM_DOWN_TIME_BOT);
            }
            g.kill(e, victim);
            e.killCd = 24 + Math.random() * 14;
            e.path = [];
            e.dwell = 0.2;
          }
        }
      }
    }
}
