// =============================================================================
// SabotageSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function triggerSabotage(g: GameEngine, kind: SabKind) {
    if (g.state !== "playing" || g.sab || g.sabCd > 0 || g.isGhost) return;
    const p = g.entities[0];
    if (!p.info.isImpostor || p.jailedT > 0) return;
    g.startSabotage(kind);
    g.sabCd = SAB_COOLDOWN;
}

export function startSabotage(g: GameEngine, kind: SabKind) {
    g.sab = { kind, timeLeft: kind === "reactor" ? REACTOR_TIME : -1 };
    g.sharedFixTime = 0;
    g.standUp(); // emergencies interrupt table chats
    // cancel any pending social proposal — emergency overrides small talk
    if (g.activeProposal) {
      const b = g.entities.find((e) => e.info.id === g.activeProposal!.botId);
      if (b) {
        b.social = "none";
        b.leadKind = null;
        b.path = [];
      }
      g.activeProposal = null;
      g.onEvent({ type: "proposalOver" });
    }
    // assign the two nearest crew bots as fixers
    const fp = FIX_POINTS[kind];
    const crewBots = g.entities
      .filter((e) => e.info.isBot && e.info.alive && !e.info.isImpostor && e.jailedT <= 0)
      .sort(
        (a, b) =>
          Math.hypot(a.x - fp.x, a.z - fp.z) - Math.hypot(b.x - fp.x, b.z - fp.z),
      );
    g.fixerIds = new Set(crewBots.slice(0, 2).map((e) => e.info.id));
    for (const e of g.entities) {
      if (g.fixerIds.has(e.info.id)) {
        const from = nearestNode(e.x, e.z);
        e.path = findPath(from.id, fp.node);
        if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
        e.dwell = 0;
      }
    }
    if (kind === "lights") g.applyBlackout(true);
    g.onEvent({ type: "sabotage", kind });
}

export function clearSabotage(g: GameEngine) {
    if (!g.sab) return;
    if (g.sab.kind === "lights") g.applyBlackout(false);
    g.alarmLight.intensity = 0;
    g.sab = null;
    g.fixerIds.clear();
    g.sharedFixTime = 0;
    // fixers resume wandering
    for (const e of g.entities) if (e.info.isBot) e.path = [];
    g.onEvent({ type: "sabotageFixed" });
}

export function applyBlackout(g: GameEngine, on: boolean) {
    const imp = g.entities[0].info.isImpostor;
    if (on) {
      for (const { l } of g.allLights) l.intensity = 0;
      g.ambient.intensity = imp ? 0.5 : 0.1;
      g.hemi.intensity = imp ? 0.4 : 0.08;
      const fog = g.scene.fog as THREE.Fog;
      fog.near = imp ? 12 : 3;
      fog.far = imp ? 30 : 11;
      g.flashlight.intensity = 90;
    } else {
      for (const { l, base } of g.allLights) l.intensity = base;
      g.ambient.intensity = 1.15;
      g.hemi.intensity = 0.85;
      const fog = g.scene.fog as THREE.Fog;
      fog.near = 26;
      fog.far = 60;
      g.flashlight.intensity = 0;
    }
}

export function updateSabotage(g: GameEngine, dt: number) {
    // bot impostor triggers sabotage
    const botImp = g.entities.find((e) => e.info.isBot && e.info.alive && e.info.isImpostor);
    if (botImp && !g.sab) {
      g.botSabTimer -= dt;
      if (g.botSabTimer <= 0) {
        g.botSabTimer = 50 + Math.random() * 35;
        g.startSabotage(Math.random() < 0.5 ? "lights" : "reactor");
      }
    }
    if (!g.sab) return;

    if (g.sab.kind === "reactor") {
      g.sab.timeLeft -= dt;
      const t = performance.now() / 1000;
      g.alarmLight.intensity = (Math.sin(t * 7) + 1.2) * 40;
      if (g.sab.timeLeft <= 0) {
        const impostorIds = g.entities.filter((e) => e.info.isImpostor).map((e) => e.info.id);
        g.endGame({
          kind: "impostor-sabotage",
          playerWon: g.entities[0].info.isImpostor,
          impostorIds,
        });
        return;
      }
    }

    // bot fixers repair when close to the fix point
    const fp = FIX_POINTS[g.sab.kind];
    let fixing = false;
    for (const e of g.entities) {
      if (!g.fixerIds.has(e.info.id) || !e.info.alive) continue;
      if (Math.hypot(e.x - fp.x, e.z - fp.z) < 3) fixing = true;
    }
    if (fixing) {
      g.sharedFixTime += dt;
      if (g.sharedFixTime > 4) g.clearSabotage();
    }
}
