// =============================================================================
// RenderSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function updateFootprints(g: GameEngine, dt: number) {
    for (const e of g.entities) {
      if (e.bloodyT <= 0) continue;
      e.bloodyT -= dt;
      if (!e.info.alive) continue;
      const moved = Math.hypot(e.x - e.lastPX, e.z - e.lastPZ);
      if (moved > 0.7) {
        e.lastPX = e.x;
        e.lastPZ = e.z;
        const side = (Math.floor(e.bloodyT * 10) % 2 === 0 ? 1 : -1) * 0.16;
        const perp = e.yaw + Math.PI / 2;
        const print = new THREE.Mesh(
          new THREE.CircleGeometry(0.13, 8),
          new THREE.MeshBasicMaterial({
            color: 0x7a0f14,
            transparent: true,
            opacity: 0.75,
            depthWrite: false,
          }),
        );
        print.rotation.x = -Math.PI / 2;
        print.scale.set(1, 1.7, 1);
        print.rotation.z = -e.yaw;
        print.position.set(e.x + Math.sin(perp) * side, 0.035, e.z + Math.cos(perp) * side);
        g.scene.add(print);
        g.anims.push({ obj: print, t: 0, dur: 22, kind: "print" });
      }
    }
}

export function updateCamera(g: GameEngine, dt: number) {
    const p = g.entities[0];
    // CCTV watch mode overrides first-person view
    if (g.camView >= 0 && CAMERAS[g.camView]) {
      const c = CAMERAS[g.camView];
      g.camSway += dt;
      // gentle auto-sweep only when the user isn't rotating manually
      const sway = Math.abs(g.camYawOff) < 0.05 ? Math.sin(g.camSway * 0.5) * 0.3 : 0;
      g.camera.position.set(c.x, 2.62, c.z);
      g.camera.rotation.order = "YXZ";
      g.camera.rotation.y =
        Math.atan2(EMERGENCY_POS.x - c.x, EMERGENCY_POS.z - c.z) +
        Math.PI +
        sway +
        g.camYawOff;
      g.camera.rotation.x = -0.38 + g.camPitchOff;
      return;
    }
    g.ghostBob += dt;
    let baseY = g.isGhost
      ? 1.75 + Math.sin(g.ghostBob * 1.8) * 0.15
      : g.sitting
        ? 1.08 // seated eye level
        : 1.55;
    // spawn drop-in animation
    if (g.spawnT > 0) {
      g.spawnT -= dt;
      const k = Math.max(0, g.spawnT / 1.1);
      baseY += k * k * 5;
    }
    let sx = 0,
      sy = 0;
    if (g.shake > 0) {
      g.shake -= dt;
      sx = (Math.random() - 0.5) * g.shake * 0.4;
      sy = (Math.random() - 0.5) * g.shake * 0.4;
    }
    const bob = p.walking && !g.isGhost ? Math.sin(performance.now() / 90) * 0.045 : 0;
    g.camera.position.set(p.x + sx, baseY + bob + sy, p.z);
    g.camera.rotation.order = "YXZ";
    g.camera.rotation.y = p.yaw;
    g.camera.rotation.x = g.pitch;
}
