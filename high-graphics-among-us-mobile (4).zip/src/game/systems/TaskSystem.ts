// =============================================================================
// TaskSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function taskInfos(g: GameEngine): TaskInfo[] {
    return g.tasks.map((t) => {
      const done = t.step >= t.steps.length;
      const cur = done ? null : t.steps[t.step];
      const st = cur ? STATIONS.find((s) => s.id === cur.st)! : null;
      return {
        id: t.id,
        label: t.label,
        room: st ? st.room : "",
        stepLabel: cur ? cur.label : "",
        done,
        step: t.step,
        total: t.steps.length,
        currentStationId: cur ? cur.st : null,
      };
    });
}

export function getActiveStation(g: GameEngine): ActiveStation | null {
    const p = g.entities[0];
    if (p.jailedT > 0) return null;
    // sabotage fix has top priority (impostor may also "fix")
    if (g.sab && !g.isGhost) {
      const fp = FIX_POINTS[g.sab.kind];
      if (Math.hypot(p.x - fp.x, p.z - fp.z) < 3.2) {
        return { stationId: "__fix__", kind: fp.game, label: fp.label, isFix: true };
      }
    }
    if (p.info.isImpostor) return null;
    for (const t of g.tasks) {
      if (t.step >= t.steps.length) continue;
      const cur = t.steps[t.step];
      const st = STATIONS.find((s) => s.id === cur.st)!;
      if (Math.hypot(p.x - st.x, p.z - st.z) < USE_RANGE) {
        return {
          stationId: cur.st,
          kind: GAME_KINDS[cur.st] ?? "hold",
          label: cur.label,
          isFix: false,
        };
      }
    }
    return null;
}

export function completeStation(g: GameEngine, stationId: string) {
    if (stationId === "__fix__") {
      if (g.sab) {
        g.clearSabotage();
        g.coins += COIN_FIX;
      }
      return;
    }
    for (const t of g.tasks) {
      if (t.step >= t.steps.length) continue;
      if (t.steps[t.step].st === stationId) {
        t.step++;
        g.coins += COIN_TASK;
        g.checkWin();
        return;
      }
    }
}

export function globalTaskProgress(g: GameEngine): number {
    const playerUnits = g.tasks.reduce((a, t) => a + t.step, 0);
    const total = g.botTaskTotal + g.playerUnitsTotal;
    if (total === 0) return 0;
    return Math.min(1, (g.botTaskUnits + playerUnits) / total);
}

export function updateTaskWork(g: GameEngine, dt: number) {
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || e.info.isImpostor) continue;
      if (g.sab) continue; // bots pause tasks during emergencies
      e.taskTimer -= dt;
      if (e.taskTimer <= 0) {
        e.taskTimer = 20 + Math.random() * 22;
        if (g.botTaskUnits < g.botTaskTotal) {
          g.botTaskUnits++;
          g.checkWin();
        }
      }
    }
}
