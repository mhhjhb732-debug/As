// =============================================================================
// CCTVSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function startWatchingCams(g: GameEngine): boolean {
    if (g.state !== "playing" || g.isGhost || g.camerasDownT > 0) return false;
    const p = g.entities[0];
    if (p.jailedT > 0) return false;
    if (Math.hypot(p.x - g.monitorPos.x, p.z - g.monitorPos.z) > CAM_WATCH_RANGE) return false;
    g.camView = 0;
    g.camYawOff = 0;
    g.camPitchOff = 0;
    g.setMove(0, 0);
    return true;
}

export function stopWatchingCams(g: GameEngine) {
    g.camView = -1;
}

export function switchCam(g: GameEngine, dir: number) {
    if (g.camView < 0) return;
    const n = CAMERAS.length;
    g.camView = (g.camView + dir + n) % n;
    g.camYawOff = 0;
    g.camPitchOff = 0;
}

export function rotateCam(g: GameEngine, dx: number, dy: number) {
    if (g.camView < 0) return;
    g.camYawOff = Math.max(-1.5, Math.min(1.5, g.camYawOff - dx * 0.005));
    g.camPitchOff = Math.max(-0.45, Math.min(0.5, g.camPitchOff - dy * 0.004));
}

export function getCamLog(g: GameEngine): { id: number; name: string; color: string; room: string; secsAgo: number }[] {
    const out: { id: number; name: string; color: string; room: string; secsAgo: number }[] = [];
    for (const [id, s] of g.sightMap) {
      const secsAgo = g.worldT - s.t;
      if (secsAgo > SIGHT_MAX_AGE) continue;
      const e = g.entities.find((en) => en.info.id === id);
      if (!e) continue;
      out.push({ id, name: id === 0 ? "شما" : e.info.name, color: e.info.color, room: s.room, secsAgo });
    }
    return out.sort((a, b) => a.secsAgo - b.secsAgo);
}

export function getCamHint(g: GameEngine): { suspectId: number; room: string; secsAgo: number } | null {
    const lastBody = g.bodies[g.bodies.length - 1];
    if (!lastBody) return null;
    const s = g.sightMap.get(lastBody.killerId);
    if (!s) return null;
    const secsAgo = g.worldT - s.t;
    if (secsAgo > 45) return null;
    const killer = g.entities.find((e) => e.info.id === lastBody.killerId);
    if (!killer || !killer.info.alive) return null;
    return { suspectId: lastBody.killerId, room: s.room, secsAgo };
}

export function getCamRoomName(g: GameEngine): string {
    if (g.camView < 0 || !CAMERAS[g.camView]) return "";
    const c = CAMERAS[g.camView];
    return roomNameAt(c.x, c.z);
}

export function killCams(g: GameEngine, duration: number) {
    g.camerasDownT = duration;
    g.camView = -1;
    g.sightMap.clear();
    g.cameraEvidence = null;
    for (const m of g.camLEDs) {
      m.emissiveIntensity = 0;
      m.color.set(0x333333);
    }
    g.onEvent({ type: "camsDown" });
}

export function sabotageCameras(g: GameEngine) {
    if (g.state !== "playing" || g.isGhost) return;
    const p = g.entities[0];
    if (!p.info.isImpostor || p.jailedT > 0) return;
    if (g.camCd > 0 || g.camerasDownT > 0) return;
    g.camCd = CAM_CD;
    // wipe the sighting log — nothing from before/during the blackout is reviewable
    g.killCams(CAM_DOWN_TIME);
}

export function inCameraView(g: GameEngine, x: number, z: number): boolean {
    if (g.camerasDownT > 0) return false;
    for (const c of CAMERAS) {
      if (Math.hypot(c.x - x, c.z - z) < CAM_VIEW_RANGE) return true;
    }
    return false;
}
