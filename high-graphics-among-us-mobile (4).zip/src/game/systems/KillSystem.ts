// =============================================================================
// KillSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function bodyClue(g: GameEngine): string {
    const b = g.nearestBody();
    if (!b) return "";
    const killer = g.entities.find((e) => e.info.id === b.killerId);
    if (!killer || !killer.info.alive) return "🔍 سرنخ: قاتل دیگر زنده نیست...";
    if (killer.bloodyT > 0)
      return `🔍 سرنخ: ردپای خونی به سمت «${roomNameAt(killer.x, killer.z)}» می‌رود!`;
    return "🔍 سرنخ: ردپاها محو شده‌اند... قتل مدتی پیش رخ داده";
}

export function pressReport(g: GameEngine) {
    if (g.state !== "playing" || g.isGhost || g.entities[0].jailedT > 0) return;
    const b = g.nearestBody();
    if (!b) return;
    g.startMeeting({ reason: "body", reporterId: 0, victimId: b.victimId, accusedId: null });
}

export function pressKill(g: GameEngine) {
    if (g.state !== "playing" || g.isGhost) return;
    const p = g.entities[0];
    if (!p.info.isImpostor || g.playerKillCd > 0 || p.jailedT > 0) return;
    const victim = g.nearestVictim();
    if (!victim) return;
    // STEALTH KILL: if the murder would be caught on CCTV and the camera
    // sabotage is ready, burn it automatically at the moment of the kill
    if (
      g.camerasDownT <= 0 &&
      g.camCd <= 0 &&
      (g.inCameraView(p.x, p.z) || g.inCameraView(victim.x, victim.z))
    ) {
      g.camCd = CAM_CD;
      g.killCams(CAM_DOWN_TIME_BOT);
      g.onEvent({ type: "stealthKill" });
    }
    g.kill(p, victim);
    g.playerKillCd = KILL_COOLDOWN;
    g.coins += COIN_KILL;
    g.shake = 0.55;
    g.onEvent({ type: "killFlash" });
}

export function nearestBody(g: GameEngine): Body | null {
    const p = g.entities[0];
    let best: Body | null = null;
    let bd = REPORT_RANGE;
    for (const b of g.bodies) {
      const d = Math.hypot(p.x - b.x, p.z - b.z);
      if (d < bd) {
        bd = d;
        best = b;
      }
    }
    return best;
}

export function nearestVictim(g: GameEngine): Entity | null {
    const p = g.entities[0];
    let best: Entity | null = null;
    let bd = KILL_RANGE;
    for (const e of g.entities) {
      if (e === p || !e.info.alive || e.info.isImpostor || e.jailedT > 0) continue;
      const d = Math.hypot(p.x - e.x, p.z - e.z);
      // no kills through walls
      if (d < bd && directWalkable(p.x, p.z, e.x, e.z)) {
        bd = d;
        best = e;
      }
    }
    return best;
}

export function fleePath(g: GameEngine, e: Entity, from: Entity): NavNode[] {
    let best: NavNode = NODES[0];
    let bd = -1;
    for (const n of NODES) {
      if (n.id === "prison") continue;
      const d = Math.hypot(n.x - from.x, n.z - from.z);
      if (d > bd) {
        bd = d;
        best = n;
      }
    }
    const start = nearestNode(e.x, e.z);
    const p = findPath(start.id, best.id);
    if (Math.hypot(start.x - e.x, start.z - e.z) > 0.6) p.unshift(start);
    return p;
}

export function kill(g: GameEngine, killer: Entity, victim: Entity) {
    victim.info.alive = false;
    victim.rig.group.visible = false;
    victim.rig.bubble.visible = false;
    victim.social = "none";
    victim.leadKind = null;
    // clear pending proposal if the victim was the proposing bot or the player
    if (
      g.activeProposal &&
      (g.activeProposal.botId === victim.info.id || victim.info.id === 0)
    ) {
      g.activeProposal = null;
      g.onEvent({ type: "proposalOver" });
    }
    const corpse = makeCorpse(victim.info.color);
    corpse.position.set(victim.x, 0, victim.z);
    corpse.rotation.y = Math.random() * Math.PI * 2;
    corpse.scale.setScalar(0.15);
    g.scene.add(corpse);
    g.bodies.push({
      victimId: victim.info.id,
      killerId: killer.info.id,
      x: victim.x,
      z: victim.z,
      mesh: corpse,
    });
    g.anims.push({ obj: corpse, t: 0, dur: 0.45, kind: "corpse" });

    // CCTV catches the murder!
    if (g.inCameraView(killer.x, killer.z) || g.inCameraView(victim.x, victim.z)) {
      g.cameraEvidence = killer.info.id;
    }

    // killer steps in blood — leaves footprints
    killer.bloodyT = BLOODY_TIME;
    killer.lastPX = killer.x;
    killer.lastPZ = killer.z;

    // accomplice payout — the joint-murder plan succeeded
    if (
      g.pendingMurder &&
      killer.info.id === g.pendingMurder.botId &&
      victim.info.id === g.pendingMurder.targetId
    ) {
      if (g.entities[0].info.alive) {
        g.coins += g.pendingMurder.reward;
        setTimeout(() => g.say(killer, "سهمت... حالا خفه‌خون بگیر 🔪🤝", 3), 1200);
      }
      g.pendingMurder = null;
    } else if (g.pendingMurder && victim.info.id === g.pendingMurder.targetId) {
      // someone else got there first — plan is void
      g.pendingMurder = null;
    }

    // rising soul animation
    const soul = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.35, 0.5, 4, 10),
      new THREE.MeshStandardMaterial({
        color: 0xdfefff,
        emissive: 0x9db8e0,
        emissiveIntensity: 0.7,
        transparent: true,
        opacity: 0.55,
        depthWrite: false,
      }),
    );
    soul.position.set(victim.x, 1.1, victim.z);
    g.scene.add(soul);
    g.anims.push({ obj: soul, t: 0, dur: 2.4, kind: "ghost" });

    const blackout = g.sab?.kind === "lights";
    for (const w of g.entities) {
      if (w === killer || w === victim || !w.info.alive || !w.info.isBot) continue;
      if (w.info.isImpostor) continue;
      const d = Math.hypot(w.x - killer.x, w.z - killer.z);
      const range = blackout ? WITNESS_RANGE_DARK : WITNESS_RANGE; // darkness hides murder
      // NO GOD-MODE: a wall blocks witnessing entirely
      const los = directWalkable(w.x, w.z, killer.x, killer.z);
      if (d < range && los && Math.random() < (blackout ? 0.4 : 0.8)) {
        g.witnesses.set(killer.info.id, w.info.id);
        // memory: very close + clear view = watched the kill; otherwise only
        // "saw the killer near the body" — the bot may NOT claim more later
        const sawKill = d < SAW_KILL_RANGE && !blackout;
        w.mind?.remember({
          kind: sawKill ? "sawKill" : "nearBody",
          aboutId: killer.info.id,
          source: "self",
          reliability: sawKill ? 0.95 : 0.65,
          t: g.worldT,
        });
        // fear scales with the bot's own personality
        if (w.jailedT <= 0 && (w.mind?.traits.fear ?? 0.5) > 0.2) {
          w.social = "none";
          w.leadKind = null;
          w.dwell = 0;
          w.path = g.fleePath(w, killer);
          g.say(w, "وای نه!! قاتل!! 😱🏃", 3);
        }
      }
    }
    if (victim.info.id === 0) {
      g.isGhost = true;
      g.shake = 0.7;
      g.camView = -1;
      g.standUp();
      g.onEvent({ type: "playerKilled", byId: killer.info.id });
    }
    g.checkWin();
}
