// =============================================================================
// SocialSystem — extracted from GameEngine. Functions receive the engine as `g`
// (orchestrator pattern): logic lives here, state lives on the engine.
// =============================================================================
/* eslint-disable */
// @ts-nocheck
import * as THREE from "three";
import type { GameEngine } from "../engine";
import {
  CAMERAS, COLORS, EMERGENCY_POS, FIX_POINTS, GAME_KINDS, MORGUE, NODES,
  PRISON, PRISON_CENTER, SINGLE_TASK_POOL, SPAWN_RING, STATIONS, TASK_CHAINS,
  canStand, directWalkable, findPath, nearestNode, roomNameAt,
} from "../mapData";
import type { NavNode } from "../mapData";
import { makeCorpse, drawBubble } from "../world";
import { PLAYER_SPEED, BOT_SPEED, SOCIAL_BOT_SPEED, FIXER_SPEED_MULT, RADIUS, KILL_RANGE, REPORT_RANGE, USE_RANGE, TALK_RANGE, SIT_RANGE, KILL_COOLDOWN, SAB_COOLDOWN, REACTOR_TIME, JAIL_TIME, CAM_VIEW_RANGE, CAM_DOWN_TIME, CAM_DOWN_TIME_BOT, CAM_CD, CAM_WATCH_RANGE, SIGHT_MAX_AGE, BLOODY_TIME, WITNESS_RANGE, WITNESS_RANGE_DARK, SAW_KILL_RANGE, DISCUSS_TIME, VOTE_TIME, BRIBE_COST, FRAME_COST, DISRUPT_COST, COIN_TASK, COIN_FIX, COIN_KILL, COIN_SURVIVE, COIN_COOP, EV } from "../constants";

export function sitDown(g: GameEngine) {
    if (g.state !== "playing" || g.isGhost || g.sab) return;
    const p = g.entities[0];
    if (p.jailedT > 0) return;
    if (Math.hypot(p.x - EMERGENCY_POS.x, p.z - EMERGENCY_POS.z) > SIT_RANGE) return;
    g.sitting = true;
    g.camView = -1;
    g.setMove(0, 0);
    // seat the player facing the table
    const ang = Math.atan2(p.z - EMERGENCY_POS.z, p.x - EMERGENCY_POS.x);
    p.x = EMERGENCY_POS.x + Math.cos(ang) * 1.9;
    p.z = EMERGENCY_POS.z + Math.sin(ang) * 1.9;
    p.yaw = Math.atan2(EMERGENCY_POS.x - p.x, EMERGENCY_POS.z - p.z);
    p.rig.group.position.set(p.x, 0, p.z);
    // invite up to 2 idle bots to join the chat
    const idle = g.entities.filter(
      (e) =>
        e.info.isBot &&
        e.info.alive &&
        e.social === "none" &&
        e.jailedT <= 0 &&
        !g.grudges.has(e.info.id) &&
        !g.fixerIds.has(e.info.id),
    );
    idle.sort(
      (a, b) =>
        Math.hypot(a.x - EMERGENCY_POS.x, a.z - EMERGENCY_POS.z) -
        Math.hypot(b.x - EMERGENCY_POS.x, b.z - EMERGENCY_POS.z),
    );
    idle.slice(0, 2).forEach((e, i) => {
      const sa = ang + ((i === 0 ? 1 : -1) * Math.PI * 2) / 3;
      e.seatX = EMERGENCY_POS.x + Math.cos(sa) * 1.9;
      e.seatZ = EMERGENCY_POS.z + Math.sin(sa) * 1.9;
      e.social = "table";
      e.socialT = 40 + Math.random() * 15;
      e.repathT = 0;
      e.dwell = 0;
      e.chatterT = 4 + i * 4 + Math.random() * 3;
    });
    if (idle.length) g.say(idle[0], "اومدم! بشینیم گپ بزنیم ☕", 3);
}

export function standUp(g: GameEngine) {
    if (!g.sitting) return;
    g.sitting = false;
    // guests get up too
    for (const e of g.entities) {
      if (e.social === "table") {
        e.social = "none";
        e.path = [];
        e.dwell = 1 + Math.random() * 2;
      }
    }
}

export function tableSay(g: GameEngine, idx: number): string {
    if (!g.sitting) return "";
    const lines = [
      "خب... چه خبرا؟ ☕",
      "به نظرتون خائن کیه؟ 🤔",
      "امروز چندتا وظیفه انجام دادی؟",
      "یه جوک بگم؟ 😄",
    ];
    const myLine = lines[idx] ?? lines[0];
    const guests = g.entities.filter((e) => e.social === "table" && e.info.alive);
    const guest = guests[Math.floor(Math.random() * guests.length)];
    if (guest) {
      const replies: string[][] = [
        ["هیچی بابا... فقط دعا می‌کنم زنده بمونم 😅", "خبر که زیاده... ولی هیچکدوم خوب نیست!"],
        guest.info.isImpostor
          ? ["والا من که به همه شک دارم... مخصوصاً اونایی که ساکتن 🤫", "نمی‌دونم، ولی مطمئنم تو نیستی رفیق! 😉"]
          : ["یه حسی بهم میگه نزدیکه... خیلی نزدیک 😰", "هرکی تنها می‌گرده مشکوکه!"],
        ["سه‌تا! دارم می‌ترکونم 💪", "هیچی... از ترسم از اتاق بیرون نرفتم 😅"],
        ["بگو بخندیم! 😄", "الان وقت جوکه؟! ... باشه بگو 😂"],
      ];
      const pool = replies[idx] ?? replies[0];
      setTimeout(() => g.say(guest, pool[Math.floor(Math.random() * pool.length)], 4), 700);
    }
    return myLine;
}

export function nearestTalkable(g: GameEngine): Entity | null {
    const p = g.entities[0];
    let best: Entity | null = null;
    let bd = TALK_RANGE;
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || e.jailedT > 0) continue;
      const d = Math.hypot(p.x - e.x, p.z - e.z);
      if (d < bd) {
        bd = d;
        best = e;
      }
    }
    return best;
}

export function say(g: GameEngine, e: Entity, text: string, dur = 3.6) {
    drawBubble(e.rig, text);
    e.bubbleT = dur;
}

export function playerTalk(g: GameEngine, kind: TalkKind): string {
    const bot = g.nearestTalkable();
    const p = g.entities[0];
    if (!bot || g.state !== "playing" || g.isGhost || p.jailedT > 0) return "";
    if (bot.jailedT > 0) return "";
    // face each other
    bot.targetYaw = Math.atan2(p.x - bot.x, p.z - bot.z);
    let myLine = "";
    switch (kind) {
      case "hi": {
        myLine = "سلام! 👋";
        const replies = [
          "سلام رفیق! مواظب خودت باش 👋",
          `سلام! این طرفا امن نیست...`,
          "درود! داشتم وظایفم رو انجام می‌دادم.",
          "سلام! جایی جسد ندیدی؟ 😰",
        ];
        setTimeout(() => g.say(bot, replies[Math.floor(Math.random() * replies.length)]), 500);
        break;
      }
      case "who": {
        myLine = "به کی مشکوکی؟ 🤔";
        setTimeout(() => {
          const intel = g.getIntel();
          if (intel.suspectId !== null && intel.witnessId === bot.info.id) {
            g.say(bot, `${g.entities.find((e) => e.info.id === intel.suspectId)?.info.name} رو نزدیک جسد دیدم! 🔪`);
          } else if (bot.info.isImpostor) {
            const targets = g.entities.filter(
              (e) => e.info.isBot && e.info.alive && !e.info.isImpostor && e !== bot,
            );
            const t = targets[Math.floor(Math.random() * targets.length)];
            g.say(bot, t ? `راستش... ${t.info.name} خیلی مشکوک می‌زنه 🤫` : "نمی‌دونم والا...");
          } else {
            const opts = [
              "هنوز مطمئن نیستم... 🤷",
              "همه مشکوکن! به هیچکس اعتماد نکن.",
              "کسی که تنها می‌گرده مشکوکه...",
            ];
            g.say(bot, opts[Math.floor(Math.random() * opts.length)]);
          }
        }, 500);
        break;
      }
      case "follow": {
        myLine = "دنبالم بیا! 🚶";
        // impostor always accepts (dangerous!), crew usually
        if (bot.info.isImpostor || Math.random() < 0.8) {
          bot.social = "buddy";
          bot.socialT = 35;
          bot.path = [];
          setTimeout(() => g.say(bot, "باشه، پشت سرتم! 👍"), 500);
        } else {
          setTimeout(() => g.say(bot, "شرمنده، کار دارم... 🏃"), 500);
        }
        break;
      }
      case "leave": {
        myLine = "برو پی کارت! 😠";
        if (g.activeProposal?.botId === bot.info.id) {
          g.activeProposal = null;
          g.onEvent({ type: "proposalOver" });
        }
        bot.social = "none";
        bot.leadKind = null;
        bot.path = [];
        bot.dwell = 0;
        setTimeout(() => g.say(bot, "باشه باشه، رفتم... 😒"), 500);
        break;
      }
    }
    return myLine;
}

export function respondProposal(g: GameEngine, accept: boolean, prop?: { reward?: number; targetId?: number }) {
    if (!g.activeProposal) return;
    const bot = g.entities.find((e) => e.info.id === g.activeProposal!.botId);
    const kind = g.activeProposal.kind;
    g.activeProposal = null;
    if (!bot || !bot.info.alive) return;

    // --- special kinds first ---
    if (kind === "quarrel") {
      g.quarrelBotId = null;
      bot.social = "none";
      bot.dwell = 1.5;
      if (accept && g.spendCoins(g.quarrelReward || 10)) {
        g.grudges.delete(bot.info.id);
        g.say(bot, "هوم... باشه، این دفعه می‌بخشمت 😤");
      } else {
        g.say(bot, "دیگه طرف من نیا! از این به بعد دشمنیم! 😡", 4);
      }
      g.quarrelReward = 0;
      return;
    }
    if (kind === "threat") {
      bot.social = "none";
      bot.dwell = 1.5;
      if (accept) {
        g.threatBotId = bot.info.id;
        g.say(bot, "آفرین... زبونت رو نگه دار 🤫");
      } else {
        g.grudges.add(bot.info.id);
        bot.killCd = Math.min(bot.killCd, 8);
        g.say(bot, "پس خودت خواستی... 🔪😈", 3.5);
      }
      return;
    }
    if (kind === "murder") {
      bot.social = "none";
      bot.dwell = 1;
      if (accept && prop?.targetId !== undefined) {
        g.pendingMurder = {
          botId: bot.info.id,
          targetId: prop.targetId,
          reward: prop.reward ?? 25,
        };
        bot.killCd = Math.min(bot.killCd, 10); // he moves fast now
        g.say(bot, "خوبه... دنبالم بیا و شش‌دنگ حواست باشه 🔪🤫", 3.5);
      } else {
        if (Math.random() < 0.5) {
          g.grudges.add(bot.info.id);
          bot.killCd = Math.min(bot.killCd, 10);
          g.say(bot, "زیادی می‌دونی... این خوب نیست 🔪😠", 3.5);
        } else {
          g.say(bot, "هه... شوخی کردم بابا! 😅 (جدی نگیر)", 3);
        }
      }
      return;
    }
    if (kind === "mission") {
      bot.social = "none";
      bot.dwell = 1.5;
      if (accept && prop?.targetId !== undefined) {
        g.pendingMission = {
          botId: bot.info.id,
          targetId: prop.targetId,
          reward: prop.reward ?? 30,
        };
        g.say(bot, "خوبه... منتظرم. ناامیدم نکن 🔪🤫", 3.5);
      } else {
        // refusing a mission is a death sentence
        g.grudges.add(bot.info.id);
        bot.killCd = Math.min(bot.killCd, 6);
        g.say(bot, "اشتباه بزرگی کردی... بدو تا می‌تونی 🔪😈", 3.5);
      }
      return;
    }
    if (kind === "deal") {
      bot.social = "none";
      bot.dwell = 1.5;
      if (accept && prop?.targetId !== undefined) {
        const reward = prop.reward ?? 10;
        g.coins += reward;
        g.pendingDeal = { botId: bot.info.id, targetId: prop.targetId, reward };
        g.say(bot, "آفرین! یادت نره... من همه چی رو می‌بینم 🤝");
      } else {
        g.say(bot, "باشه... خودت خواستی 😒");
        if (bot.info.isImpostor && Math.random() < 0.4) bot.killCd = Math.min(bot.killCd, 12);
      }
      return;
    }

    if (!accept) {
      bot.social = "none";
      bot.dwell = 1;
      g.say(bot, kind === "lure" ? "حیف شد... باشه 😐" : "باشه، موفق باشی!");
      return;
    }
    switch (kind) {
      case "buddy":
        bot.social = "buddy";
        bot.socialT = 40;
        bot.path = [];
        g.say(bot, "عالیه! با هم امن‌تریم 🤝");
        break;
      case "warn":
        bot.social = "none";
        bot.dwell = 2;
        g.say(bot, "مواظب خودت باش! 👀");
        break;
      case "task":
      case "lure": {
        bot.social = "lead";
        bot.socialT = 45;
        const from = nearestNode(bot.x, bot.z);
        bot.path = findPath(from.id, bot.leadNodeId!);
        if (Math.hypot(from.x - bot.x, from.z - bot.z) > 0.6) bot.path.unshift(from);
        g.say(bot, "دنبالم بیا! 🏃");
        break;
      }
    }
}

export function buildProposal(g: GameEngine, bot: Entity): ProposalData {
    const isImp = bot.info.isImpostor;
    let kind: ProposalKind;
    if (bot.info.id === g.quarrelBotId) {
      kind = "quarrel";
    } else if (isImp && !g.isGhost && !g.entities[0].info.isImpostor) {
      // personality-driven: aggressive impostors threaten, deceivers lure/deal
      const tr = bot.mind?.traits;
      const agg = tr?.aggression ?? 0.5;
      const dec = tr?.deception ?? 0.5;
      const greed = tr?.greed ?? 0.5;
      const r = Math.random();
      kind =
        r < 0.22 * (0.5 + dec)
          ? "lure"
          : r < 0.42 && agg > 0.45
            ? "threat"
            : r < 0.58 && !g.pendingMission && agg > 0.35
              ? "mission"
              : r < 0.76 && !g.pendingMurder && dec > 0.35
                ? "murder"
                : r < 0.9 && greed > 0.3
                  ? "deal"
                  : "buddy";
    } else {
      const tr = bot.mind?.traits;
      const coop = tr?.cooperation ?? 0.5;
      const greed = tr?.greed ?? 0.5;
      const r = Math.random();
      kind =
        r < 0.28 + coop * 0.15
          ? "buddy"
          : r < 0.52
            ? "warn"
            : r < 0.52 + greed * 0.3
              ? "deal"
              : "task";
    }
    let text = "";
    let acceptLabel = "قبول ✓";
    let declineLabel = "نه، ممنون";
    let reward: number | undefined;
    let targetId: number | undefined;
    // only rooms that exist on the active map
    const farRooms = ["reactor", "upperEng", "lowerEng", "nav", "weapons", "comms", "office"].filter(
      (id) => NODES.some((n) => n.id === id),
    );
    if (kind === "quarrel") {
      reward = g.quarrelReward || 10;
      text = `تو بهم خیانت کردی!! پولمو گرفتی و به حرفم گوش ندادی!! 😡 یا پس بده یا دشمن همیم!`;
      acceptLabel = `معذرت! پس می‌دم (${reward}🪙)`;
      declineLabel = "برو بابا! 😒";
    } else if (kind === "threat") {
      text = "گوش کن... 🔪 می‌دونم چی دیدی. اگه توی جلسه اسمی از من بیاری، نفر بعدی خودتی. فهمیدی؟";
      acceptLabel = "باشه... ساکت می‌مونم 😨";
      declineLabel = "ازت نمی‌ترسم! 😤";
    } else if (kind === "murder") {
      // joint-murder proposal: the impostor does the killing, you keep watch
      const targets = g.entities.filter(
        (e) => e.info.isBot && e.info.alive && e !== bot && !e.info.isImpostor && e.jailedT <= 0,
      );
      const t = targets[Math.floor(Math.random() * targets.length)];
      if (!t) {
        kind = "buddy";
        text = "تنها گشتن خطرناکه... می‌خوای با هم بگردیم؟ 🤝";
        acceptLabel = "آره، با هم 🤝";
      } else {
        targetId = t.info.id;
        reward = 25;
        text = `🔪🤫 بیا شریک جرم شیم... من «${t.info.name}» رو می‌کشم، تو فقط حواست باشه کسی نیاد و جایی گزارش نکن. سهمت ${reward} سکه. هستی؟`;
        acceptLabel = "هستم... 😈";
        declineLabel = "من قاتل نیستم!";
      }
    } else if (kind === "mission") {
      // forced elimination contract
      const targets = g.entities.filter(
        (e) => e.info.isBot && e.info.alive && e !== bot && !e.info.isImpostor && e.jailedT <= 0,
      );
      const t = targets[Math.floor(Math.random() * targets.length)];
      if (!t) {
        kind = "threat";
        text = "گوش کن... 🔪 اگه توی جلسه اسمی از من بیاری، نفر بعدی خودتی. فهمیدی؟";
        acceptLabel = "باشه... ساکت می‌مونم 😨";
        declineLabel = "ازت نمی‌ترسم! 😤";
      } else {
        targetId = t.info.id;
        reward = 30;
        text = `🔪 یه مأموریت برات دارم... کاری کن «${t.info.name}» توی جلسه بعدی حذف بشه. موفق بشی ${reward} سکه می‌گیری... شکست بخوری، خودت نفر بعدی هستی. انتخابی نداری!`;
        acceptLabel = "انجامش می‌دم... 😰";
        declineLabel = "هرگز! 😤";
      }
    } else if (kind === "deal") {
      reward = bot.info.isImpostor ? 20 : 10;
      // pick a target the proposer wants voted out
      const others = g.entities.filter(
        (e) => e.info.isBot && e.info.alive && e !== bot && e.jailedT <= 0 && !(bot.info.isImpostor && e.info.isImpostor),
      );
      const t = others[Math.floor(Math.random() * others.length)];
      if (!t) {
        // fallback to buddy proposal
        kind = "buddy";
        text = "تنها گشتن خطرناکه... می‌خوای با هم بگردیم؟ 🤝";
        acceptLabel = "آره، با هم 🤝";
        return {
          botId: bot.info.id,
          botName: bot.info.name,
          botColor: bot.info.color,
          botHat: bot.info.hat,
          kind,
          text,
          acceptLabel,
          declineLabel,
        };
      }
      targetId = t.info.id;
      text = `یه معامله... 🤫 این ${reward} سکه مال تو. فقط توی جلسه بعدی به «${t.info.name}» رأی بده. قبوله؟`;
      acceptLabel = `سکه‌ها رو بده 🪙`;
      declineLabel = "معامله نمی‌کنم";
    } else if (kind === "lure") {
      const nid = farRooms[Math.floor(Math.random() * farRooms.length)];
      bot.leadNodeId = nid;
      bot.leadKind = "lure";
      const roomName = roomNameAt(
        NODES.find((n) => n.id === nid)!.x,
        NODES.find((n) => n.id === nid)!.z,
      );
      text = `یه چیز خیلی عجیب توی ${roomName} دیدم... بیا نشونت بدم! 👀`;
      acceptLabel = "بریم ببینم 🚶";
      declineLabel = "نمیام 🙅";
    } else if (kind === "task") {
      const nid = farRooms[Math.floor(Math.random() * farRooms.length)];
      bot.leadNodeId = nid;
      bot.leadKind = "task";
      const roomName = roomNameAt(
        NODES.find((n) => n.id === nid)!.x,
        NODES.find((n) => n.id === nid)!.z,
      );
      text = `می‌خوام برم ${roomName} وظیفه انجام بدم. با هم بریم؟ تنهایی خطرناکه!`;
      acceptLabel = "با هم بریم 🤝";
    } else if (kind === "buddy") {
      text = "تنها گشتن خطرناکه... می‌خوای با هم بگردیم؟ 🤝";
      acceptLabel = "آره، با هم 🤝";
    } else {
      // warn — use intel or a fabricated hunch
      const intel = g.getIntel();
      let suspectName: string | null = null;
      if (intel.suspectId !== null && intel.suspectId !== 0) {
        suspectName = g.entities.find((e) => e.info.id === intel.suspectId)?.info.name ?? null;
      }
      if (!suspectName) {
        const others = g.entities.filter(
          (e) => e.info.isBot && e.info.alive && e !== bot && (!e.info.isImpostor || !bot.info.isImpostor),
        );
        // impostor bot spreads lies about crew; crew guesses randomly
        const pool = bot.info.isImpostor ? others.filter((e) => !e.info.isImpostor) : others;
        suspectName = pool[Math.floor(Math.random() * pool.length)]?.info.name ?? null;
      }
      text = suspectName
        ? `هی! مواظب ${suspectName} باش... رفتارش خیلی عجیبه 🤫`
        : "یه حس بدی دارم... مواظب باش!";
      acceptLabel = "ممنون از هشدار 🙏";
      declineLabel = "باور نمی‌کنم";
    }
    return {
      botId: bot.info.id,
      botName: bot.info.name,
      botColor: bot.info.color,
      botHat: bot.info.hat,
      kind,
      text,
      acceptLabel,
      declineLabel,
      reward,
      targetId,
    };
}

export function updateSocial(g: GameEngine, dt: number) {
    const p = g.entities[0];
    if (g.isGhost) return;

    // spawn a new approach
    g.socialTimer -= dt;
    if (
      g.socialTimer <= 0 &&
      !g.activeProposal &&
      !g.sab &&
      p.jailedT <= 0
    ) {
      g.socialTimer = 26 + Math.random() * 22;
      // grudge quarrel takes priority: the betrayed bot storms toward you
      const quarrelBot =
        g.quarrelBotId !== null
          ? g.entities.find(
              (e) =>
                e.info.id === g.quarrelBotId &&
                e.info.alive &&
                e.social === "none" &&
                e.jailedT <= 0,
            )
          : undefined;
      if (quarrelBot) {
        quarrelBot.social = "approach";
        quarrelBot.socialT = 30;
        quarrelBot.repathT = 0;
        quarrelBot.dwell = 0;
        g.say(quarrelBot, "هی تو!! وایسا ببینم!! 😡", 3);
      } else {
        const candidates = g.entities.filter(
          (e) =>
            e.info.isBot &&
            e.info.alive &&
            e.social === "none" &&
            e.jailedT <= 0 &&
            !g.grudges.has(e.info.id) &&
            !g.fixerIds.has(e.info.id),
        );
        if (candidates.length) {
          const bot = candidates[Math.floor(Math.random() * candidates.length)];
          bot.social = "approach";
          bot.socialT = 26;
          bot.repathT = 0;
          bot.dwell = 0;
        }
      }
    }

    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive || e.social === "none") continue;
      e.socialT -= dt;

      if (e.social === "approach") {
        const d = Math.hypot(p.x - e.x, p.z - e.z);
        e.repathT -= dt;
        if (d < 2.6) {
          // arrived — make the proposal
          e.social = "await";
          e.socialT = 14;
          e.path = [];
          e.targetYaw = Math.atan2(p.x - e.x, p.z - e.z);
          const prop = g.buildProposal(e);
          g.activeProposal = { botId: e.info.id, kind: prop.kind };
          g.say(e, "هی! یه لحظه وایسا... ✋", 2.5);
          g.onEvent({ type: "proposal", data: prop });
        } else if (e.repathT <= 0) {
          e.repathT = 0.5;
          if (directWalkable(e.x, e.z, p.x, p.z)) {
            e.path = [{ id: "__player__", x: p.x, z: p.z }];
          } else {
            const from = nearestNode(e.x, e.z);
            const to = nearestNode(p.x, p.z);
            e.path = findPath(from.id, to.id);
            if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
          }
        }
        if (e.socialT <= 0) {
          e.social = "none";
          e.path = [];
          if (g.activeProposal?.botId === e.info.id) g.activeProposal = null;
        }
      } else if (e.social === "await") {
        e.path = [];
        e.walking = false;
        e.targetYaw = Math.atan2(p.x - e.x, p.z - e.z);
        if (e.socialT <= 0) {
          e.social = "none";
          e.dwell = 1;
          if (g.activeProposal?.botId === e.info.id) {
            g.activeProposal = null;
            g.onEvent({ type: "proposalOver" });
            g.say(e, "باشه... بعداً حرف می‌زنیم 😕");
          }
        }
      } else if (e.social === "buddy") {
        const d = Math.hypot(p.x - e.x, p.z - e.z);
        e.repathT -= dt;
        if (d > 2.0 && e.repathT <= 0) {
          e.repathT = 0.4;
          // BUGFIX: follow the *player position* directly when line-of-walk is clear,
          // instead of only walking to the nearest nav node (which made bots stall)
          if (directWalkable(e.x, e.z, p.x, p.z)) {
            e.path = [{ id: "__player__", x: p.x, z: p.z }];
          } else {
            const from = nearestNode(e.x, e.z);
            const to = nearestNode(p.x, p.z);
            e.path = findPath(from.id, to.id);
            if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
            e.path.push({ id: "__player__", x: p.x, z: p.z });
          }
        } else if (d <= 2.0) {
          e.path = [];
          e.walking = false;
          e.targetYaw = Math.atan2(p.x - e.x, p.z - e.z);
        }
        // impostor buddy may strike when alone!
        if (e.info.isImpostor && e.killCd <= 0 && d < 2.1) {
          let seen = 0;
          for (const w of g.entities) {
            if (w === e || w === p || !w.info.alive) continue;
            if (Math.hypot(w.x - e.x, w.z - e.z) < 9) seen++;
          }
          if (seen === 0) {
            g.say(e, "هه‌هه... چه ساده بودی 🔪", 2.5);
            g.kill(e, p);
            e.killCd = 26 + Math.random() * 12;
            e.social = "none";
            continue;
          }
        }
        if (e.socialT <= 0) {
          e.social = "none";
          g.say(e, "من میرم به وظایفم برسم. مراقب باش! 👋");
          e.dwell = 1;
        }
      } else if (e.social === "table") {
        // walk to the seat, then sit facing the table and gossip
        const d = Math.hypot(e.seatX - e.x, e.seatZ - e.z);
        if (d > 0.45) {
          e.repathT -= dt;
          if (e.repathT <= 0) {
            e.repathT = 0.6;
            if (directWalkable(e.x, e.z, e.seatX, e.seatZ)) {
              e.path = [{ id: "__seat__", x: e.seatX, z: e.seatZ }];
            } else {
              const from = nearestNode(e.x, e.z);
              const to = nearestNode(e.seatX, e.seatZ);
              e.path = findPath(from.id, to.id);
              if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
              e.path.push({ id: "__seat__", x: e.seatX, z: e.seatZ });
            }
          }
        } else {
          e.path = [];
          e.walking = false;
          e.targetYaw = Math.atan2(EMERGENCY_POS.x - e.x, EMERGENCY_POS.z - e.z);
          // table gossip
          e.chatterT -= dt;
          if (e.chatterT <= 0 && e.bubbleT <= 0) {
            e.chatterT = 8 + Math.random() * 8;
            const gossip = [
              "این میز بهترین جای سفینه‌ست ☕",
              "دیشب یه صدای عجیب از موتورخونه شنیدم... 😨",
              "کاش قهوه داشتیم!",
              "بین خودمون بمونه... به زردـه اعتماد ندارم 🤫",
              "بعد از این ماموریت میرم تعطیلات 🏖",
            ];
            g.say(e, gossip[Math.floor(Math.random() * gossip.length)], 3.5);
          }
        }
        if (e.socialT <= 0 || !g.sitting) {
          e.social = "none";
          e.path = [];
          e.dwell = 1;
          if (g.sitting && e.bubbleT <= 0) g.say(e, "من برم به کارام برسم... 👋", 2.5);
        }
      } else if (e.social === "lead") {
        const dest = NODES.find((n) => n.id === e.leadNodeId);
        if (!dest) {
          e.social = "none";
          continue;
        }
        const dDest = Math.hypot(dest.x - e.x, dest.z - e.z);
        const dPlayer = Math.hypot(p.x - e.x, p.z - e.z);
        // wait for player if too far behind
        if (dPlayer > 7) {
          e.path = [];
          e.walking = false;
          if (e.bubbleT <= 0) g.say(e, "بیا دیگه! عجله کن 🏃", 2.5);
        } else if (e.path.length === 0 && dDest > 1.6) {
          const from = nearestNode(e.x, e.z);
          e.path = findPath(from.id, e.leadNodeId!);
          if (Math.hypot(from.x - e.x, from.z - e.z) > 0.6) e.path.unshift(from);
        }
        if (dDest < 1.8 && dPlayer < 4) {
          // arrived together
          if (e.leadKind === "lure" && e.info.isImpostor) {
            let seen = 0;
            for (const w of g.entities) {
              if (w === e || w === p || !w.info.alive) continue;
              if (Math.hypot(w.x - e.x, w.z - e.z) < 10) seen++;
            }
            if (seen === 0) {
              g.say(e, "چیز عجیب... خودتی! 🔪😈", 2.5);
              g.kill(e, p);
              e.killCd = 26 + Math.random() * 12;
            } else {
              g.say(e, "اِ... فکر کنم اشتباه دیدم 😅");
            }
          } else {
            g.say(e, "رسیدیم! من اینجا وظیفه دارم. ممنون که اومدی 🙏");
            g.coins += COIN_COOP; // reward for cooperating
          }
          e.social = "none";
          e.leadKind = null;
          e.dwell = 3;
        }
        if (e.socialT <= 0) {
          e.social = "none";
          e.leadKind = null;
        }
      }
    }

    // ambient chatter between nearby bots
    for (const e of g.entities) {
      if (!e.info.isBot || !e.info.alive) continue;
      e.chatterT -= dt;
      if (e.chatterT <= 0) {
        e.chatterT = (30 + Math.random() * 45) * (1.6 - (e.mind?.traits.curiosity ?? 0.5));
        const near = g.entities.find(
          (o) => o !== e && o.info.isBot && o.info.alive && Math.hypot(o.x - e.x, o.z - e.z) < 5,
        );
        if (near && e.bubbleT <= 0) {
          const lines = [
            "این راهروها منو می‌ترسونه... 😨",
            "وظایفت تموم شد؟",
            "یکی داشت دنبالم میومد... 👀",
            "کاش زودتر تموم شه!",
            "به هیچکس اعتماد ندارم...",
          ];
          g.say(e, lines[Math.floor(Math.random() * lines.length)], 3);
        }
      }
    }
}
