// ---- central gameplay configuration (no magic numbers in systems) ---------

export const PLAYER_SPEED = 4.0;
export const BOT_SPEED = 2.35;
export const SOCIAL_BOT_SPEED = 3.7; // bots hurrying to the player
export const FIXER_SPEED_MULT = 1.5;
export const RADIUS = 0.45;

export const KILL_RANGE = 2.4;
export const REPORT_RANGE = 3.6;
export const USE_RANGE = 2.6;
export const TALK_RANGE = 3.4;
export const SIT_RANGE = 3.4;

export const KILL_COOLDOWN = 32;
export const SAB_COOLDOWN = 42;
export const REACTOR_TIME = 40;
export const JAIL_TIME = 35;

export const CAM_VIEW_RANGE = 8; // CCTV coverage radius
export const CAM_DOWN_TIME = 40; // player sabotage
export const CAM_DOWN_TIME_BOT = 32; // smart bot sabotage
export const CAM_CD = 55;
export const CAM_WATCH_RANGE = 3.6;
export const SIGHT_MAX_AGE = 60; // seconds a CCTV sighting stays reviewable

export const BLOODY_TIME = 16; // footprint trail duration
export const WITNESS_RANGE = 8.5;
export const WITNESS_RANGE_DARK = 3.5;
export const SAW_KILL_RANGE = 4.5; // closer than this + LOS = direct witness

export const DISCUSS_TIME = 15;
export const VOTE_TIME = 30;
export const BRIBE_COST = 25;
export const FRAME_COST = 15;
export const DISRUPT_COST = 40;

export const COIN_TASK = 8;
export const COIN_FIX = 12;
export const COIN_KILL = 15;
export const COIN_SURVIVE = 6;
export const COIN_COOP = 5;

// ---- evidence weights for bot voting (scaled 0..100) -----------------------
export const EV = {
  SAW_KILL: 80,
  NEAR_BODY: 25,
  PROVEN_LIE: 35,
  HEARD_SUSPICION: 12,
  ACCUSED_NO_PROOF: 5,
  GOOD_DEFENSE: -15,
  BETRAYED_ME: 40,
  THREATENED_ME: 30,
  VOTED_AGAINST_ME: 15,
  DEALT_WITH_ME: -10,
  CAMERA_PROOF: 60,
  VOTE_THRESHOLD: 30, // minimum score before a bot votes for someone
} as const;
