// ---- user settings persisted in localStorage --------------------------------

export type Quality = "low" | "medium" | "high" | "ultra";

export type OrientationPref = "auto" | "landscape" | "portrait";

export type VoiceLang = "en" | "off";

export interface GameSettings {
  quality: Quality;
  fps: 30 | 60;
  volume: number; // 0..1
  joySize: number; // px
  orientation: OrientationPref;
  voiceLang: VoiceLang;
}

const KEY = "amongus-fa-settings";

/** Apple devices (iPhone/iPad/Mac) have strong GPUs — run max graphics */
export function isAppleDevice(): boolean {
  const ua = navigator.userAgent;
  return (
    /iPhone|iPad|iPod|Macintosh/.test(ua) ||
    // iPadOS 13+ reports as Mac with touch
    (navigator.maxTouchPoints > 1 && /Mac/.test(ua))
  );
}

const DEFAULTS: GameSettings = {
  quality: isAppleDevice() ? "ultra" : "high",
  fps: 60,
  volume: 0.8,
  joySize: 132,
  orientation: "landscape",
  voiceLang: "en",
};

let cache: GameSettings | null = null;

export function getSettings(): GameSettings {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<GameSettings>;
      cache = {
        quality: (["low", "medium", "high", "ultra"] as const).includes(p.quality as Quality)
          ? (p.quality as Quality)
          : DEFAULTS.quality,
        fps: p.fps === 30 ? 30 : 60,
        volume: typeof p.volume === "number" ? Math.min(1, Math.max(0, p.volume)) : DEFAULTS.volume,
        joySize:
          typeof p.joySize === "number" ? Math.min(180, Math.max(96, p.joySize)) : DEFAULTS.joySize,
        orientation: (["auto", "landscape", "portrait"] as const).includes(
          p.orientation as OrientationPref,
        )
          ? (p.orientation as OrientationPref)
          : DEFAULTS.orientation,
        voiceLang: (["en", "off"] as const).includes(p.voiceLang as VoiceLang)
          ? (p.voiceLang as VoiceLang)
          : DEFAULTS.voiceLang,
      };
      return cache;
    }
  } catch {
    /* corrupted storage — fall back */
  }
  cache = { ...DEFAULTS };
  return cache;
}

export function saveSettings(s: Partial<GameSettings>): GameSettings {
  const next = { ...getSettings(), ...s };
  cache = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable */
  }
  return next;
}

export function pixelRatioFor(q: Quality): number {
  const dpr = window.devicePixelRatio || 1;
  switch (q) {
    case "low":
      return 1;
    case "medium":
      return Math.min(dpr, 1.5);
    case "high":
      return Math.min(dpr, 2);
    case "ultra":
      return Math.min(dpr, 3);
  }
}

// ---- forced-landscape (CSS rotation) -----------------------------------------
// Browsers refuse orientation.lock without fullscreen+gesture (iOS: never).
// So when the pref is landscape and the device is physically portrait we
// rotate the whole app 90° with CSS. These helpers keep input/render in sync.

export function isForcedLandscape(): boolean {
  return getSettings().orientation === "landscape" && window.innerHeight > window.innerWidth;
}

/** logical viewport size for the renderer (swapped when CSS-rotated) */
export function viewSize(): { w: number; h: number } {
  if (isForcedLandscape()) return { w: window.innerHeight, h: window.innerWidth };
  return { w: window.innerWidth, h: window.innerHeight };
}

/** map a physical pointer delta into the rotated app's local space */
export function mapDelta(dx: number, dy: number): [number, number] {
  return isForcedLandscape() ? [dy, -dx] : [dx, dy];
}

// ---- orientation control ----------------------------------------------------
// Browsers only allow locking orientation in fullscreen; degrade gracefully.

interface OrientationLockable {
  lock?: (o: "landscape" | "portrait") => Promise<void>;
  unlock?: () => void;
}

// Capacitor's ScreenOrientation plugin (if the app runs inside the APK and
// the plugin is installed) — locks the WebView without needing fullscreen.
interface CapOrientationPlugin {
  lock?: (opts: { orientation: string }) => Promise<void>;
  unlock?: () => Promise<void>;
}
function capOrientation(): CapOrientationPlugin | null {
  const w = window as unknown as {
    Capacitor?: { Plugins?: { ScreenOrientation?: CapOrientationPlugin } };
  };
  return w.Capacitor?.Plugins?.ScreenOrientation ?? null;
}

export async function applyOrientation(pref: OrientationPref): Promise<void> {
  const so = screen.orientation as unknown as OrientationLockable | undefined;
  try {
    // 0) native path first: Capacitor plugin inside the APK
    const cap = capOrientation();
    if (cap) {
      if (pref === "auto") await cap.unlock?.();
      else await cap.lock?.({ orientation: pref });
      return;
    }
    if (pref === "auto") {
      so?.unlock?.();
      if (document.fullscreenElement) await document.exitFullscreen();
      return;
    }
    // 1) try the hardware lock directly (installed PWAs allow this)
    try {
      await so?.lock?.(pref);
      return;
    } catch {
      /* needs fullscreen first */
    }
    // 2) fullscreen + lock — the standard "native game" path on Android
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen?.();
    }
    await so?.lock?.(pref);
  } catch {
    // unsupported (iOS Safari etc.) — the CSS rotation fallback covers it
  }
}

/** true when the device is REALLY hardware-locked to the pref (no CSS needed) */
export function isHardwareLandscape(): boolean {
  return window.innerWidth > window.innerHeight;
}

// ---- one-time tutorial flags -------------------------------------------------

const TUT_KEY = "amongus-fa-tutorials";

export function tutorialSeen(id: string): boolean {
  try {
    const raw = localStorage.getItem(TUT_KEY);
    return raw ? (JSON.parse(raw) as string[]).includes(id) : false;
  } catch {
    return false;
  }
}

export function markTutorialSeen(id: string): void {
  try {
    const raw = localStorage.getItem(TUT_KEY);
    const arr = raw ? (JSON.parse(raw) as string[]) : [];
    if (!arr.includes(id)) arr.push(id);
    localStorage.setItem(TUT_KEY, JSON.stringify(arr));
  } catch {
    /* ignore */
  }
}
