export type Screen =
  | "menu"
  | "reveal"
  | "game"
  | "meeting"
  | "eject"
  | "gameover";

export interface PlayerInfo {
  id: number;
  name: string;
  color: string; // hex
  colorName: string;
  alive: boolean;
  isImpostor: boolean;
  isBot: boolean;
  hat: string; // hat id ("none" = بدون کلاه)
}

export type TalkKind = "hi" | "who" | "follow" | "leave";

export type ProposalKind =
  | "buddy"
  | "warn"
  | "task"
  | "lure"
  | "threat"
  | "deal"
  | "quarrel"
  | "mission"
  | "murder";

export interface MissionInfo {
  botId: number;
  botName: string;
  targetId: number;
  targetName: string;
  reward: number;
}

export interface CamSighting {
  id: number;
  name: string;
  color: string;
  room: string;
  secsAgo: number;
}

export interface ProposalData {
  botId: number;
  botName: string;
  botColor: string;
  botHat: string;
  kind: ProposalKind;
  text: string;
  acceptLabel: string;
  declineLabel: string;
  reward?: number; // coins offered (deal) or demanded back (quarrel)
  targetId?: number; // whom to vote for (deal)
}

export interface DealInfo {
  botId: number;
  botName: string;
  targetId: number;
  targetName: string;
  reward: number;
}

export interface TaskInfo {
  id: string;
  label: string;
  room: string; // room of current step
  stepLabel: string;
  done: boolean;
  step: number; // completed steps
  total: number;
  currentStationId: string | null;
}

export type UseKind = "task" | "fix" | "emergency" | null;

export type SabKind = "lights" | "reactor";

export interface SabotageState {
  kind: SabKind;
  timeLeft: number; // seconds; -1 for lights (no timer)
}

export interface HudState {
  canUse: boolean;
  useLabel: string;
  useKind: UseKind;
  canReport: boolean;
  canKill: boolean;
  killCooldown: number;
  nearEmergency: boolean;
  taskProgress: number; // 0..1 global
  tasks: TaskInfo[];
  isImpostor: boolean;
  isGhost: boolean;
  playerPos: { x: number; z: number };
  roomName: string;
  coins: number;
  sabotage: SabotageState | null;
  sabotageCd: number;
  danger: number; // 0..1 — impostor proximity fear
  canTalk: boolean;
  talkName: string;
  jailTime: number; // seconds left in prison (0 = free)
  onCamera: boolean; // impostor is in CCTV view (and cams active)
  camerasDown: number; // seconds until CCTV back online
  cameraCd: number; // impostor camera-sabotage cooldown
  clue: string; // clue text near a body
  canWatchCams: boolean; // near the security monitors
  watchingCam: number; // -1 = not watching, else camera index
  camCount: number;
  mission: MissionInfo | null; // forced elimination contract
  murderPlan: MissionInfo | null; // accomplice murder plan with an impostor
  canSit: boolean; // near the emergency table — can sit down for a chat
  sitting: boolean; // currently seated at the table
}

export interface Intel {
  suspectId: number | null;
  witnessId: number | null;
  camera: boolean; // evidence comes from CCTV
}

export interface ActiveStation {
  stationId: string;
  kind: string; // minigame kind
  label: string;
  isFix: boolean;
}

export interface MeetingData {
  reason: "body" | "emergency";
  reporterId: number;
  victimId: number | null;
  accusedId: number | null;
}

export interface MeetingResult {
  ejectedId: number | null;
  jailedId: number | null; // plurality without absolute majority => prison
  votes: Record<number, number | -1>;
  disrupted?: boolean;
}

export type GameOverKind =
  | "crew-tasks"
  | "crew-eject"
  | "impostor-kill"
  | "impostor-sabotage"
  | "impostor-vote";

export interface GameOverData {
  kind: GameOverKind;
  playerWon: boolean;
  impostorIds: number[];
}

export type EngineEvent =
  | { type: "meeting"; data: MeetingData }
  | { type: "playerKilled"; byId: number }
  | { type: "gameover"; data: GameOverData }
  | { type: "killFlash" }
  | { type: "sabotage"; kind: SabKind }
  | { type: "sabotageFixed" }
  | { type: "proposal"; data: ProposalData }
  | { type: "proposalOver" }
  | { type: "camsDown" }
  | { type: "stealthKill" }
  | { type: "avenger"; botName: string };
