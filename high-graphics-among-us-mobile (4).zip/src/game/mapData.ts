// ---- Multi-map ship layouts ------------------------------------------------
// All rects are axis-aligned: [cx, cz, width, depth]

export interface Rect {
  id: string;
  cx: number;
  cz: number;
  w: number;
  d: number;
  room: boolean;
  name?: string;
}

const R = (
  id: string,
  cx: number,
  cz: number,
  w: number,
  d: number,
  room = false,
  name?: string,
): Rect => ({ id, cx, cz, w, d, room, name });

export interface NavNode {
  id: string;
  x: number;
  z: number;
}
const N = (id: string, x: number, z: number): NavNode => ({ id, x, z });

export interface Station {
  id: string;
  label: string;
  room: string;
  x: number;
  z: number;
  ry: number;
}

export interface FixDef {
  x: number;
  z: number;
  node: string;
  label: string;
  game: string;
}

export interface CamDef {
  x: number;
  z: number;
}

export interface GateDef {
  x: number;
  z: number;
  horizontal: boolean; // bars run along X (gate on a north/south wall)
  span: number;
}

export interface MapDef {
  id: string;
  name: string;
  desc: string;
  rects: Rect[];
  nodes: NavNode[];
  stations: Station[];
  prison: { x0: number; x1: number; z0: number; z1: number };
  prisonCenter: { x: number; z: number };
  prisonGate: GateDef;
  morgue: { x: number; z: number };
  emergency: { x: number; z: number };
  fixPoints: { lights: FixDef; reactor: FixDef };
  cameras: CamDef[];
}

// ============================ MAP 1: SKELD ==================================

const SKELD_RECTS: Rect[] = [
  R("caf", 0, 0, 18, 14, true, "کافه‌تریا"),
  R("weapons", 16, -12, 9, 8, true, "اسلحه‌خانه"),
  R("nav", 26, 0, 8, 9, true, "ناوبری"),
  R("shields", 16, 12, 9, 8, true, "سپرها"),
  R("storage", 0, 16, 12, 10, true, "انبار"),
  R("elec", -13, 12, 9, 8, true, "برق"),
  R("lowerEng", -24, 12, 9, 9, true, "موتور پایین"),
  R("reactor", -28, 0, 8, 10, true, "رآکتور"),
  R("upperEng", -24, -12, 9, 9, true, "موتور بالا"),
  R("medbay", -13, -10, 8, 8, true, "درمانگاه"),
  R("h-caf-weap", 13.75, -4, 11.5, 3),
  R("v-weap", 16, -5.75, 3, 6.5),
  R("v-east", 19, 0, 3, 18),
  R("h-nav", 20.25, 0, 5.5, 3),
  R("v-caf-storage", 0, 9, 3, 6),
  R("h-storage-shields", 8.75, 12, 7.5, 3),
  R("h-storage-elec", -7.25, 12, 4.5, 3),
  R("h-elec-lower", -18.5, 12, 4, 3),
  R("v-lower-reactor", -26, 6, 3, 5),
  R("v-reactor-upper", -26, -6, 3, 5),
  R("h-upper-medbay", -18.25, -12, 4.5, 3),
  R("h-medbay-caf", -7, -10, 6, 3),
  R("v-medbay-caf", -5.5, -8.75, 3, 5.5),
  R("admin", 12, 19, 8, 6, true, "اداری"),
  R("comms", 26, 12, 7, 6, true, "ارتباطات"),
  R("o2", 25, -12, 6, 6, true, "اکسیژن"),
  R("security", -13, 1, 7, 7, true, "امنیت"),
  R("prison", -21, 1, 6, 7, true, "بازداشتگاه"),
  R("h-storage-admin", 7, 18, 4, 3),
  R("h-shields-comms", 21.5, 12, 4, 3),
  R("h-weap-o2", 21.25, -12, 3.5, 3),
  R("v-o2-nav", 26, -6.75, 3, 6.5),
  R("v-med-sec", -13, -4.25, 3, 5.5),
  R("v-sec-elec", -13, 6.25, 3, 5.5),
  R("h-prison-sec", -17.5, 1, 4, 3),
  R("morgue", -13, -17.5, 6, 5, true, "سردخانه"),
  R("v-med-morgue", -13, -15, 3, 4),
];

const SKELD_NODES: NavNode[] = [
  N("caf", 0, 0),
  N("weapons", 16, -12),
  N("nav", 26, 0),
  N("shields", 16, 12),
  N("storage", 0, 16),
  N("elec", -13, 12),
  N("lowerEng", -24, 12),
  N("reactor", -28, 0),
  N("upperEng", -24, -12),
  N("medbay", -13, -10),
  N("cafE", 6, -4),
  N("w1", 12.75, -4),
  N("w2", 16, -4),
  N("v1", 19, -6),
  N("v2", 19, 0),
  N("v3", 19, 6),
  N("s1", 0, 9),
  N("stE", 4, 12),
  N("stW", -4, 12),
  N("sh1", 8.75, 12),
  N("e1", -7.25, 12),
  N("l1", -18.5, 12),
  N("r1", -26, 6),
  N("r2", -26, -6),
  N("m1", -18, -12),
  N("c2", -5.5, -10),
  N("cafNW", -5.5, -5),
  N("adm1", 7, 18),
  N("admin", 12, 19),
  N("comms", 26, 12),
  N("o2", 25, -12),
  N("security", -13, 1),
  N("prison", -21, 1),
  N("morgue", -13, -17.5),
];

const SKELD_STATIONS: Station[] = [
  { id: "wires", label: "اتصال سیم‌ها", room: "برق", x: -16.6, z: 10, ry: Math.PI / 2 },
  { id: "scan", label: "اسکن پزشکی", room: "درمانگاه", x: -13, z: -13, ry: 0 },
  { id: "chart", label: "تنظیم مسیر", room: "ناوبری", x: 29.1, z: 0, ry: -Math.PI / 2 },
  { id: "asteroids", label: "نابودی شهاب‌سنگ‌ها", room: "اسلحه‌خانه", x: 16, z: -15.1, ry: 0 },
  { id: "prime", label: "کالیبره‌کردن سپرها", room: "سپرها", x: 16, z: 15.1, ry: Math.PI },
  { id: "fuel", label: "تخلیه سوخت", room: "انبار", x: 5.1, z: 18, ry: -Math.PI / 2 },
  { id: "reactor", label: "شارژ رآکتور", room: "رآکتور", x: -31.1, z: 0, ry: Math.PI / 2 },
  { id: "upload", label: "بارگذاری داده‌ها", room: "کافه‌تریا", x: -8.1, z: 5, ry: Math.PI / 2 },
  { id: "alignU", label: "تنظیم موتور بالا", room: "موتور بالا", x: -24, z: -15.6, ry: 0 },
  { id: "alignL", label: "تنظیم موتور پایین", room: "موتور پایین", x: -24, z: 15.6, ry: Math.PI },
  { id: "swipe", label: "کشیدن کارت شناسایی", room: "اداری", x: 14.9, z: 19, ry: -Math.PI / 2 },
  { id: "antenna", label: "تنظیم آنتن مخابراتی", room: "ارتباطات", x: 26, z: 14.4, ry: Math.PI },
  { id: "o2filter", label: "تصفیه اکسیژن", room: "اکسیژن", x: 25, z: -14.5, ry: 0 },
];

// ============================ MAP 2: MIRA ===================================

const MIRA_RECTS: Rect[] = [
  R("caf", 0, 0, 16, 12, true, "کافه‌تریا"),
  R("green", 0, -14, 10, 8, true, "گلخانه"),
  R("comms", 14, -14, 8, 6, true, "ارتباطات"),
  R("medbay", -14, -12, 8, 7, true, "درمانگاه"),
  R("office", 14, 12, 8, 7, true, "اداری"),
  R("storage", 0, 14, 10, 8, true, "انبار"),
  R("elec", -14, 12, 8, 7, true, "برق"),
  R("reactor", -27, 0, 8, 9, true, "رآکتور"),
  R("weapons", 14, 0, 8, 7, true, "اسلحه‌خانه"),
  R("nav", 26, 0, 7, 8, true, "ناوبری"),
  R("security", -16, 0, 6, 6, true, "امنیت"),
  R("prison", -24, 12, 6, 6, true, "بازداشتگاه"),
  R("v-caf-green", 0, -8, 3, 6),
  R("h-green-comms", 7.5, -14, 7, 3),
  R("h-med-green", -7.5, -13, 7, 3),
  R("h-caf-weap", 9, 0, 4, 3),
  R("h-weap-nav", 20.25, 0, 6.5, 3),
  R("v-weap-office", 14, 6, 3, 7),
  R("v-caf-storage", 0, 8, 3, 6),
  R("h-storage-elec", -7.5, 12, 7, 3),
  R("h-storage-office", 7.5, 12, 7, 3),
  R("h-caf-sec", -10.5, 0, 7, 3),
  R("h-sec-reactor", -21, 0, 6, 3),
  R("v-med-sec", -14, -5.75, 3, 7.5),
  R("v-elec-sec", -14, 5.75, 3, 7.5),
  R("h-elec-prison", -19.5, 12, 5, 3),
  R("morgue", -24, -12, 6, 5, true, "سردخانه"),
  R("h-med-morgue", -19.5, -12, 5, 3),
];

const MIRA_NODES: NavNode[] = [
  N("caf", 0, 0),
  N("green", 0, -14),
  N("comms", 14, -14),
  N("medbay", -14, -12),
  N("office", 14, 12),
  N("storage", 0, 14),
  N("elec", -14, 12),
  N("reactor", -27, 0),
  N("weapons", 14, 0),
  N("nav", 26, 0),
  N("security", -16, 0),
  N("prison", -24, 12),
  N("j1", 0, -8),
  N("j2", 7.5, -14),
  N("j3", -7.5, -13),
  N("j4", 9, 0),
  N("j5", 20, 0),
  N("j6", 14, 6),
  N("j7", 0, 8),
  N("j8", -7.5, 12),
  N("j9", 7.5, 12),
  N("j10", -10.5, 0),
  N("j11", -21, 0),
  N("j12", -14, -5.5),
  N("j13", -14, 5.5),
  N("j14", -19.5, 12),
  N("morgue", -24, -12),
];

const MIRA_STATIONS: Station[] = [
  { id: "wires", label: "اتصال سیم‌ها", room: "برق", x: -17, z: 14, ry: Math.PI / 2 },
  { id: "scan", label: "اسکن پزشکی", room: "درمانگاه", x: -14, z: -14.6, ry: 0 },
  { id: "chart", label: "تنظیم مسیر", room: "ناوبری", x: 28.6, z: 0, ry: -Math.PI / 2 },
  { id: "asteroids", label: "نابودی شهاب‌سنگ‌ها", room: "اسلحه‌خانه", x: 17.1, z: -2.5, ry: -Math.PI / 2 },
  { id: "prime", label: "کالیبره‌کردن سپرها", room: "گلخانه", x: 3.5, z: -17.1, ry: 0 },
  { id: "fuel", label: "تخلیه سوخت", room: "انبار", x: 4.1, z: 16.5, ry: -Math.PI / 2 },
  { id: "reactor", label: "شارژ رآکتور", room: "رآکتور", x: -30.1, z: 0, ry: Math.PI / 2 },
  { id: "upload", label: "بارگذاری داده‌ها", room: "کافه‌تریا", x: -7.1, z: 4, ry: Math.PI / 2 },
  { id: "alignU", label: "تنظیم موتور بالا", room: "رآکتور", x: -27, z: -3.6, ry: 0 },
  { id: "alignL", label: "تنظیم موتور پایین", room: "اداری", x: 17, z: 14.6, ry: Math.PI },
  { id: "swipe", label: "کشیدن کارت شناسایی", room: "اداری", x: 11, z: 14.6, ry: Math.PI },
  { id: "antenna", label: "تنظیم آنتن مخابراتی", room: "ارتباطات", x: 17, z: -16, ry: Math.PI },
  { id: "o2filter", label: "تصفیه اکسیژن", room: "گلخانه", x: -3.5, z: -17.1, ry: 0 },
];

// ============================ MAP 3: POLUS ==================================

const POLUS_RECTS: Rect[] = [
  R("weapons", -16, -12, 8, 7, true, "اسلحه‌خانه"),
  R("caf", 0, -12, 14, 8, true, "کافه‌تریا"),
  R("nav", 16, -12, 8, 7, true, "ناوبری"),
  R("elec", -20, 8, 8, 7, true, "برق"),
  R("medbay", -8, 8, 8, 7, true, "درمانگاه"),
  R("storage", 4, 8, 8, 7, true, "انبار"),
  R("comms", 16, 8, 8, 7, true, "ارتباطات"),
  R("reactor", -32, 8, 8, 8, true, "رآکتور"),
  R("office", 28, 8, 7, 7, true, "اداری"),
  R("prison", 16, 20, 6, 6, true, "بازداشتگاه"),
  R("h-weap-caf", -9.5, -12, 7, 3),
  R("h-caf-nav", 9.5, -12, 7, 3),
  R("v-caf-storage", 4, -1.75, 3, 14.5),
  R("v-weap-elec", -18, -2, 3, 15),
  R("v-nav-comms", 16, -2, 3, 15),
  R("h-elec-med", -14, 8, 6, 3),
  R("h-med-storage", -2, 8, 6, 3),
  R("h-storage-comms", 10, 8, 6, 3),
  R("h-reactor-elec", -26, 8, 6, 3),
  R("h-comms-office", 22.25, 8, 6.5, 3),
  R("v-comms-prison", 16, 14.5, 3, 7),
  R("morgue", -27, -12, 6, 5, true, "سردخانه"),
  R("h-weap-morgue", -22, -12, 6, 3),
];

const POLUS_NODES: NavNode[] = [
  N("weapons", -16, -12),
  N("caf", 0, -12),
  N("nav", 16, -12),
  N("elec", -20, 8),
  N("medbay", -8, 8),
  N("storage", 4, 8),
  N("comms", 16, 8),
  N("reactor", -32, 8),
  N("office", 28, 8),
  N("prison", 16, 20),
  N("k1", -9.5, -12),
  N("k2", 9.5, -12),
  N("k3", 4, -10),
  N("k4", 4, -3),
  N("k5", 4, 4),
  N("k6", -18, -10),
  N("k7", -18, -2),
  N("k8", -18, 5),
  N("k9", 16, -10),
  N("k10", 16, -2),
  N("k11", 16, 5),
  N("k12", -14, 8),
  N("k13", -2, 8),
  N("k14", 10, 8),
  N("k15", -26, 8),
  N("k16", 22, 8),
  N("k17", 16, 14.5),
  N("morgue", -27, -12),
];

const POLUS_STATIONS: Station[] = [
  { id: "wires", label: "اتصال سیم‌ها", room: "برق", x: -23, z: 10.5, ry: Math.PI / 2 },
  { id: "scan", label: "اسکن پزشکی", room: "درمانگاه", x: -8, z: 10.9, ry: Math.PI },
  { id: "chart", label: "تنظیم مسیر", room: "ناوبری", x: 19.4, z: -14, ry: -Math.PI / 2 },
  { id: "asteroids", label: "نابودی شهاب‌سنگ‌ها", room: "اسلحه‌خانه", x: -19.4, z: -14, ry: Math.PI / 2 },
  { id: "prime", label: "کالیبره‌کردن سپرها", room: "کافه‌تریا", x: 3, z: -15.4, ry: 0 },
  { id: "fuel", label: "تخلیه سوخت", room: "انبار", x: 7.4, z: 10.5, ry: -Math.PI / 2 },
  { id: "reactor", label: "شارژ رآکتور", room: "رآکتور", x: -35.4, z: 8, ry: Math.PI / 2 },
  { id: "upload", label: "بارگذاری داده‌ها", room: "کافه‌تریا", x: -3, z: -15.4, ry: 0 },
  { id: "alignU", label: "تنظیم موتور بالا", room: "رآکتور", x: -32, z: 4.7, ry: 0 },
  { id: "alignL", label: "تنظیم موتور پایین", room: "اداری", x: 30.9, z: 8, ry: -Math.PI / 2 },
  { id: "swipe", label: "کشیدن کارت شناسایی", room: "اداری", x: 28, z: 10.9, ry: Math.PI },
  { id: "antenna", label: "تنظیم آنتن مخابراتی", room: "ارتباطات", x: 19.4, z: 6, ry: -Math.PI / 2 },
  { id: "o2filter", label: "تصفیه اکسیژن", room: "درمانگاه", x: -11.4, z: 6, ry: Math.PI / 2 },
];

// ============================ MAP REGISTRY ==================================

export const MAPS: MapDef[] = [
  {
    id: "skeld",
    name: "اسکلد",
    desc: "سفینه کلاسیک — بزرگ و پیچیده",
    rects: SKELD_RECTS,
    nodes: SKELD_NODES,
    stations: SKELD_STATIONS,
    prison: { x0: -24, x1: -18, z0: -2.5, z1: 4.5 },
    prisonCenter: { x: -21, z: 1 },
    prisonGate: { x: -18, z: 1, horizontal: false, span: 3 },
    morgue: { x: -13, z: -17.5 },
    emergency: { x: 0, z: 0 },
    fixPoints: {
      lights: { x: -13, z: 12, node: "elec", label: "وصل کردن فیوزهای برق", game: "fix-lights" },
      reactor: { x: -28, z: 0, node: "reactor", label: "خنک‌سازی اضطراری رآکتور", game: "fix-reactor" },
    },
    cameras: [
      { x: 0, z: -6 },
      { x: 19, z: 4 },
      { x: -13, z: 10 },
      { x: -26, z: -4 },
    ],
  },
  {
    id: "mira",
    name: "میرا",
    desc: "مقر مرکزی — فشرده با گلخانه",
    rects: MIRA_RECTS,
    nodes: MIRA_NODES,
    stations: MIRA_STATIONS,
    prison: { x0: -27, x1: -21, z0: 9, z1: 15 },
    prisonCenter: { x: -24, z: 12 },
    prisonGate: { x: -21, z: 12, horizontal: false, span: 3 },
    morgue: { x: -24, z: -12 },
    emergency: { x: 0, z: 0 },
    fixPoints: {
      lights: { x: -14, z: 12, node: "elec", label: "وصل کردن فیوزهای برق", game: "fix-lights" },
      reactor: { x: -27, z: 0, node: "reactor", label: "خنک‌سازی اضطراری رآکتور", game: "fix-reactor" },
    },
    cameras: [
      { x: 0, z: -4.5 },
      { x: 14, z: 1.5 },
      { x: -14, z: 10 },
    ],
  },
  {
    id: "polus",
    name: "پولوس",
    desc: "پایگاه یخی — راهروهای طولانی",
    rects: POLUS_RECTS,
    nodes: POLUS_NODES,
    stations: POLUS_STATIONS,
    prison: { x0: 13, x1: 19, z0: 17, z1: 23 },
    prisonCenter: { x: 16, z: 20 },
    prisonGate: { x: 16, z: 17, horizontal: true, span: 3 },
    morgue: { x: -27, z: -12 },
    emergency: { x: 0, z: -12 },
    fixPoints: {
      lights: { x: -20, z: 8, node: "elec", label: "وصل کردن فیوزهای برق", game: "fix-lights" },
      reactor: { x: -32, z: 8, node: "reactor", label: "خنک‌سازی اضطراری رآکتور", game: "fix-reactor" },
    },
    cameras: [
      { x: 0, z: -10 },
      { x: -18, z: 2 },
      { x: 16, z: 6.5 },
    ],
  },
];

// ---- active-map live bindings ----------------------------------------------

export let RECTS: Rect[] = SKELD_RECTS;
export let ROOMS: Rect[] = SKELD_RECTS.filter((r) => r.room);
export let NODES: NavNode[] = SKELD_NODES;
export let STATIONS: Station[] = SKELD_STATIONS;
export let PRISON = MAPS[0].prison;
export let PRISON_CENTER = MAPS[0].prisonCenter;
export let PRISON_GATE = MAPS[0].prisonGate;
export let MORGUE = MAPS[0].morgue;
export let EMERGENCY_POS = MAPS[0].emergency;
export let FIX_POINTS = MAPS[0].fixPoints;
export let CAMERAS: CamDef[] = MAPS[0].cameras;
export let EDGES: Map<string, string[]> = new Map();
let nodeById = new Map<string, NavNode>();

export function setActiveMap(idx: number): void {
  const m = MAPS[Math.max(0, Math.min(MAPS.length - 1, idx))];
  RECTS = m.rects;
  ROOMS = m.rects.filter((r) => r.room);
  NODES = m.nodes;
  STATIONS = m.stations;
  PRISON = m.prison;
  PRISON_CENTER = m.prisonCenter;
  PRISON_GATE = m.prisonGate;
  MORGUE = m.morgue;
  EMERGENCY_POS = m.emergency;
  FIX_POINTS = m.fixPoints;
  CAMERAS = m.cameras;
  nodeById = new Map(NODES.map((n) => [n.id, n]));
  buildEdges();
}

// ---- geometry helpers ----------------------------------------------------

export function rectContains(r: Rect, x: number, z: number, margin = 0): boolean {
  return (
    x >= r.cx - r.w / 2 + margin &&
    x <= r.cx + r.w / 2 - margin &&
    z >= r.cz - r.d / 2 + margin &&
    z <= r.cz + r.d / 2 - margin
  );
}

export function insideUnion(x: number, z: number): boolean {
  for (const r of RECTS) if (rectContains(r, x, z)) return true;
  return false;
}

export function canStand(x: number, z: number, rad: number): boolean {
  if (!insideUnion(x, z)) return false;
  const k = rad;
  return (
    insideUnion(x + k, z) &&
    insideUnion(x - k, z) &&
    insideUnion(x, z + k) &&
    insideUnion(x, z - k) &&
    insideUnion(x + k * 0.71, z + k * 0.71) &&
    insideUnion(x - k * 0.71, z + k * 0.71) &&
    insideUnion(x + k * 0.71, z - k * 0.71) &&
    insideUnion(x - k * 0.71, z - k * 0.71)
  );
}

function segmentWalkable(ax: number, az: number, bx: number, bz: number, margin = 0.4): boolean {
  const len = Math.hypot(bx - ax, bz - az);
  const steps = Math.max(2, Math.ceil(len / 0.4));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = ax + (bx - ax) * t;
    const z = az + (bz - az) * t;
    let ok = false;
    for (const r of RECTS) {
      if (rectContains(r, x, z, margin)) {
        ok = true;
        break;
      }
    }
    if (!ok) return false;
  }
  return true;
}

/** direct line-of-walk check used by follower AI */
export function directWalkable(ax: number, az: number, bx: number, bz: number): boolean {
  return segmentWalkable(ax, az, bx, bz, 0.5);
}

function buildEdges(): void {
  const adj = new Map<string, string[]>();
  for (const n of NODES) adj.set(n.id, []);
  for (let i = 0; i < NODES.length; i++) {
    for (let j = i + 1; j < NODES.length; j++) {
      const a = NODES[i];
      const b = NODES[j];
      const d = Math.hypot(a.x - b.x, a.z - b.z);
      if (d > 14) continue;
      if (segmentWalkable(a.x, a.z, b.x, b.z)) {
        adj.get(a.id)!.push(b.id);
        adj.get(b.id)!.push(a.id);
      }
    }
  }
  EDGES = adj;
}

export function nearestNode(x: number, z: number): NavNode {
  let best = NODES[0];
  let bd = Infinity;
  for (const n of NODES) {
    const d = Math.hypot(n.x - x, n.z - z);
    if (d < bd && segmentWalkable(x, z, n.x, n.z)) {
      bd = d;
      best = n;
    }
  }
  if (bd === Infinity) {
    for (const n of NODES) {
      const d = Math.hypot(n.x - x, n.z - z);
      if (d < bd) {
        bd = d;
        best = n;
      }
    }
  }
  return best;
}

export function findPath(fromId: string, toId: string): NavNode[] {
  if (fromId === toId) return [nodeById.get(toId)!];
  const prev = new Map<string, string>();
  const q = [fromId];
  const seen = new Set([fromId]);
  while (q.length) {
    const cur = q.shift()!;
    if (cur === toId) break;
    for (const nb of EDGES.get(cur) ?? []) {
      if (!seen.has(nb)) {
        seen.add(nb);
        prev.set(nb, cur);
        q.push(nb);
      }
    }
  }
  if (!prev.has(toId)) return [nodeById.get(toId)!];
  const path: NavNode[] = [];
  let cur: string | undefined = toId;
  while (cur && cur !== fromId) {
    path.unshift(nodeById.get(cur)!);
    cur = prev.get(cur);
  }
  return path;
}

export function roomNameAt(x: number, z: number): string {
  for (const r of ROOMS) if (rectContains(r, x, z)) return r.name!;
  return "راهرو";
}

// ---- multi-stage task chains & minigame kinds -----------------------------

export interface TaskChainDef {
  id: string;
  label: string;
  steps: { st: string; label: string }[];
}

export const TASK_CHAINS: TaskChainDef[] = [
  {
    id: "fuelchain",
    label: "سوخت‌رسانی موتور (۲ مرحله)",
    steps: [
      { st: "fuel", label: "برداشتن گالن سوخت از انبار" },
      { st: "alignU", label: "تزریق سوخت به موتور" },
    ],
  },
  {
    id: "datachain",
    label: "انتقال داده‌ها (۲ مرحله)",
    steps: [
      { st: "chart", label: "دانلود داده‌ها در ناوبری" },
      { st: "upload", label: "آپلود داده‌ها در کافه‌تریا" },
    ],
  },
];

export const SINGLE_TASK_POOL = [
  "wires",
  "scan",
  "asteroids",
  "prime",
  "reactor",
  "alignL",
  "swipe",
  "antenna",
  "o2filter",
];

export const GAME_KINDS: Record<string, string> = {
  wires: "wires",
  scan: "download",
  chart: "path",
  asteroids: "targets",
  prime: "targets",
  fuel: "hold",
  reactor: "simon",
  upload: "download",
  alignU: "hold",
  alignL: "align",
  swipe: "download",
  antenna: "align",
  o2filter: "hold",
};

// ---- players ---------------------------------------------------------------

export const COLORS = [
  { hex: "#C51111", name: "قرمز" },
  { hex: "#132ED1", name: "آبی" },
  { hex: "#117F2D", name: "سبز" },
  { hex: "#ED54BA", name: "صورتی" },
  { hex: "#EF7D0D", name: "نارنجی" },
  { hex: "#F5F557", name: "زرد" },
  { hex: "#3F474E", name: "مشکی" },
  { hex: "#D6E0F0", name: "سفید" },
  { hex: "#6B2FBB", name: "بنفش" },
  { hex: "#38FEDC", name: "فیروزه‌ای" },
];

export const SPAWN_RING = 2.6;

// initialize default map
setActiveMap(0);
