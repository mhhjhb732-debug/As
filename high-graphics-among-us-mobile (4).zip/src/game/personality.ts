// =============================================================================
// Bot personality, relationships and memory.
//
// CORE RULE (no god-mode): a bot may only remember what it SAW itself,
// what it HEARD from someone, or what it SUSPECTS. Every memory entry
// carries a source and a reliability. Decisions are explainable:
// evidenceScore() sums weighted memories modified by personality traits.
// =============================================================================

import { EV } from "./constants";

export interface Traits {
  aggression: number; // پرخاشگری
  trust: number; // اعتماد
  bravery: number; // شجاعت
  suspicion: number; // بدگمانی
  loyalty: number; // وفاداری
  greed: number; // طمع
  cooperation: number; // همکاری
  fear: number; // ترس
  deception: number; // فریبکاری
  curiosity: number; // کنجکاوی
}

export interface ArchetypeDef {
  id: string;
  label: string; // Persian label shown in meetings/log
  base: Traits;
}

const T = (
  aggression: number,
  trust: number,
  bravery: number,
  suspicion: number,
  loyalty: number,
  greed: number,
  cooperation: number,
  fear: number,
  deception: number,
  curiosity: number,
): Traits => ({
  aggression,
  trust,
  bravery,
  suspicion,
  loyalty,
  greed,
  cooperation,
  fear,
  deception,
  curiosity,
});

export const ARCHETYPES: ArchetypeDef[] = [
  { id: "detective", label: "کارآگاه", base: T(0.4, 0.4, 0.7, 0.75, 0.5, 0.2, 0.6, 0.25, 0.15, 0.9) },
  { id: "aggressive", label: "پرخاشگر", base: T(0.9, 0.25, 0.85, 0.6, 0.3, 0.5, 0.3, 0.15, 0.4, 0.5) },
  { id: "coward", label: "ترسو", base: T(0.15, 0.5, 0.15, 0.55, 0.4, 0.35, 0.5, 0.9, 0.25, 0.35) },
  { id: "leader", label: "رهبر", base: T(0.6, 0.55, 0.8, 0.5, 0.65, 0.3, 0.85, 0.2, 0.3, 0.6) },
  { id: "loyal", label: "وفادار", base: T(0.3, 0.8, 0.6, 0.3, 0.95, 0.15, 0.85, 0.35, 0.1, 0.4) },
  { id: "paranoid", label: "بدگمان", base: T(0.5, 0.15, 0.5, 0.95, 0.25, 0.4, 0.3, 0.6, 0.3, 0.7) },
  { id: "deceiver", label: "فریبکار", base: T(0.55, 0.3, 0.6, 0.5, 0.2, 0.75, 0.4, 0.3, 0.95, 0.6) },
  { id: "opportunist", label: "فرصت‌طلب", base: T(0.5, 0.35, 0.55, 0.45, 0.2, 0.9, 0.45, 0.4, 0.6, 0.55) },
  { id: "quiet", label: "کم‌حرف", base: T(0.25, 0.45, 0.45, 0.5, 0.5, 0.3, 0.4, 0.5, 0.2, 0.3) },
];

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const clamp100 = (v: number) => Math.min(100, Math.max(0, v));

/** jitter each trait ±0.12 so two bots of the same archetype still differ */
export function rollTraits(a: ArchetypeDef): Traits {
  const out = { ...a.base };
  for (const k of Object.keys(out) as (keyof Traits)[]) {
    out[k] = clamp01(out[k] + (Math.random() - 0.5) * 0.24);
  }
  return out;
}

// ---- memory ------------------------------------------------------------------

export type KnowledgeSource = "self" | "cctv" | "bot" | "player" | "body" | "meeting";

export type MemoryKind =
  | "sawKill" // direct: watched the murder happen
  | "nearBody" // direct: saw target close to a corpse
  | "heardSuspicion" // second-hand: someone claimed target is suspicious
  | "provenLie" // target's claim turned out false
  | "defendedMe"
  | "votedAgainstMe"
  | "dealtWithMe"
  | "threatenedMe"
  | "betrayedMe";

export interface MemoryEvent {
  kind: MemoryKind;
  aboutId: number;
  source: KnowledgeSource;
  reliability: number; // 0..1 — heard info can simply be wrong
  t: number;
}

export interface Relationship {
  trust: number; // 0..100
  suspicion: number;
  fear: number;
  loyalty: number;
  grudge: number;
}

const MEMORY_CAP = 60;

const KIND_WEIGHT: Record<MemoryKind, number> = {
  sawKill: EV.SAW_KILL,
  nearBody: EV.NEAR_BODY,
  heardSuspicion: EV.HEARD_SUSPICION,
  provenLie: EV.PROVEN_LIE,
  defendedMe: EV.GOOD_DEFENSE,
  votedAgainstMe: EV.VOTED_AGAINST_ME,
  dealtWithMe: EV.DEALT_WITH_ME,
  threatenedMe: EV.THREATENED_ME,
  betrayedMe: EV.BETRAYED_ME,
};

export class BotMind {
  readonly archetype: ArchetypeDef;
  readonly traits: Traits;
  private rel = new Map<number, Relationship>();
  private memory: MemoryEvent[] = [];

  constructor(archetype?: ArchetypeDef) {
    this.archetype =
      archetype ?? ARCHETYPES[Math.floor(Math.random() * ARCHETYPES.length)];
    this.traits = rollTraits(this.archetype);
  }

  relFor(id: number): Relationship {
    let r = this.rel.get(id);
    if (!r) {
      // base trust depends on the bot's trusting nature
      r = {
        trust: 30 + this.traits.trust * 40,
        suspicion: 10 + this.traits.suspicion * 20,
        fear: this.traits.fear * 15,
        loyalty: this.traits.loyalty * 30,
        grudge: 0,
      };
      this.rel.set(id, r);
    }
    return r;
  }

  adjustRel(id: number, d: Partial<Relationship>): void {
    const r = this.relFor(id);
    if (d.trust !== undefined) r.trust = clamp100(r.trust + d.trust);
    if (d.suspicion !== undefined) r.suspicion = clamp100(r.suspicion + d.suspicion);
    if (d.fear !== undefined) r.fear = clamp100(r.fear + d.fear);
    if (d.loyalty !== undefined) r.loyalty = clamp100(r.loyalty + d.loyalty);
    if (d.grudge !== undefined) r.grudge = clamp100(r.grudge + d.grudge);
  }

  remember(ev: MemoryEvent): void {
    this.memory.push(ev);
    if (this.memory.length > MEMORY_CAP) this.memory.shift();
    // memories also shift the relationship immediately
    const w = KIND_WEIGHT[ev.kind] * ev.reliability;
    if (w > 0) this.adjustRel(ev.aboutId, { suspicion: w * 0.5, trust: -w * 0.25 });
    else this.adjustRel(ev.aboutId, { trust: -w * 0.5, suspicion: w * 0.3 });
    if (ev.kind === "betrayedMe") this.adjustRel(ev.aboutId, { grudge: 45 });
    if (ev.kind === "threatenedMe") this.adjustRel(ev.aboutId, { fear: 35, grudge: 20 });
    if (ev.kind === "defendedMe") this.adjustRel(ev.aboutId, { loyalty: 20 });
  }

  /** strongest direct sighting this bot has about a killer, if any */
  directSighting(): { aboutId: number; kind: "sawKill" | "nearBody" } | null {
    for (let i = this.memory.length - 1; i >= 0; i--) {
      const m = this.memory[i];
      if (m.kind === "sawKill" && m.source === "self") return { aboutId: m.aboutId, kind: "sawKill" };
    }
    for (let i = this.memory.length - 1; i >= 0; i--) {
      const m = this.memory[i];
      if (m.kind === "nearBody" && m.source === "self") return { aboutId: m.aboutId, kind: "nearBody" };
    }
    return null;
  }

  /**
   * Explainable voting score for a target: weighted memories × personality.
   * A paranoid bot amplifies evidence; a trusting bot dampens it.
   * Memories FADE naturally: soft evidence (rumors, near-body sightings)
   * decays fast; watching a murder is nearly unforgettable.
   */
  evidenceScore(targetId: number, now = 0): number {
    let sum = 0;
    for (const m of this.memory) {
      if (m.aboutId !== targetId) continue;
      const age = Math.max(0, now - m.t);
      const halfLife =
        m.kind === "sawKill" || m.kind === "betrayedMe"
          ? 900 // ~15 min: traumatic, barely fades
          : m.kind === "heardSuspicion"
            ? 120 // rumors fade in ~2 min
            : 300;
      const decay = Math.pow(0.5, age / halfLife);
      sum += KIND_WEIGHT[m.kind] * m.reliability * decay;
    }
    const r = this.relFor(targetId);
    sum += r.grudge * 0.5 + r.suspicion * 0.3 - r.trust * 0.2;
    // personality multiplier on positive evidence only
    const mult = 0.65 + this.traits.suspicion * 0.7;
    return sum > 0 ? sum * mult : sum;
  }
}
