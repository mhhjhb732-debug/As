import * as THREE from "three";
import {
  CAMERAS,
  EMERGENCY_POS,
  MORGUE,
  PRISON_GATE,
  PRISON_CENTER,
  RECTS,
  ROOMS,
  STATIONS,
} from "./mapData";

const WALL_H = 3.2;

// ---------- wall boundary computation (interval subtraction) ---------------

interface Interval {
  a: number;
  b: number;
}

function subtract(base: Interval, cuts: Interval[]): Interval[] {
  let out: Interval[] = [base];
  for (const c of cuts) {
    const next: Interval[] = [];
    for (const s of out) {
      if (c.b <= s.a || c.a >= s.b) {
        next.push(s);
        continue;
      }
      if (c.a > s.a) next.push({ a: s.a, b: c.a });
      if (c.b < s.b) next.push({ a: c.b, b: s.b });
    }
    out = next;
  }
  return out.filter((s) => s.b - s.a > 0.05);
}

interface WallSeg {
  x: number;
  z: number;
  len: number;
  horizontal: boolean; // wall runs along X
}

export function computeWalls(): WallSeg[] {
  const segs: WallSeg[] = [];
  for (const r of RECTS) {
    const x0 = r.cx - r.w / 2,
      x1 = r.cx + r.w / 2,
      z0 = r.cz - r.d / 2,
      z1 = r.cz + r.d / 2;
    // four edges: (fixed coord, axis range, horizontal?)
    const edges: { c: number; range: Interval; horizontal: boolean }[] = [
      { c: z0, range: { a: x0, b: x1 }, horizontal: true },
      { c: z1, range: { a: x0, b: x1 }, horizontal: true },
      { c: x0, range: { a: z0, b: z1 }, horizontal: false },
      { c: x1, range: { a: z0, b: z1 }, horizontal: false },
    ];
    for (const e of edges) {
      const cuts: Interval[] = [];
      for (const o of RECTS) {
        if (o === r) continue;
        const ox0 = o.cx - o.w / 2,
          ox1 = o.cx + o.w / 2,
          oz0 = o.cz - o.d / 2,
          oz1 = o.cz + o.d / 2;
        if (e.horizontal) {
          if (oz0 < e.c && oz1 > e.c) cuts.push({ a: ox0, b: ox1 });
        } else {
          if (ox0 < e.c && ox1 > e.c) cuts.push({ a: oz0, b: oz1 });
        }
      }
      for (const s of subtract(e.range, cuts)) {
        if (e.horizontal)
          segs.push({ x: (s.a + s.b) / 2, z: e.c, len: s.b - s.a, horizontal: true });
        else segs.push({ x: e.c, z: (s.a + s.b) / 2, len: s.b - s.a, horizontal: false });
      }
    }
  }
  return segs;
}

// ---------- per-room color themes -------------------------------------------

interface RoomTheme {
  floor: number;
  trim: number;
  light: number;
}

const ROOM_THEMES: Record<string, RoomTheme> = {
  caf: { floor: 0x4a4436, trim: 0x5c5442, light: 0xffe9c4 },
  medbay: { floor: 0x35494f, trim: 0x40606a, light: 0xa8f4e6 },
  elec: { floor: 0x4d4429, trim: 0x615432, light: 0xfff29e },
  storage: { floor: 0x453b30, trim: 0x54473a, light: 0xe8cba0 },
  nav: { floor: 0x2f3d55, trim: 0x3a4c6b, light: 0x9ec2ff },
  weapons: { floor: 0x4c3232, trim: 0x5e3d3d, light: 0xffb3a3 },
  reactor: { floor: 0x2f4a38, trim: 0x3a5c45, light: 0x9dffc4 },
  comms: { floor: 0x433350, trim: 0x534064, light: 0xd6b3ff },
  o2: { floor: 0x30503a, trim: 0x3c6248, light: 0xb0ffcb },
  admin: { floor: 0x4f3a4a, trim: 0x61475b, light: 0xffc4ec },
  office: { floor: 0x4f3a4a, trim: 0x61475b, light: 0xffc4ec },
  security: { floor: 0x333f52, trim: 0x3f4e66, light: 0xa9c8ff },
  prison: { floor: 0x3d3236, trim: 0x4d3f44, light: 0xff9c8a },
  morgue: { floor: 0x2b3a44, trim: 0x354855, light: 0x9adfff },
  shields: { floor: 0x2f4a4a, trim: 0x3a5c5c, light: 0x9efcf4 },
  green: { floor: 0x3a5230, trim: 0x47653b, light: 0xc9ffa8 },
  upperEng: { floor: 0x4d3d2b, trim: 0x5f4c35, light: 0xffcf9e },
  lowerEng: { floor: 0x4d3d2b, trim: 0x5f4c35, light: 0xffcf9e },
};
const DEFAULT_THEME: RoomTheme = { floor: 0x39424f, trim: 0x3d4654, light: 0xcfe8ff };

export function themeOf(roomId: string): RoomTheme {
  return ROOM_THEMES[roomId] ?? DEFAULT_THEME;
}

// ---------- ship construction ----------------------------------------------

export function buildShip(scene: THREE.Scene, mapId = 0): void {
  void mapId;
  // floors
  const corridorFloorMat = new THREE.MeshStandardMaterial({
    color: 0x2c333e,
    roughness: 0.8,
    metalness: 0.3,
  });
  const floorGeo = new THREE.BoxGeometry(1, 0.2, 1);
  for (const r of RECTS) {
    const theme = themeOf(r.id);
    const mat = r.room
      ? new THREE.MeshStandardMaterial({ color: theme.floor, roughness: 0.75, metalness: 0.35 })
      : corridorFloorMat;
    const m = new THREE.Mesh(floorGeo, mat);
    m.scale.set(r.w, 1, r.d);
    m.position.set(r.cx, -0.1, r.cz);
    m.receiveShadow = true;
    scene.add(m);
    // per-room tinted floor trim
    if (r.room) {
      const trim = new THREE.Mesh(
        new THREE.BoxGeometry(r.w - 1.2, 0.02, r.d - 1.2),
        new THREE.MeshStandardMaterial({ color: theme.trim, roughness: 0.6, metalness: 0.45 }),
      );
      trim.position.set(r.cx, 0.011, r.cz);
      trim.receiveShadow = true;
      scene.add(trim);
    }
  }

  // walls
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x4a5568,
    roughness: 0.65,
    metalness: 0.4,
  });
  const stripMat = new THREE.MeshStandardMaterial({
    color: 0x9fd8ff,
    emissive: 0x77c9ff,
    emissiveIntensity: 1.4,
  });
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0x232a35,
    roughness: 0.85,
  });
  for (const s of computeWalls()) {
    const g = new THREE.Group();
    const wall = new THREE.Mesh(new THREE.BoxGeometry(s.len, WALL_H, 0.5), wallMat);
    wall.position.y = WALL_H / 2;
    wall.castShadow = false;
    g.add(wall);
    const strip = new THREE.Mesh(new THREE.BoxGeometry(s.len, 0.1, 0.54), stripMat);
    strip.position.y = 2.15;
    g.add(strip);
    const base = new THREE.Mesh(new THREE.BoxGeometry(s.len, 0.45, 0.62), baseMat);
    base.position.y = 0.22;
    g.add(base);
    g.position.set(s.x, 0, s.z);
    if (!s.horizontal) g.rotation.y = Math.PI / 2;
    scene.add(g);
  }

  // ceiling glow panels per room + tinted point lights
  for (const r of ROOMS) {
    const theme = themeOf(r.id);
    const panel = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(4, r.w * 0.4), 0.1, Math.min(4, r.d * 0.4)),
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: theme.light,
        emissiveIntensity: 1.6,
      }),
    );
    panel.position.set(r.cx, WALL_H + 0.05, r.cz);
    scene.add(panel);
    const light = new THREE.PointLight(theme.light, 26, Math.max(r.w, r.d) * 1.7, 1.8);
    light.position.set(r.cx, WALL_H - 0.4, r.cz);
    scene.add(light);
  }
  // a few corridor lights
  const corridorLightSpots = [
    [13.75, -4],
    [19, 0],
    [0, 9],
    [0, 12],
    [-13, 12],
    [-26, 0],
    [-7, -10],
  ];
  for (const [x, z] of corridorLightSpots) {
    const l = new THREE.PointLight(0x8fb8ff, 10, 12, 1.9);
    l.position.set(x, WALL_H - 0.6, z);
    scene.add(l);
  }

  buildEmergency(scene);
  buildPrisonProps(scene);
  buildMorgueProps(scene);
  buildCameras(scene);
  buildRoomProps(scene);
  buildStations(scene);
  buildStars(scene);
}

// ---------- per-room furniture (works on every map) --------------------------

function buildRoomProps(scene: THREE.Scene): void {
  const std = (color: number, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
    new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.4, ...extra });
  const glow = (color: number, intensity = 1.5) =>
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity });

  for (const r of ROOMS) {
    const cx = r.cx;
    const cz = r.cz;
    switch (r.id) {
      case "caf": {
        const tableMat = std(0x8b98ab, { roughness: 0.5, metalness: 0.5 });
        const seatMat = std(0x5a6a80, { roughness: 0.7 });
        for (const [dx, dz] of [
          [-r.w * 0.28, -r.d * 0.25],
          [r.w * 0.28, r.d * 0.25],
        ]) {
          const top = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.14, 20), tableMat);
          top.position.set(cx + dx, 0.9, cz + dz);
          scene.add(top);
          const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.28, 0.9, 8), seatMat);
          leg.position.set(cx + dx, 0.45, cz + dz);
          scene.add(leg);
          for (let i = 0; i < 4; i++) {
            const a = (i / 4) * Math.PI * 2 + 0.4;
            const st = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.5, 8), seatMat);
            st.position.set(cx + dx + Math.cos(a) * 1.9, 0.25, cz + dz + Math.sin(a) * 1.9);
            scene.add(st);
          }
        }
        break;
      }
      case "medbay": {
        // bed
        const bed = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.5, 2.4), std(0xd8e4ee, { roughness: 0.5 }));
        bed.position.set(cx - r.w * 0.25, 0.35, cz + r.d * 0.15);
        scene.add(bed);
        const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.16, 0.5), std(0x7ec8d8));
        pillow.position.set(cx - r.w * 0.25, 0.68, cz + r.d * 0.15 - 0.85);
        scene.add(pillow);
        // scanner ring
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.09, 8, 26), glow(0x6fe3ff, 1.6));
        ring.rotation.x = Math.PI / 2;
        ring.position.set(cx + r.w * 0.22, 0.12, cz - r.d * 0.15);
        scene.add(ring);
        break;
      }
      case "elec": {
        const box = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 0.4), std(0x6b6437, { roughness: 0.5 }));
        box.position.set(cx + r.w * 0.25, 0.9, cz - r.d * 0.3);
        scene.add(box);
        for (let i = 0; i < 5; i++) {
          const led = new THREE.Mesh(
            new THREE.BoxGeometry(0.09, 0.09, 0.09),
            glow(i % 2 ? 0xffe14d : 0x55ff88, 1.8),
          );
          led.position.set(cx + r.w * 0.25 - 0.8 + i * 0.4, 1.45, cz - r.d * 0.3 + 0.25);
          scene.add(led);
        }
        const coil = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 1.2, 10), std(0x8a8146));
        coil.position.set(cx - r.w * 0.25, 0.6, cz + r.d * 0.2);
        scene.add(coil);
        break;
      }
      case "storage": {
        const crateMat = std(0x8a734f, { roughness: 0.85, metalness: 0.15 });
        for (const [fx, fz, s] of [
          [-0.28, 0.25, 1.1],
          [-0.1, 0.32, 0.8],
          [0.3, -0.28, 1.0],
          [-0.3, -0.22, 0.7],
        ]) {
          const c = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), crateMat);
          c.position.set(cx + r.w * (fx as number), (s as number) / 2, cz + r.d * (fz as number));
          c.rotation.y = (fx as number) * 5;
          scene.add(c);
        }
        break;
      }
      case "nav": {
        const console_ = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.9, 0.7), std(0x44557a));
        console_.position.set(cx, 0.45, cz - r.d * 0.28);
        scene.add(console_);
        const scr = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.5, 0.08), glow(0x76aaff, 1.4));
        scr.position.set(cx, 1.15, cz - r.d * 0.28);
        scr.rotation.x = -0.3;
        scene.add(scr);
        break;
      }
      case "weapons": {
        const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.75, 1.0, 10), std(0x7a4d4d));
        turret.position.set(cx + r.w * 0.2, 0.5, cz + r.d * 0.2);
        scene.add(turret);
        const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.4, 8), std(0x4d3232));
        barrel.rotation.z = Math.PI / 2.5;
        barrel.position.set(cx + r.w * 0.2 + 0.5, 1.15, cz + r.d * 0.2);
        scene.add(barrel);
        const chair = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 1.0, 12), std(0x9aa7bd));
        chair.position.set(cx - r.w * 0.22, 0.5, cz - r.d * 0.15);
        scene.add(chair);
        break;
      }
      case "reactor": {
        const core = new THREE.Mesh(
          new THREE.CylinderGeometry(0.85, 0.85, 2.4, 18),
          new THREE.MeshStandardMaterial({
            color: 0x7dffb2,
            emissive: 0x1fd06a,
            emissiveIntensity: 1.8,
            transparent: true,
            opacity: 0.85,
          }),
        );
        core.position.set(cx, 1.2, cz);
        scene.add(core);
        const l = new THREE.PointLight(0x3dff8a, 15, 11, 2);
        l.position.set(cx, 1.6, cz);
        scene.add(l);
        break;
      }
      case "comms": {
        const rack = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.1, 0.55), std(0x574168));
        rack.position.set(cx + r.w * 0.28, 1.05, cz - r.d * 0.22);
        scene.add(rack);
        for (let i = 0; i < 4; i++) {
          const led = new THREE.Mesh(
            new THREE.BoxGeometry(0.09, 0.09, 0.09),
            glow(i % 2 ? 0xff5555 : 0xd6b3ff, 1.7),
          );
          led.position.set(cx + r.w * 0.28 - 0.35, 0.55 + i * 0.42, cz - r.d * 0.22 + 0.3);
          scene.add(led);
        }
        const dish = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 8, 0, Math.PI), std(0xb9a8cc));
        dish.rotation.x = -Math.PI / 3;
        dish.position.set(cx - r.w * 0.25, 1.6, cz + r.d * 0.2);
        scene.add(dish);
        break;
      }
      case "o2": {
        for (const [fx, fz] of [
          [-0.25, 0.2],
          [-0.32, -0.1],
          [0.28, 0.22],
        ]) {
          const can = new THREE.Mesh(
            new THREE.CylinderGeometry(0.36, 0.36, 1.5, 12),
            std(0x2fbf6b, { roughness: 0.4, metalness: 0.5 }),
          );
          can.position.set(cx + r.w * fx, 0.75, cz + r.d * fz);
          scene.add(can);
        }
        break;
      }
      case "admin":
      case "office": {
        const desk = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.8, 1.0), std(0x6e5064));
        desk.position.set(cx - r.w * 0.2, 0.4, cz + r.d * 0.2);
        scene.add(desk);
        const holoBase = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.05, 0.7, 6), std(0x5a6a80));
        holoBase.position.set(cx + r.w * 0.2, 0.35, cz - r.d * 0.15);
        scene.add(holoBase);
        const holo = new THREE.Mesh(
          new THREE.ConeGeometry(0.75, 1.0, 6, 1, true),
          new THREE.MeshStandardMaterial({
            color: 0xff9de8,
            emissive: 0xc9599f,
            emissiveIntensity: 1.3,
            transparent: true,
            opacity: 0.3,
            side: THREE.DoubleSide,
          }),
        );
        holo.position.set(cx + r.w * 0.2, 1.25, cz - r.d * 0.15);
        scene.add(holo);
        break;
      }
      case "security": {
        for (let i = 0; i < 3; i++) {
          const mon = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.7, 0.09), glow(0x9fd7ff, 1.4));
          mon.position.set(cx - 1.2 + i * 1.2, 1.7, cz - r.d / 2 + 0.65);
          scene.add(mon);
        }
        const deskS = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.7, 0.7), std(0x46536b));
        deskS.position.set(cx, 0.35, cz - r.d / 2 + 1.1);
        scene.add(deskS);
        break;
      }
      case "shields": {
        const hex = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.15, 6), glow(0x5ef2e8, 1.4));
        hex.position.set(cx, 0.08, cz);
        scene.add(hex);
        break;
      }
      case "green": {
        for (const [fx, fz] of [
          [-0.25, -0.2],
          [0.25, -0.25],
          [0.3, 0.25],
          [-0.3, 0.22],
        ]) {
          const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.24, 0.45, 10), std(0x7a5638));
          pot.position.set(cx + r.w * fx, 0.22, cz + r.d * fz);
          scene.add(pot);
          const plant = new THREE.Mesh(
            new THREE.ConeGeometry(0.45, 1.1, 8),
            std(0x3f9e4d, { roughness: 0.8, metalness: 0.05 }),
          );
          plant.position.set(cx + r.w * fx, 1.0, cz + r.d * fz);
          scene.add(plant);
        }
        break;
      }
      case "upperEng":
      case "lowerEng": {
        const eng = new THREE.Mesh(
          new THREE.CylinderGeometry(1.2, 1.5, 2.8, 14),
          std(0x8a6d4c, { metalness: 0.6, roughness: 0.5 }),
        );
        eng.rotation.z = Math.PI / 2;
        eng.position.set(cx - r.w * 0.15, 1.35, cz);
        scene.add(eng);
        const glowDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.25, 14), glow(0xff7a1a, 2.0));
        glowDisc.rotation.z = Math.PI / 2;
        glowDisc.position.set(cx - r.w * 0.15 - 1.5, 1.35, cz);
        scene.add(glowDisc);
        break;
      }
      default:
        break;
    }
  }
}

function buildEmergency(scene: THREE.Scene): void {
  const ex = EMERGENCY_POS.x;
  const ez = EMERGENCY_POS.z;
  const tableMat = new THREE.MeshStandardMaterial({ color: 0x8b98ab, roughness: 0.5, metalness: 0.5 });
  const emTop = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.2, 0.5, 24), tableMat);
  emTop.position.set(ex, 0.55, ez);
  scene.add(emTop);
  const btn = new THREE.Mesh(
    new THREE.CylinderGeometry(0.42, 0.5, 0.22, 20),
    new THREE.MeshStandardMaterial({
      color: 0xff2222,
      emissive: 0xaa0000,
      emissiveIntensity: 0.9,
      roughness: 0.35,
    }),
  );
  btn.position.set(ex, 0.92, ez);
  scene.add(btn);
  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(0.62, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2),
    new THREE.MeshStandardMaterial({
      color: 0xbfe6ff,
      transparent: true,
      opacity: 0.28,
      roughness: 0.1,
      metalness: 0.2,
    }),
  );
  dome.position.set(ex, 0.82, ez);
  scene.add(dome);
}

function buildPrisonProps(scene: THREE.Scene): void {
  const cx = PRISON_CENTER.x;
  const cz = PRISON_CENTER.z;
  const bench = new THREE.Mesh(
    new THREE.BoxGeometry(2.2, 0.35, 0.8),
    new THREE.MeshStandardMaterial({ color: 0x6b7688, roughness: 0.7, metalness: 0.4 }),
  );
  bench.position.set(cx - 1, 0.45, cz + 1.6);
  scene.add(bench);
  const jailLight = new THREE.PointLight(0xff5544, 8, 10, 2);
  jailLight.position.set(cx, 2.6, cz);
  scene.add(jailLight);

  // ---- BUGFIX: laser bars now block the actual DOORWAY (map-defined gate),
  // not a random wall. Energy bars span the gate opening.
  const g = PRISON_GATE;
  const postMat = new THREE.MeshStandardMaterial({
    color: 0xff4444,
    emissive: 0xaa1111,
    emissiveIntensity: 1.4,
  });
  const beamMat = new THREE.MeshStandardMaterial({
    color: 0xff6655,
    emissive: 0xdd2211,
    emissiveIntensity: 1.8,
    transparent: true,
    opacity: 0.65,
  });
  const half = g.span / 2;
  // side posts at the door frame
  for (const off of [-half, half]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.2, 3.1, 0.2), postMat);
    if (g.horizontal) post.position.set(g.x + off, 1.55, g.z);
    else post.position.set(g.x, 1.55, g.z + off);
    scene.add(post);
  }
  // top lintel
  const lintel = new THREE.Mesh(
    g.horizontal ? new THREE.BoxGeometry(g.span, 0.2, 0.2) : new THREE.BoxGeometry(0.2, 0.2, g.span),
    postMat,
  );
  lintel.position.set(g.x, 3.05, g.z);
  scene.add(lintel);
  // energy bars across the opening
  const barCount = 5;
  for (let i = 1; i < barCount; i++) {
    const off = -half + (i / barCount) * g.span;
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 2.9, 6), beamMat);
    if (g.horizontal) bar.position.set(g.x + off, 1.5, g.z);
    else bar.position.set(g.x, 1.5, g.z + off);
    scene.add(bar);
  }
  const gateLight = new THREE.PointLight(0xff3322, 6, 7, 2);
  gateLight.position.set(g.x, 2.2, g.z);
  scene.add(gateLight);
}

function buildMorgueProps(scene: THREE.Scene): void {
  const cx = MORGUE.x;
  const cz = MORGUE.z;
  const slabMat = new THREE.MeshStandardMaterial({
    color: 0x9fb4c4,
    roughness: 0.35,
    metalness: 0.55,
  });
  // cold slabs where corpses rest after meetings
  for (let i = 0; i < 3; i++) {
    const slab = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.55, 2.2), slabMat);
    slab.position.set(cx - 1.8 + i * 1.8, 0.28, cz + 0.6);
    slab.name = `morgueSlab${i}`;
    scene.add(slab);
  }
  // cold-storage wall of drawers
  const drawerMat = new THREE.MeshStandardMaterial({ color: 0x5d707f, roughness: 0.5, metalness: 0.6 });
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 2; j++) {
      const d = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.7, 0.5), drawerMat);
      d.position.set(cx - 1.2 + i * 1.2, 0.5 + j * 0.85, cz - 2.0);
      scene.add(d);
      const handle = new THREE.Mesh(
        new THREE.BoxGeometry(0.35, 0.06, 0.06),
        new THREE.MeshStandardMaterial({ color: 0xd0dde8, metalness: 0.8, roughness: 0.25 }),
      );
      handle.position.set(cx - 1.2 + i * 1.2, 0.5 + j * 0.85, cz - 1.72);
      scene.add(handle);
    }
  }
  // eerie cold light
  const cold = new THREE.PointLight(0x9adfff, 10, 9, 2);
  cold.position.set(cx, 2.4, cz);
  scene.add(cold);
}

function buildCameras(scene: THREE.Scene): void {
  for (const cam of CAMERAS) {
    const g = new THREE.Group();
    // pole
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.09, 2.7, 8),
      new THREE.MeshStandardMaterial({ color: 0x525a68, metalness: 0.7, roughness: 0.35 }),
    );
    pole.position.y = 1.35;
    g.add(pole);
    // head
    const head = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.3, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x22262e, roughness: 0.45, metalness: 0.5 }),
    );
    head.position.set(0, 2.72, 0.15);
    head.rotation.x = 0.35;
    g.add(head);
    // lens
    const lens = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.13, 0.1, 10),
      new THREE.MeshStandardMaterial({
        color: 0x74d7ff,
        emissive: 0x1a6c96,
        emissiveIntensity: 1.2,
        roughness: 0.15,
      }),
    );
    lens.rotation.x = Math.PI / 2 - 0.35;
    lens.position.set(0, 2.6, 0.5);
    g.add(lens);
    // blinking REC LED — engine finds these by name
    const ledMat = new THREE.MeshStandardMaterial({
      color: 0xff2222,
      emissive: 0xcc0000,
      emissiveIntensity: 2,
    });
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), ledMat);
    led.name = "camLED";
    led.position.set(0.18, 2.9, 0.1);
    g.add(led);
    // face roughly toward emergency center
    g.position.set(cam.x, 0, cam.z);
    g.rotation.y = Math.atan2(EMERGENCY_POS.x - cam.x, EMERGENCY_POS.z - cam.z);
    scene.add(g);
  }
}


function buildStations(scene: THREE.Scene): void {
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x515e73,
    roughness: 0.45,
    metalness: 0.65,
  });
  for (const st of STATIONS) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.25, 0.55), bodyMat);
    body.position.y = 0.62;
    g.add(body);
    const screenMat = new THREE.MeshStandardMaterial({
      color: 0x9ff5c0,
      emissive: 0x2fe07d,
      emissiveIntensity: 1.5,
    });
    const screen = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.62, 0.06), screenMat);
    screen.position.set(0, 1.28, 0.26);
    screen.rotation.x = -0.28;
    g.add(screen);
    const kb = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.06, 0.4),
      new THREE.MeshStandardMaterial({ color: 0x2b323e, roughness: 0.8 }),
    );
    kb.position.set(0, 1.02, 0.42);
    g.add(kb);
    g.position.set(st.x, 0, st.z);
    g.rotation.y = st.ry;
    g.userData.stationId = st.id;
    g.name = `station-${st.id}`;
    scene.add(g);
  }
}

function buildStars(scene: THREE.Scene): void {
  const count = 700;
  const pos = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const r = 150 + Math.random() * 250;
    const th = Math.random() * Math.PI * 2;
    const ph = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
    pos[i * 3 + 1] = Math.abs(r * Math.cos(ph)) * (Math.random() > 0.5 ? 1 : -0.3);
    pos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.PointsMaterial({ color: 0xdfe8ff, size: 0.9, sizeAttenuation: true });
  scene.add(new THREE.Points(geo, mat));
}

// ---------- hats -------------------------------------------------------------

export const HATS: { id: string; label: string; emoji: string }[] = [
  { id: "none", label: "خالی", emoji: "🚫" },
  { id: "crown", label: "تاج", emoji: "👑" },
  { id: "tophat", label: "شاپو", emoji: "🎩" },
  { id: "cap", label: "کپ", emoji: "🧢" },
  { id: "halo", label: "هاله", emoji: "😇" },
  { id: "horns", label: "شاخ", emoji: "😈" },
  { id: "antenna", label: "آنتن", emoji: "📡" },
];

export function makeHat(hatId: string): THREE.Group | null {
  const g = new THREE.Group();
  const gold = new THREE.MeshStandardMaterial({
    color: 0xffc93d,
    metalness: 0.75,
    roughness: 0.25,
    emissive: 0x6b4d00,
    emissiveIntensity: 0.35,
  });
  switch (hatId) {
    case "crown": {
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.28, 0.13, 12), gold);
      band.position.y = 1.72;
      g.add(band);
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.16, 6), gold);
        spike.position.set(Math.cos(a) * 0.24, 1.85, Math.sin(a) * 0.24);
        g.add(spike);
        const gem = new THREE.Mesh(
          new THREE.SphereGeometry(0.03, 6, 6),
          new THREE.MeshStandardMaterial({ color: 0xff2255, emissive: 0x881122, emissiveIntensity: 0.8 }),
        );
        gem.position.set(Math.cos(a) * 0.28, 1.72, Math.sin(a) * 0.28);
        g.add(gem);
      }
      return g;
    }
    case "tophat": {
      const black = new THREE.MeshStandardMaterial({ color: 0x14151c, roughness: 0.55 });
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.04, 16), black);
      brim.position.y = 1.68;
      g.add(brim);
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.22, 0.34, 16), black);
      top.position.y = 1.87;
      g.add(top);
      const ribbon = new THREE.Mesh(
        new THREE.CylinderGeometry(0.225, 0.225, 0.07, 16),
        new THREE.MeshStandardMaterial({ color: 0xb01030, roughness: 0.5 }),
      );
      ribbon.position.y = 1.74;
      g.add(ribbon);
      return g;
    }
    case "cap": {
      const blue = new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.6 });
      const dome = new THREE.Mesh(
        new THREE.SphereGeometry(0.27, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2),
        blue,
      );
      dome.position.y = 1.66;
      g.add(dome);
      const brim = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.03, 0.24), blue);
      brim.position.set(0, 1.67, 0.32);
      g.add(brim);
      return g;
    }
    case "halo": {
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.22, 0.035, 8, 24),
        new THREE.MeshStandardMaterial({
          color: 0xffe97d,
          emissive: 0xffd83d,
          emissiveIntensity: 1.6,
        }),
      );
      halo.rotation.x = Math.PI / 2;
      halo.position.y = 1.98;
      g.add(halo);
      return g;
    }
    case "horns": {
      const red = new THREE.MeshStandardMaterial({
        color: 0xd91e1e,
        roughness: 0.4,
        emissive: 0x550808,
        emissiveIntensity: 0.5,
      });
      for (const s of [-1, 1]) {
        const horn = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.24, 8), red);
        horn.position.set(s * 0.2, 1.78, 0);
        horn.rotation.z = -s * 0.5;
        g.add(horn);
      }
      return g;
    }
    case "antenna": {
      const stem = new THREE.Mesh(
        new THREE.CylinderGeometry(0.015, 0.02, 0.3, 6),
        new THREE.MeshStandardMaterial({ color: 0x8a93a5, metalness: 0.7, roughness: 0.35 }),
      );
      stem.position.y = 1.82;
      g.add(stem);
      const ball = new THREE.Mesh(
        new THREE.SphereGeometry(0.06, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xff3b3b, emissive: 0xaa1111, emissiveIntensity: 1.2 }),
      );
      ball.position.y = 2.0;
      g.add(ball);
      return g;
    }
    default:
      return null;
  }
}

// ---------- crewmate character ---------------------------------------------

export interface CharacterRig {
  group: THREE.Group;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  body: THREE.Mesh;
  bubble: THREE.Sprite;
  bubbleCanvas: HTMLCanvasElement;
  bubbleTex: THREE.CanvasTexture;
}

export function drawBubble(rig: CharacterRig, text: string): void {
  const cv = rig.bubbleCanvas;
  const ctx = cv.getContext("2d")!;
  ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.font = "700 30px Vazirmatn, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  // wrap into max 2 lines
  const words = text.split(" ");
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const test = cur ? cur + " " + w : w;
    if (ctx.measureText(test).width > 420 && cur) {
      lines.push(cur);
      cur = w;
    } else cur = test;
  }
  if (cur) lines.push(cur);
  const shown = lines.slice(0, 2);
  const widest = Math.min(460, Math.max(...shown.map((l) => ctx.measureText(l).width)) + 44);
  const bh = shown.length > 1 ? 108 : 72;
  const x0 = (cv.width - widest) / 2;
  const y0 = 10;
  // bubble
  ctx.fillStyle = "rgba(255,255,255,0.96)";
  ctx.strokeStyle = "rgba(0,0,0,0.55)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(x0, y0, widest, bh, 22);
  ctx.fill();
  ctx.stroke();
  // tail
  ctx.beginPath();
  ctx.moveTo(cv.width / 2 - 14, y0 + bh - 2);
  ctx.lineTo(cv.width / 2, y0 + bh + 22);
  ctx.lineTo(cv.width / 2 + 14, y0 + bh - 2);
  ctx.closePath();
  ctx.fill();
  // text
  ctx.fillStyle = "#0c1220";
  shown.forEach((l, i) => {
    ctx.fillText(l, cv.width / 2, y0 + bh / 2 + (i - (shown.length - 1) / 2) * 38);
  });
  rig.bubbleTex.needsUpdate = true;
  rig.bubble.visible = true;
}

function nameSprite(text: string): THREE.Sprite {
  const cv = document.createElement("canvas");
  cv.width = 256;
  cv.height = 80;
  const ctx = cv.getContext("2d")!;
  ctx.font = "900 44px Vazirmatn, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.lineWidth = 8;
  ctx.strokeStyle = "rgba(0,0,0,0.85)";
  ctx.strokeText(text, 128, 40);
  ctx.fillStyle = "#ffffff";
  ctx.fillText(text, 128, 40);
  const tex = new THREE.CanvasTexture(cv);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false }));
  sp.scale.set(1.7, 0.53, 1);
  sp.position.y = 2.15;
  return sp;
}

export function makeCrewmate(colorHex: string, name: string, hatId = "none"): CharacterRig {
  const color = new THREE.Color(colorHex);
  const dark = color.clone().multiplyScalar(0.55);
  const g = new THREE.Group();

  const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.42, metalness: 0.08 });
  const darkMat = new THREE.MeshStandardMaterial({ color: dark, roughness: 0.5 });

  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.55, 6, 14), bodyMat);
  body.position.y = 1.02;
  body.scale.set(1, 1, 0.92);
  body.castShadow = true;
  g.add(body);

  // visor
  const visor = new THREE.Mesh(
    new THREE.SphereGeometry(0.26, 16, 12),
    new THREE.MeshStandardMaterial({
      color: 0xa8d3e8,
      roughness: 0.08,
      metalness: 0.35,
      emissive: 0x1c3742,
      emissiveIntensity: 0.5,
    }),
  );
  visor.scale.set(1.15, 0.75, 0.7);
  visor.position.set(0, 1.38, 0.34);
  g.add(visor);

  // backpack
  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.62, 0.26), darkMat);
  pack.position.set(0, 1.0, -0.45);
  g.add(pack);

  // legs
  const legGeo = new THREE.CapsuleGeometry(0.15, 0.28, 4, 8);
  const legL = new THREE.Mesh(legGeo, darkMat);
  legL.position.set(-0.2, 0.3, 0);
  g.add(legL);
  const legR = new THREE.Mesh(legGeo, darkMat);
  legR.position.set(0.2, 0.3, 0);
  g.add(legR);

  // soft shadow blob
  const blob = new THREE.Mesh(
    new THREE.CircleGeometry(0.55, 20),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3 }),
  );
  blob.rotation.x = -Math.PI / 2;
  blob.position.y = 0.02;
  g.add(blob);

  g.add(nameSprite(name));

  // hat
  const hat = makeHat(hatId);
  if (hat) g.add(hat);

  // speech bubble sprite
  const bubbleCanvas = document.createElement("canvas");
  bubbleCanvas.width = 512;
  bubbleCanvas.height = 160;
  const bubbleTex = new THREE.CanvasTexture(bubbleCanvas);
  const bubble = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: bubbleTex, depthTest: false, transparent: true }),
  );
  bubble.scale.set(3.4, 1.06, 1);
  bubble.position.y = 2.85;
  bubble.visible = false;
  g.add(bubble);

  return { group: g, legL, legR, body, bubble, bubbleCanvas, bubbleTex };
}

export function makeCorpse(colorHex: string): THREE.Group {
  const color = new THREE.Color(colorHex);
  const g = new THREE.Group();
  // lower half of the body lying down
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.42, 0.4, 6, 14),
    new THREE.MeshStandardMaterial({ color, roughness: 0.45 }),
  );
  body.rotation.z = Math.PI / 2;
  body.position.set(0, 0.42, 0);
  g.add(body);
  // bone
  const boneMat = new THREE.MeshStandardMaterial({ color: 0xf2f0e6, roughness: 0.6 });
  const bone = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.5, 8), boneMat);
  bone.position.set(0.42, 0.72, 0);
  bone.rotation.z = 0.35;
  g.add(bone);
  for (const [dx, dy] of [
    [-0.09, 0.24],
    [0.09, 0.26],
  ]) {
    const k = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), boneMat);
    k.position.set(0.42 + dx, 0.72 + dy, 0);
    g.add(k);
  }
  // blood pool
  const blood = new THREE.Mesh(
    new THREE.CircleGeometry(0.85, 22),
    new THREE.MeshBasicMaterial({ color: 0x7a0f14, transparent: true, opacity: 0.85 }),
  );
  blood.rotation.x = -Math.PI / 2;
  blood.position.y = 0.03;
  blood.scale.set(1.3, 0.9, 1);
  g.add(blood);
  return g;
}
