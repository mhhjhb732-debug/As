// Tiny synthesized SFX — no assets needed.

import { getSettings } from "./settings";

let ctx: AudioContext | null = null;
let masterVolume = getSettings().volume;

export function setVolume(v: number): void {
  masterVolume = Math.min(1, Math.max(0, v));
}

export function ensureAudio(): void {
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* audio unavailable */
  }
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType = "sine",
  gain = 0.08,
  when = 0,
  slideTo?: number,
): void {
  if (!ctx || ctx.state !== "running" || masterVolume <= 0) return;
  gain *= masterVolume;
  try {
    const t0 = ctx.currentTime + when;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  } catch {
    /* ignore */
  }
}

// ---- English voice announcements (Web Speech API) ----------------------------

export type SpeechKey =
  | "gameStart"
  | "voting"
  | "youImpostor"
  | "youCrew"
  | "victory"
  | "defeat"
  | "kill"
  | "bodyReported"
  | "emergency"
  | "ejected"
  | "notEjected"
  | "jailed"
  | "sabotageReactor"
  | "sabotageLights"
  | "sabotageFixed"
  | "camsDown"
  | "taskComplete"
  | "youDied";

const LINES: Record<SpeechKey, string> = {
  gameStart: "The game has started",
  voting: "Voting time",
  youImpostor: "You are the impostor",
  youCrew: "You are a crewmate",
  victory: "Victory",
  defeat: "Defeat",
  kill: "Elimination",
  bodyReported: "Dead body reported",
  emergency: "Emergency meeting",
  ejected: "Ejected",
  notEjected: "No one was ejected",
  jailed: "Sent to jail",
  sabotageReactor: "Reactor meltdown. Evacuate",
  sabotageLights: "Lights sabotaged",
  sabotageFixed: "Systems restored",
  camsDown: "Cameras offline",
  taskComplete: "Task complete",
  youDied: "You were eliminated",
};

let enVoice: SpeechSynthesisVoice | null | undefined;

function pickVoice(): SpeechSynthesisVoice | null {
  const voices = speechSynthesis.getVoices();
  return (
    voices.find((v) => v.lang.startsWith("en-US")) ??
    voices.find((v) => v.lang.startsWith("en")) ??
    null
  );
}

export function speak(key: SpeechKey): void {
  try {
    if (getSettings().voiceLang === "off") return;
    if (masterVolume <= 0 || !("speechSynthesis" in window)) return;
    if (enVoice === undefined) {
      enVoice = pickVoice();
      if (!enVoice) {
        speechSynthesis.onvoiceschanged = () => {
          enVoice = pickVoice();
        };
      }
    }
    speechSynthesis.cancel(); // don't overlap announcements
    const u = new SpeechSynthesisUtterance(LINES[key]);
    u.lang = "en-US";
    if (enVoice) u.voice = enVoice;
    u.volume = masterVolume;
    u.rate = 1.0;
    u.pitch = 1.0;
    speechSynthesis.speak(u);
  } catch {
    /* speech unavailable */
  }
}

export const sfx = {
  heartbeat(): void {
    tone(52, 0.14, "sine", 0.3);
    tone(42, 0.16, "sine", 0.26, 0.18);
  },
  alarm(): void {
    tone(840, 0.16, "square", 0.045);
    tone(620, 0.16, "square", 0.045, 0.2);
  },
  kill(): void {
    tone(220, 0.25, "sawtooth", 0.18, 0, 60);
    tone(95, 0.5, "sawtooth", 0.22, 0.05, 40);
  },
  meeting(): void {
    tone(523, 0.11, "square", 0.08);
    tone(523, 0.11, "square", 0.08, 0.17);
    tone(740, 0.3, "square", 0.08, 0.38);
  },
  task(): void {
    tone(660, 0.1, "sine", 0.1);
    tone(990, 0.2, "sine", 0.1, 0.11);
  },
  sabotage(): void {
    tone(140, 0.4, "sawtooth", 0.14, 0, 70);
    tone(110, 0.55, "sawtooth", 0.14, 0.3, 55);
  },
  click(): void {
    tone(480, 0.06, "sine", 0.07);
  },
  fixed(): void {
    tone(440, 0.12, "sine", 0.1);
    tone(660, 0.12, "sine", 0.1, 0.13);
    tone(880, 0.25, "sine", 0.1, 0.26);
  },
};
