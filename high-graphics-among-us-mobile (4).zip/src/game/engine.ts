import * as THREE from "three";
import {
  CAMERAS,
  COLORS,
  EMERGENCY_POS,
  NODES,
  PRISON,
  SINGLE_TASK_POOL,
  SPAWN_RING,
  STATIONS,
  TASK_CHAINS,
  canStand,
  roomNameAt,
  setActiveMap,
  NavNode,
} from "./mapData";
import { buildShip, makeCrewmate, HATS, CharacterRig } from "./world";
import {
  ActiveStation,
  EngineEvent,
  GameOverData,
  HudState,
  MeetingData,
  PlayerInfo,
  ProposalData,
  ProposalKind,
  SabKind,
  SabotageState,
  TalkKind,
  TaskInfo,
} from "./types";

import {
  CAM_WATCH_RANGE,
  PLAYER_SPEED,
  RADIUS,
  SIT_RANGE,
  } from "./constants";
import { ARCHETYPES, BotMind } from "./personality";
import { startWatchingCams as cCTVSystem_startWatchingCams, stopWatchingCams as cCTVSystem_stopWatchingCams, switchCam as cCTVSystem_switchCam, rotateCam as cCTVSystem_rotateCam, getCamLog as cCTVSystem_getCamLog, getCamHint as cCTVSystem_getCamHint, killCams as cCTVSystem_killCams, sabotageCameras as cCTVSystem_sabotageCameras, inCameraView as cCTVSystem_inCameraView, getCamRoomName as cCTVSystem_getCamRoomName } from "./systems/CCTVSystem";
import { sitDown as socialSystem_sitDown, standUp as socialSystem_standUp, tableSay as socialSystem_tableSay, nearestTalkable as socialSystem_nearestTalkable, say as socialSystem_say, playerTalk as socialSystem_playerTalk, respondProposal as socialSystem_respondProposal, buildProposal as socialSystem_buildProposal, updateSocial as socialSystem_updateSocial } from "./systems/SocialSystem";
import { getMeetingSeed as meetingSystem_getMeetingSeed, noteMeetingClaim as meetingSystem_noteMeetingClaim, settleMeetingOutcome as meetingSystem_settleMeetingOutcome, startMeeting as meetingSystem_startMeeting, resolveMeeting as meetingSystem_resolveMeeting } from "./systems/MeetingSystem";
import { jail as jailSystem_jail } from "./systems/JailSystem";
import { nearestBody as killSystem_nearestBody, nearestVictim as killSystem_nearestVictim, fleePath as killSystem_fleePath, kill as killSystem_kill, pressKill as killSystem_pressKill, pressReport as killSystem_pressReport, bodyClue as killSystem_bodyClue } from "./systems/KillSystem";
import { taskInfos as taskSystem_taskInfos, getActiveStation as taskSystem_getActiveStation, completeStation as taskSystem_completeStation, updateTaskWork as taskSystem_updateTaskWork, globalTaskProgress as taskSystem_globalTaskProgress } from "./systems/TaskSystem";
import { triggerSabotage as sabotageSystem_triggerSabotage, startSabotage as sabotageSystem_startSabotage, clearSabotage as sabotageSystem_clearSabotage, applyBlackout as sabotageSystem_applyBlackout, updateSabotage as sabotageSystem_updateSabotage } from "./systems/SabotageSystem";
import { updateBots as botAISystem_updateBots } from "./systems/BotAISystem";
import { updateCamera as renderSystem_updateCamera, updateFootprints as renderSystem_updateFootprints } from "./systems/RenderSystem";

import { getSettings, pixelRatioFor, viewSize } from "./settings";

type SocialMode = "none" | "approach" | "await" | "buddy" | "lead" | "table";

export interface Entity {
  info: PlayerInfo;
  rig: CharacterRig;
  x: number;
  z: number;
  yaw: number;
  targetYaw: number;
  walking: boolean;
  path: NavNode[];
  dwell: number;
  taskTimer: number;
  killCd: number;
  stuck: number;
  lastX: number;
  lastZ: number;
  reportDelay: number;
  // social
  social: SocialMode;
  socialT: number; // timer for current social mode
  leadNodeId: string | null;
  leadKind: ProposalKind | null;
  repathT: number;
  bubbleT: number;
  chatterT: number;
  jailedT: number;
  bloodyT: number; // leaves footprints while > 0
  lastPX: number;
  lastPZ: number;
  seatX: number;
  seatZ: number;
  mind: BotMind | null; // bots only — personality + memory + relationships
}

export interface TransientAnim {
  obj: THREE.Object3D;
  t: number;
  dur: number;
  kind: "corpse" | "ghost" | "print";
}

export interface Body {
  victimId: number;
  killerId: number;
  x: number;
  z: number;
  mesh: THREE.Group;
}

export interface PlayerTask {
  id: string;
  label: string;
  steps: { st: string; label: string }[];
  step: number; // completed steps
}



export class GameEngine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  clock = new THREE.Clock();
  raf = 0;

  entities: Entity[] = [];
  bodies: Body[] = [];
  witnesses = new Map<number, number>();

  state: "playing" | "meeting" | "over" = "playing";
  onEvent: (e: EngineEvent) => void;

  // player
  pitch = -0.06;
  moveX = 0;
  moveY = 0;
  keys = new Set<string>();
  isGhost = false;
  tasks: PlayerTask[] = [];
  playerKillCd = 12;
  emergencyLeft = 1;
  shake = 0;
  ghostBob = 0;

  // economy
  coins = 30;

  // sabotage
  sab: SabotageState | null = null;
  sabCd = 25;
  botSabTimer = 45 + Math.random() * 25;
  fixerIds = new Set<number>();
  sharedFixTime = 0;
  alarmLight: THREE.PointLight;
  flashlight: THREE.SpotLight;
  allLights: { l: THREE.Light; base: number }[] = [];
  ambient: THREE.AmbientLight;
  hemi: THREE.HemisphereLight;

  // bot task economy
  botTaskUnits = 0;
  botTaskTotal = 0;
  playerUnitsTotal = 0;

  playerHat = "none";
  socialTimer = 14;
  activeProposal: { botId: number; kind: ProposalKind } | null = null;
  anims: TransientAnim[] = [];
  spawnT = 1.1;
  voteTokens = 4;
  defensesLeft = 2;

  // CCTV
  camerasDownT = 0;
  camCd = 20;
  cameraEvidence: number | null = null;
  camLEDs: THREE.MeshStandardMaterial[] = [];
  camView = -1; // -1 = not watching
  monitorPos = { x: 0, z: 0 };
  camSway = 0;

  // deals / threats / grudges
  pendingDeal: { botId: number; targetId: number; reward: number } | null = null;
  threatBotId: number | null = null;
  grudges = new Set<number>();
  quarrelBotId: number | null = null;
  quarrelReward = 0;

  // forced elimination mission
  pendingMission: { botId: number; targetId: number; reward: number } | null = null;

  // accomplice murder plan (impostor proposes a joint kill)
  pendingMurder: { botId: number; targetId: number; reward: number } | null = null;

  // CCTV sighting log + manual rotation
  sightMap = new Map<number, { room: string; t: number }>();
  sightTimer = 0;
  worldT = 0;
  camYawOff = 0;
  camPitchOff = 0;
  botCamCd = 30; // bot impostor's own camera-sabotage cooldown
  morgueCount = 0;

  // table-chat (sitting at the emergency table just to talk)
  sitting = false;

  // pause (stop menu): freezes simulation, keeps rendering the scene
  paused = false;

  setPaused(p: boolean) {
    this.paused = p;
    if (p) this.setMove(0, 0);
    else this.clock.getDelta(); // discard time spent paused
  }

  /** re-read user settings (called live from the pause menu) */
  applySettings() {
    const s = getSettings();
    this.fpsInterval = s.fps === 30 ? 1 / 31 : 0;
    this.targetRatio = pixelRatioFor(s.quality);
    if (this.curRatio > this.targetRatio) {
      this.curRatio = this.targetRatio;
      this.renderer.setPixelRatio(this.curRatio);
    }
  }

  // fps cap (settings): 0 = uncapped/60, otherwise min seconds per frame
  fpsInterval = 0;
  frameAcc = 0;

  // dynamic resolution: auto-scale pixel ratio to hold a smooth framerate
  targetRatio = 1; // from quality setting
  curRatio = 1;
  fpsEma = 60;
  dynResTimer = 0;

  botCount = 9;
  impostorCount = 2;

  constructor(
    canvas: HTMLCanvasElement,
    playerColorIdx: number,
    playerIsImpostor: boolean,
    playerHat: string,
    mapIdx: number,
    onEvent: (e: EngineEvent) => void,
    lobby?: { botCount: number; impostorCount: number },
  ) {
    setActiveMap(mapIdx);
    if (lobby) {
      // clamp: 4..9 bots (colors limit), 1..3 impostors, crew must outnumber
      this.botCount = Math.min(9, Math.max(4, lobby.botCount));
      this.impostorCount = Math.min(
        3,
        Math.max(1, Math.min(lobby.impostorCount, Math.floor((this.botCount + 1) / 3))),
      );
    }
    this.playerHat = playerHat;
    this.onEvent = onEvent;
    const settings = getSettings();
    this.fpsInterval = settings.fps === 30 ? 1 / 31 : 0;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: settings.quality === "high" || settings.quality === "ultra",
    });
    this.targetRatio = pixelRatioFor(settings.quality);
    this.curRatio = this.targetRatio;
    this.renderer.setPixelRatio(this.curRatio);
    const vs0 = viewSize();
    this.renderer.setSize(vs0.w, vs0.h);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    // pro graphics on high/ultra: soft shadows + richer exposure
    if (settings.quality === "high" || settings.quality === "ultra") {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.toneMappingExposure = 1.2;
      // key light casting soft shadows over the whole ship
      const key = new THREE.DirectionalLight(0xcfe0ff, 0.9);
      key.position.set(20, 30, 10);
      key.castShadow = true;
      key.shadow.mapSize.set(settings.quality === "ultra" ? 2048 : 1024, settings.quality === "ultra" ? 2048 : 1024);
      key.shadow.camera.left = -45;
      key.shadow.camera.right = 45;
      key.shadow.camera.top = 45;
      key.shadow.camera.bottom = -45;
      key.shadow.bias = -0.001;
      this.scene.add(key);
    }
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    this.camera = new THREE.PerspectiveCamera(72, vs0.w / vs0.h, 0.1, 500);

    this.scene.background = new THREE.Color(0x04060d);
    this.scene.fog = new THREE.Fog(0x04060d, 26, 60);
    this.ambient = new THREE.AmbientLight(0x3b4a66, 1.15);
    this.scene.add(this.ambient);
    this.hemi = new THREE.HemisphereLight(0x6d84ad, 0x1a2030, 0.85);
    this.scene.add(this.hemi);

    buildShip(this.scene, mapIdx);

    // collect all point lights for sabotage dimming + camera LEDs
    this.scene.traverse((o) => {
      if ((o as THREE.PointLight).isPointLight) {
        const pl = o as THREE.PointLight;
        this.allLights.push({ l: pl, base: pl.intensity });
      }
      if (o.name === "camLED") {
        this.camLEDs.push((o as THREE.Mesh).material as THREE.MeshStandardMaterial);
      }
    });

    // security-monitor watch point: security room, else comms
    {
      const rooms = this.scene ? null : null;
      void rooms;
      const sec =
        NODES.find((n) => n.id === "security") ?? NODES.find((n) => n.id === "comms");
      if (sec) this.monitorPos = { x: sec.x, z: sec.z };
    }

    // reactor alarm light
    this.alarmLight = new THREE.PointLight(0xff1a1a, 0, 60, 1.2);
    this.alarmLight.position.set(-26, 2.6, 0);
    this.scene.add(this.alarmLight);

    // player flashlight (used in blackout)
    this.scene.add(this.camera);
    this.flashlight = new THREE.SpotLight(0xcfe0ff, 0, 22, 0.55, 0.45, 1.1);
    this.flashlight.position.set(0, 0, 0.1);
    const flTarget = new THREE.Object3D();
    flTarget.position.set(0, -0.15, -6);
    this.camera.add(flTarget);
    this.flashlight.target = flTarget;
    this.camera.add(this.flashlight);

    this.setupPlayers(playerColorIdx, playerIsImpostor);
    this.setupInput();

    window.addEventListener("resize", this.onResize);
    this.loop();
  }

  // ------------------------------------------------------------------ setup

  setupPlayers(playerColorIdx: number, playerIsImpostor: boolean) {
    const idxPool = COLORS.map((_, i) => i).filter((i) => i !== playerColorIdx);
    for (let i = idxPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [idxPool[i], idxPool[j]] = [idxPool[j], idxPool[i]];
    }
    const botColorIdxs = idxPool.slice(0, this.botCount);
    // distribute impostor roles: if the player is one, the rest go to bots
    const botImpostorCount = Math.min(
      Math.max(0, this.impostorCount - (playerIsImpostor ? 1 : 0)),
      botColorIdxs.length - 1, // at least one crew bot must remain
    );
    const slotPool = botColorIdxs.map((_, i) => i);
    for (let i = slotPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [slotPool[i], slotPool[j]] = [slotPool[j], slotPool[i]];
    }
    const impostorSlots = new Set(slotPool.slice(0, botImpostorCount));

    const makeEntity = (
      id: number,
      colorIdx: number,
      isBot: boolean,
      isImpostor: boolean,
      angle: number,
    ): Entity => {
      const c = COLORS[colorIdx];
      const hat = isBot
        ? HATS[Math.floor(Math.random() * HATS.length)].id
        : this.playerHat;
      const rig = makeCrewmate(c.hex, c.name, hat);
      const x = EMERGENCY_POS.x + Math.cos(angle) * SPAWN_RING;
      const z = EMERGENCY_POS.z + Math.sin(angle) * SPAWN_RING;
      rig.group.position.set(x, 0, z);
      if (!isBot) rig.group.visible = false;
      this.scene.add(rig.group);
      return {
        info: { id, name: c.name, color: c.hex, colorName: c.name, alive: true, isImpostor, isBot, hat },
        rig,
        x,
        z,
        yaw: angle + Math.PI,
        targetYaw: angle + Math.PI,
        walking: false,
        path: [],
        dwell: 1 + Math.random() * 3,
        taskTimer: 14 + Math.random() * 14,
        killCd: 24 + Math.random() * 10,
        stuck: 0,
        lastX: x,
        lastZ: z,
        reportDelay: 0,
        social: "none",
        socialT: 0,
        leadNodeId: null,
        leadKind: null,
        repathT: 0,
        bubbleT: 0,
        chatterT: 20 + Math.random() * 40,
        jailedT: 0,
        bloodyT: 0,
        lastPX: x,
        lastPZ: z,
        seatX: 0,
        seatZ: 0,
        mind: isBot ? new BotMind(ARCHETYPES[id % ARCHETYPES.length]) : null,
      };
    };

    this.entities.push(makeEntity(0, playerColorIdx, false, playerIsImpostor, -Math.PI / 2));
    const total = botColorIdxs.length + 1;
    botColorIdxs.forEach((ci, i) => {
      const ang = -Math.PI / 2 + ((i + 1) / total) * Math.PI * 2;
      this.entities.push(makeEntity(i + 1, ci, true, impostorSlots.has(i), ang));
    });

    const p = this.entities[0];
    this.camera.position.set(p.x, 1.55, p.z);

    // tasks: 2 multi-stage chains + 3 single tasks
    if (!playerIsImpostor) {
      for (const ch of TASK_CHAINS) {
        this.tasks.push({ id: ch.id, label: ch.label, steps: [...ch.steps], step: 0 });
      }
      const singles = [...SINGLE_TASK_POOL].sort(() => Math.random() - 0.5).slice(0, 3);
      for (const sid of singles) {
        const st = STATIONS.find((s) => s.id === sid)!;
        this.tasks.push({
          id: sid,
          label: st.label,
          steps: [{ st: sid, label: st.label }],
          step: 0,
        });
      }
      this.playerUnitsTotal = this.tasks.reduce((a, t) => a + t.steps.length, 0);
    }
    const crewBots = this.entities.filter((e) => e.info.isBot && !e.info.isImpostor).length;
    this.botTaskTotal = crewBots * 5;
  }

  // named handlers so destroy() can actually unregister them (leak fix)
  onKeyDown = (e: KeyboardEvent) => this.keys.add(e.code);
  onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);

  setupInput() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
  }

  onResize = () => {
    const vs = viewSize();
    this.camera.aspect = vs.w / vs.h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(vs.w, vs.h);
  };

  // ------------------------------------------------------------- public API

  setMove(x: number, y: number) {
    this.moveX = x;
    this.moveY = y;
  }

  addLook(dx: number, dy: number) {
    const p = this.entities[0];
    p.yaw -= dx * 0.0042;
    this.pitch = Math.max(-1.1, Math.min(0.75, this.pitch - dy * 0.0038));
  }

  getPlayers(): PlayerInfo[] {
    return this.entities.map((e) => ({ ...e.info }));
  }

  /**
   * Meeting seed built ONLY from what each bot actually knows:
   * its own memories (evidenceScore) — no god-mode reads.
   * The witness line carries the correct claim strength:
   * "sawKill" (دیدم!) vs "nearBody" (نزدیک جسد بود).
   */
  getMeetingSeed(): {
    scores: Record<number, Record<number, number>>;
    witness: { id: number; suspectId: number; kind: "sawKill" | "nearBody" } | null;
    personalities: Record<number, { aggression: number; bravery: number; label: string }>;
  } {
    return meetingSystem_getMeetingSeed(this);
  }

  /** meeting tells the engine what happened socially, so bots remember it */
  noteMeetingClaim(
    speakerId: number,
    targetId: number,
    kind: "accusation" | "defense" | "lie",
  ) {
    return meetingSystem_noteMeetingClaim(this, speakerId, targetId, kind);
  }

  getIntel(): { suspectId: number | null; witnessId: number | null; camera: boolean } {
    // CCTV evidence beats eyewitness testimony
    if (this.cameraEvidence !== null) {
      return { suspectId: this.cameraEvidence, witnessId: null, camera: true };
    }
    for (const [killer, witness] of this.witnesses) {
      return { suspectId: killer, witnessId: witness, camera: false };
    }
    return { suspectId: null, witnessId: null, camera: false };
  }

  // ---------------------------------------------------------- CCTV watching

  startWatchingCams(): boolean {
    return cCTVSystem_startWatchingCams(this);
  }

  stopWatchingCams() {
    return cCTVSystem_stopWatchingCams(this);
  }

  switchCam(dir: number) {
    return cCTVSystem_switchCam(this, dir);
  }

  /** drag-rotate the CCTV camera while watching */
  rotateCam(dx: number, dy: number) {
    return cCTVSystem_rotateCam(this, dx, dy);
  }

  /** who passed in front of cameras recently (for meetings & the log panel) */
  getCamLog(): { id: number; name: string; color: string; room: string; secsAgo: number }[] {
    return cCTVSystem_getCamLog(this);
  }

  /** if the most recent killer was caught passing a camera lately */
  getCamHint(): { suspectId: number; room: string; secsAgo: number } | null {
    return cCTVSystem_getCamHint(this);
  }

  getMission(): { botId: number; targetId: number; reward: number } | null {
    return this.pendingMission ? { ...this.pendingMission } : null;
  }

  // ------------------------------------------------------- table chat mode

  sitDown() {
    return socialSystem_sitDown(this);
  }

  standUp() {
    return socialSystem_standUp(this);
  }

  /** player says something at the table; a seated guest replies */
  tableSay(idx: number): string {
    return socialSystem_tableSay(this, idx);
  }

  getCamRoomName(): string {
    return cCTVSystem_getCamRoomName(this);
  }

  // ------------------------------------------------------ deals & grudges

  getDeal(): { botId: number; targetId: number; reward: number } | null {
    return this.pendingDeal ? { ...this.pendingDeal } : null;
  }

  getGrudges(): number[] {
    return [...this.grudges];
  }

  /** called after each meeting with the final votes */
  settleMeetingOutcome(
    votes: Record<number, number | -1>,
    ejectedId: number | null = null,
    jailedId: number | null = null,
  ) {
    return meetingSystem_settleMeetingOutcome(this, votes, ejectedId, jailedId);
  }

  /** shared cams-down routine — used by the player AND smart bot impostors */
  killCams(duration: number) {
    return cCTVSystem_killCams(this, duration);
  }

  sabotageCameras() {
    return cCTVSystem_sabotageCameras(this);
  }

  inCameraView(x: number, z: number): boolean {
    return cCTVSystem_inCameraView(this, x, z);
  }

  spendCoins(n: number): boolean {
    if (this.coins < n) return false;
    this.coins -= n;
    return true;
  }

  taskInfos(): TaskInfo[] {
    return taskSystem_taskInfos(this);
  }

  getActiveStation(): ActiveStation | null {
    return taskSystem_getActiveStation(this);
  }

  completeStation(stationId: string) {
    return taskSystem_completeStation(this, stationId);
  }

  getHud(): HudState {
    const p = this.entities[0];
    const active = this.getActiveStation();
    const talkable =
      this.isGhost || p.jailedT > 0 || this.state !== "playing"
        ? null
        : this.nearestTalkable();
    const nearEmergency =
      Math.hypot(p.x - EMERGENCY_POS.x, p.z - EMERGENCY_POS.z) < 2.6 &&
      this.emergencyLeft > 0 &&
      !this.isGhost &&
      p.jailedT <= 0 &&
      !this.sab;
    let useLabel = "";
    let useKind: HudState["useKind"] = null;
    let canUse = false;
    if (active) {
      useLabel = active.label;
      useKind = active.isFix ? "fix" : "task";
      canUse = true;
    } else if (nearEmergency) {
      useLabel = "جلسه اضطراری";
      useKind = "emergency";
      canUse = true;
    }

    // fear factor: closest alive impostor (crew only)
    let danger = 0;
    if (!p.info.isImpostor && !this.isGhost) {
      for (const e of this.entities) {
        if (!e.info.alive || !e.info.isImpostor) continue;
        const d = Math.hypot(p.x - e.x, p.z - e.z);
        if (d < 8) danger = Math.max(danger, (8 - d) / 8);
      }
    }

    return {
      canUse,
      useLabel,
      useKind,
      canReport: !this.isGhost && this.nearestBody() !== null,
      canKill:
        p.info.isImpostor && !this.isGhost && this.playerKillCd <= 0 && this.nearestVictim() !== null,
      killCooldown: Math.max(0, this.playerKillCd),
      nearEmergency,
      taskProgress: this.globalTaskProgress(),
      tasks: this.taskInfos(),
      isImpostor: p.info.isImpostor,
      isGhost: this.isGhost,
      playerPos: { x: p.x, z: p.z },
      roomName: roomNameAt(p.x, p.z),
      coins: this.coins,
      sabotage: this.sab ? { ...this.sab } : null,
      sabotageCd: Math.max(0, this.sabCd),
      danger,
      canTalk: talkable !== null,
      talkName: talkable?.info.name ?? "",
      jailTime: Math.max(0, p.jailedT),
      onCamera: p.info.isImpostor && !this.isGhost && this.inCameraView(p.x, p.z),
      camerasDown: Math.max(0, this.camerasDownT),
      cameraCd: Math.max(0, this.camCd),
      clue: this.bodyClue(),
      canWatchCams:
        !this.isGhost &&
        p.jailedT <= 0 &&
        this.camerasDownT <= 0 &&
        Math.hypot(p.x - this.monitorPos.x, p.z - this.monitorPos.z) < CAM_WATCH_RANGE,
      watchingCam: this.camView,
      camCount: CAMERAS.length,
      mission: this.missionInfo(),
      murderPlan: this.murderInfo(),
      canSit:
        !this.isGhost &&
        !this.sitting &&
        p.jailedT <= 0 &&
        !this.sab &&
        this.state === "playing" &&
        Math.hypot(p.x - EMERGENCY_POS.x, p.z - EMERGENCY_POS.z) < SIT_RANGE,
      sitting: this.sitting,
    };
  }

  missionInfo() {
    if (!this.pendingMission) return null;
    const bot = this.entities.find((e) => e.info.id === this.pendingMission!.botId);
    const target = this.entities.find((e) => e.info.id === this.pendingMission!.targetId);
    if (!bot || !target) return null;
    return {
      botId: bot.info.id,
      botName: bot.info.name,
      targetId: target.info.id,
      targetName: target.info.name,
      reward: this.pendingMission.reward,
    };
  }

  murderInfo() {
    if (!this.pendingMurder) return null;
    const bot = this.entities.find((e) => e.info.id === this.pendingMurder!.botId);
    const target = this.entities.find((e) => e.info.id === this.pendingMurder!.targetId);
    if (!bot || !bot.info.alive || !target || !target.info.alive) return null;
    return {
      botId: bot.info.id,
      botName: bot.info.name,
      targetId: target.info.id,
      targetName: target.info.name,
      reward: this.pendingMurder.reward,
    };
  }

  bodyClue(): string {
    return killSystem_bodyClue(this);
  }

  consumeVote(): boolean {
    if (this.voteTokens <= 0) return false;
    this.voteTokens--;
    return true;
  }

  consumeDefense(): boolean {
    if (this.defensesLeft <= 0) return false;
    this.defensesLeft--;
    return true;
  }

  // ------------------------------------------------------------ social API

  nearestTalkable(): Entity | null {
    return socialSystem_nearestTalkable(this) as Entity | null;
  }

  say(e: Entity, text: string, dur = 3.6) {
    return socialSystem_say(this, e, text, dur);
  }

  /** player says something to the nearest bot; returns the player's own line */
  playerTalk(kind: TalkKind): string {
    return socialSystem_playerTalk(this, kind);
  }

  respondProposal(accept: boolean, prop?: { reward?: number; targetId?: number }) {
    return socialSystem_respondProposal(this, accept, prop);
  }

  pressUse() {
    // emergency button only (tasks/fixes run through minigames)
    if (this.state !== "playing" || this.isGhost || this.sab) return;
    const p = this.entities[0];
    if (p.jailedT > 0) return;
    if (Math.hypot(p.x - EMERGENCY_POS.x, p.z - EMERGENCY_POS.z) < 2.6 && this.emergencyLeft > 0) {
      this.emergencyLeft--;
      this.startMeeting({ reason: "emergency", reporterId: 0, victimId: null, accusedId: null });
    }
  }

  pressReport() {
    return killSystem_pressReport(this);
  }

  pressKill() {
    return killSystem_pressKill(this);
  }

  triggerSabotage(kind: SabKind) {
    return sabotageSystem_triggerSabotage(this, kind);
  }

  jail(id: number) {
    return jailSystem_jail(this, id);
  }

  resolveMeeting(ejectedId: number | null, jailedId: number | null = null) {
    return meetingSystem_resolveMeeting(this, ejectedId, jailedId);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    this.renderer.dispose();
  }

  // -------------------------------------------------------------- sabotage

  startSabotage(kind: SabKind) {
    return sabotageSystem_startSabotage(this, kind);
  }

  clearSabotage() {
    return sabotageSystem_clearSabotage(this);
  }

  applyBlackout(on: boolean) {
    return sabotageSystem_applyBlackout(this, on);
  }

  // ----------------------------------------------------------------- logic

  nearestBody(): Body | null {
    return killSystem_nearestBody(this) as Body | null;
  }

  nearestVictim(): Entity | null {
    return killSystem_nearestVictim(this) as Entity | null;
  }

  globalTaskProgress(): number {
    return taskSystem_globalTaskProgress(this);
  }

  fleePath(e: Entity, from: Entity): NavNode[] {
    return killSystem_fleePath(this, e, from);
  }

  kill(killer: Entity, victim: Entity) {
    return killSystem_kill(this, killer, victim);
  }

  startMeeting(data: MeetingData) {
    return meetingSystem_startMeeting(this, data);
  }

  checkWin(): boolean {
    if (this.state === "over") return true;
    const aliveImps = this.entities.filter((e) => e.info.alive && e.info.isImpostor).length;
    const aliveCrew = this.entities.filter((e) => e.info.alive && !e.info.isImpostor).length;
    const impostorIds = this.entities.filter((e) => e.info.isImpostor).map((e) => e.info.id);
    const playerImp = this.entities[0].info.isImpostor;

    let over: GameOverData | null = null;
    if (aliveImps === 0) {
      over = { kind: "crew-eject", playerWon: !playerImp, impostorIds };
    } else if (this.globalTaskProgress() >= 1) {
      over = { kind: "crew-tasks", playerWon: !playerImp, impostorIds };
    } else if (aliveImps >= aliveCrew) {
      over = { kind: "impostor-kill", playerWon: playerImp, impostorIds };
    }
    if (over) {
      this.endGame(over);
      return true;
    }
    return false;
  }

  endGame(data: GameOverData) {
    this.state = "over";
    if (this.sab?.kind === "lights") this.applyBlackout(false);
    this.alarmLight.intensity = 0;
    this.onEvent({ type: "gameover", data });
  }

  // ------------------------------------------------------------------ loop

  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const rawDt = this.clock.getDelta();
    let dt = Math.min(rawDt, 0.05);
    // 30fps cap: skip frames but carry the elapsed time into the next update
    if (this.fpsInterval > 0) {
      this.frameAcc += dt;
      if (this.frameAcc < this.fpsInterval) return;
      dt = Math.min(this.frameAcc, 0.08);
      this.frameAcc = 0;
    }

    // ---- dynamic resolution: keep gameplay smooth on weak phones ----
    if (rawDt > 0) {
      this.fpsEma = this.fpsEma * 0.95 + (1 / rawDt) * 0.05;
      this.dynResTimer += rawDt;
      if (this.dynResTimer > 2) {
        this.dynResTimer = 0;
        const capTarget = this.fpsInterval > 0 ? 30 : 60;
        const floor = Math.max(0.85, this.targetRatio * 0.6); // never blurry
        if (this.fpsEma < capTarget * 0.65 && this.curRatio > floor) {
          // only under REAL strain → small step down, sharpness preserved
          this.curRatio = Math.max(floor, this.curRatio - 0.1);
          this.renderer.setPixelRatio(this.curRatio);
        } else if (this.fpsEma > capTarget * 0.9 && this.curRatio < this.targetRatio) {
          // recover to full clarity quickly
          this.curRatio = Math.min(this.targetRatio, this.curRatio + 0.2);
          this.renderer.setPixelRatio(this.curRatio);
        }
      }
    }
    if (this.state === "playing" && !this.paused) {
      this.worldT += dt;
      // record CCTV sightings every 0.6s
      this.sightTimer -= dt;
      if (this.sightTimer <= 0) {
        this.sightTimer = 0.6;
        if (this.camerasDownT <= 0) {
          for (const e of this.entities) {
            if (!e.info.alive || e.jailedT > 0) continue;
            if (this.inCameraView(e.x, e.z)) {
              this.sightMap.set(e.info.id, { room: roomNameAt(e.x, e.z), t: this.worldT });
            }
          }
        }
      }
      this.sabCd -= dt;
      this.camCd -= dt;
      this.botCamCd -= dt;
      if (this.camerasDownT > 0) {
        // BUGFIX: force-exit the CCTV viewer for anyone watching while cams are dead
        if (this.camView >= 0) this.camView = -1;
        this.camerasDownT -= dt;
        if (this.camerasDownT <= 0) {
          for (const m of this.camLEDs) {
            m.emissiveIntensity = 2;
            m.color.set(0xff2222);
          }
        }
      }
      this.updateSabotage(dt);
      this.updatePlayer(dt);
      this.updateSocial(dt);
      this.updateBots(dt);
      this.updateTaskWork(dt);
      this.updateFootprints(dt);
    }
    // bubble + jail timers always tick
    for (const e of this.entities) {
      if (e.bubbleT > 0) {
        e.bubbleT -= dt;
        if (e.bubbleT <= 0) e.rig.bubble.visible = false;
      }
      if (this.state === "playing" && !this.paused && e.jailedT > 0) {
        e.jailedT -= dt;
        if (e.jailedT <= 0 && e.info.isBot) {
          e.path = [];
          e.dwell = 0.5;
          this.say(e, "بالاخره آزاد شدم! 😮‍💨", 3);
        }
      }
    }
    // transient animations (corpse pop / rising souls)
    for (let i = this.anims.length - 1; i >= 0; i--) {
      const a = this.anims[i];
      a.t += dt;
      const k = Math.min(1, a.t / a.dur);
      if (a.kind === "corpse") {
        const ease = 1 - Math.pow(1 - k, 3);
        const squash = 1 + Math.sin(k * Math.PI) * 0.35;
        a.obj.scale.set(0.15 + 0.85 * ease * squash, 0.15 + 0.85 * ease, 0.15 + 0.85 * ease * squash);
      } else if (a.kind === "ghost") {
        a.obj.position.y += dt * 1.15;
        a.obj.rotation.y += dt * 1.8;
        const m = a.obj as THREE.Mesh;
        (m.material as THREE.MeshStandardMaterial).opacity = 0.55 * (1 - k);
      } else {
        // footprint slow fade
        const m = a.obj as THREE.Mesh;
        (m.material as THREE.MeshBasicMaterial).opacity = 0.75 * (1 - k);
      }
      if (k >= 1) {
        if (a.kind === "ghost" || a.kind === "print") this.scene.remove(a.obj);
        else a.obj.scale.setScalar(1);
        this.anims.splice(i, 1);
      }
    }
    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
  };

  // ------------------------------------------------------------ social loop

  buildProposal(bot: Entity): ProposalData {
    return socialSystem_buildProposal(this, bot);
  }

  updateSocial(dt: number) {
    return socialSystem_updateSocial(this, dt);
  }

  updateSabotage(dt: number) {
    return sabotageSystem_updateSabotage(this, dt);
  }

  tryMove(e: Entity, dx: number, dz: number, ghost = false) {
    if (e.jailedT > 0) {
      // locked in the prison cell
      const nx = e.x + dx;
      const nz = e.z + dz;
      if (nx > PRISON.x0 + 0.75 && nx < PRISON.x1 - 0.75) e.x = nx;
      if (nz > PRISON.z0 + 0.75 && nz < PRISON.z1 - 0.75) e.z = nz;
      return;
    }
    if (ghost) {
      e.x = Math.max(-40, Math.min(38, e.x + dx));
      e.z = Math.max(-26, Math.min(30, e.z + dz));
      return;
    }
    if (canStand(e.x + dx, e.z + dz, RADIUS)) {
      e.x += dx;
      e.z += dz;
    } else if (canStand(e.x + dx, e.z, RADIUS)) {
      e.x += dx;
    } else if (canStand(e.x, e.z + dz, RADIUS)) {
      e.z += dz;
    }
  }

  updatePlayer(dt: number) {
    const p = this.entities[0];
    this.playerKillCd -= dt;

    let kx = 0,
      ky = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) ky -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) ky += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) kx -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) kx += 1;
    const mx = this.moveX + kx;
    const my = this.moveY + ky;
    const mag = Math.min(1, Math.hypot(mx, my));

    if (mag > 0.12) {
      if (this.camView >= 0) this.camView = -1; // moving exits CCTV view
      if (this.sitting) this.standUp(); // moving stands you up from the table
      const ang = Math.atan2(-mx, -my);
      const dir = p.yaw + ang;
      const speed = (this.isGhost ? PLAYER_SPEED * 1.25 : PLAYER_SPEED) * mag;
      const dx = Math.sin(dir) * -speed * dt;
      const dz = Math.cos(dir) * -speed * dt;
      this.tryMove(p, dx, dz, this.isGhost);
      p.walking = true;
    } else {
      p.walking = false;
    }
    p.rig.group.position.set(p.x, 0, p.z);
  }

  updateBots(dt: number) {
    return botAISystem_updateBots(this, dt);
  }

  updateFootprints(dt: number) {
    return renderSystem_updateFootprints(this, dt);
  }

  updateTaskWork(dt: number) {
    return taskSystem_updateTaskWork(this, dt);
  }

  updateCamera(dt: number) {
    return renderSystem_updateCamera(this, dt);
  }
}
