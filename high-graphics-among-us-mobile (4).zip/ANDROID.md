# 📱 راهنمای ساخت APK افقی (Capacitor)

مشکل شناسایی‌شده: در `AndroidManifest.xml` هیچ `android:screenOrientation` تنظیم نشده بود،
پس اندروید WebView را روی حالت عمودی نگه می‌داشت.

## ✅ راه‌حل ۱ — اصلاح مانیفست (اصلی و ضروری)

فایل `android/app/src/main/AndroidManifest.xml` را باز کن و تگ اکتیویتی اصلی را
به این شکل اصلاح کن (دو attribute مهم: `screenOrientation` و `configChanges`):

```xml
<activity
    android:name=".MainActivity"
    android:label="@string/title_activity_main"
    android:theme="@style/AppTheme.NoActionBarLaunch"
    android:launchMode="singleTask"
    android:exported="true"
    android:screenOrientation="sensorLandscape"
    android:configChanges="orientation|screenSize|screenLayout|keyboardHidden|smallestScreenSize|uiMode">
```

- `sensorLandscape` = همیشه افقی، ولی بین افقی چپ/راست با سنسور می‌چرخد (مثل همه بازی‌ها)
- `configChanges` شامل `orientation|screenSize` = هنگام چرخش، اکتیویتی ری‌استارت نمی‌شود
  (بدون این، WebView هر بار reload می‌شود و بازی از اول شروع می‌شود!)

سپس:

```bash
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug
```

## ✅ راه‌حل ۲ — پلاگین قفل نرم‌افزاری (اختیاری، پشتیبان)

کد بازی به‌صورت خودکار پلاگین ScreenOrientation کپاسیتور را (اگر نصب باشد) تشخیص
می‌دهد و استفاده می‌کند — در WebView بدون نیاز به fullscreen قفل می‌کند:

```bash
npm install @capacitor/screen-orientation
npx cap sync android
```

هیچ کد اضافه‌ای لازم نیست؛ `applyOrientation` در `src/game/settings.ts` خودش
پلاگین را پیدا می‌کند. اگر پلاگین نباشد هم چرخش CSS پشتیبان است.

## 🔧 نکات تکمیلی مانیفست

برای تجربه تمام‌عیار بازی، این‌ها هم پیشنهاد می‌شود:

```xml
<!-- داخل <activity> — مخفی‌کردن نوار وضعیت با تم -->
<!-- و داخل styles.xml تم AppTheme.NoActionBarLaunch را fullscreen کن: -->
<item name="android:windowFullscreen">true</item>
```

## 📋 چک‌لیست نهایی

- [ ] `screenOrientation="sensorLandscape"` روی MainActivity
- [ ] `configChanges` شامل `orientation|screenSize`
- [ ] `npm run build` قبل از `npx cap sync`
- [ ] تست: بازی باز شود → گوشی خودکار افقی بچرخد → با چرخاندن گوشی بین دو حالت افقی جابه‌جا شود → عمودی نشود
